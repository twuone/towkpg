const FailPlugin = require('webpack-fail-plugin');
import HtmlReplaceWebpackPlugin from 'html-replace-webpack-plugin';
const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');
const webpack = require('webpack');

module.exports = {
  entry: {
    main: './src/js/main.ts',
  },
  output: {
    filename: '[name].[hash].js',
    publicPath: './',
    path: path.resolve(__dirname, 'build'),
  },
  module: {
    rules: [
      {
        test: /\.(js|ts)$/,
        loader: 'babel-loader',
        exclude: /(node_modules)/,
      },
      {
        test: /\.html$/,
        loader: 'html-loader',
      },
      {
        test: /\.(css|scss)$/,
        use: [
          { loader: 'style-loader' },
          { loader: 'css-loader' },
          {
            loader: 'sass-loader',
            options: {
              includePaths: ['src/scss', 'src/assets'],
            },
          },
          { loader: 'postcss-loader' },
        ],
      },
      {
        test: /\.(png|jp(e*)g|svg)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              limit: 8000, // Convert images < 8kb to base64 strings
              name: 'images/[hash]-[name].[ext]',
            },
          },
        ],
      },
    ],
  },
  target: 'web',
  resolve: {
    extensions: ['.ts', '.js', '.json'],
    modules: ['node_modules', path.resolve(__dirname, 'src/js')],
  },
  optimization: {
    splitChunks: {
      chunks: 'all',
      minChunks: 1,
      minSize: 30000,
      maxSize: 0,
      name: true,
      cacheGroups: {
        vendors: {
          test: /[\\/]node_modules[\\/]/,
          priority: -10,
        },
        default: {
          minChunks: 2,
          priority: -20,
          reuseExistingChunk: true,
        },
      },
    },
  },
  plugins: [
    new webpack.ProvidePlugin({
      $: 'jquery',
      jQuery: 'jquery',
      Waves: 'node-waves',
    }),
    new webpack.optimize.OccurrenceOrderPlugin(),
    new webpack.NoEmitOnErrorsPlugin(),
    FailPlugin,
    new HtmlWebpackPlugin({
      template: path.resolve(__dirname, 'src/index.html'),
      filename: 'index.html',
    }),
    new HtmlReplaceWebpackPlugin([
      {
        pattern: /\@\@GoogleTagAPIKey\@\@/,
        replacement: () =>
          require('./src/environments/environment').default.googleTagAPIKey,
      },
      {
        pattern: /\@\@GoogleMapsAPIKey\@\@/,
        replacement: () =>
          require('./src/environments/environment').default.googleApiKey,
      },
    ]),
    new webpack.LoaderOptionsPlugin({
      debug: true,
    }),
  ],
};
