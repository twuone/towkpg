# Guia de Migração

O ciclo de vida do AngularJS foi estendido até 2020, o que é um bom tempo, mas 
está cada vez mais difícil encontrar novas soluções para o AngularJS. Pensando 
em seguir o padrão da Serasa Experian, escrevi esse guia com alguns passos para 
realizar a migração do Polis gradualmente, o que pode ser a única maneira 
possível.

## Incluir o Webpack no lugar do browserify
O webpack conta com recursos avançados de treeshaking, loaders que permitem 
importar basicamente tudo em arquivos .js como .html, .scss.

## Seguir a estrutura de pastas do John Papa
Seguindo um padrão já estabelecido, John Papa sugere que as aplicações AngularJS
sejam separadas por feature, em módulos, ao contrário do antigo agrupamento MVC 
em que os arquivos eram agrupados por camada (Model, View, Controllers), no caso
do Angular por tipos (constants, values, controllers, components, etc.). Esse 
tipo de separação por tipos dificulta a manutenção, além de não deixar claro do 
que se trata a aplicação.

## Remover padrões antigos

### `$rootScope`
Substituir as chamadas do $rootScope por algum gerenciador de estado moderno.

### `.values` e `.constants` por arquivos simples exportando constantes via ES6

## Converter arquivos `.js` para `.ts``

## Seguir guia completo de migração do Angular
