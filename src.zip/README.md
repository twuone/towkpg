# POLIS Next Frontend

**POLIS Next Smartzones** é uma aplicação que permite consulta via mapa ou bases enviada pelo usuário, e plotar uma série de gráficos com base nos filtros permitidos.

O projeto foi desenvolvido com AngularJS (1.5+ com componentes), ES6 e Gulp.

## Requisitos

- NodeJS (vide versão no `.nvmrc`)

## Ambientes

- [`dev` (Stagging)](https://next-polis-polis-stg.apps.appcanvas.net)
- [`qa` (Qualidade)](https://polis-next-polis-qa.f-internal.br.appcanvas.net)
- [`prod` (Produção)](https://polis.f.apps.experian.com)

## Desenvolvimento

Primeiramente instale as dependências da aplicação com `npm`:

```sh
npm install
```

Para desenvolver, use a tarefa `start` em uma das variações abaixo:
```sh
npm start # ambiente de desenvolvimento
npm run start:qa # apontando para QA
npm run start:prod # cuidado! Aponta diretamente para o ambiente de produção. Use quando extremamente necessário.
```

A tarefa `start` iniciará uma tarefa no gulp com *watch* para escutar alterações nos arquivos. Será possível navegar na aplicação através do endereço [localhost:5000](http://localhost:5000) e o portal do `browserSync` em [localhost:5001](http://localhost:5001).

Antes de modificar algo, leia as [regras de modificação (CONTRIBUTING.md)](/CONTRIBUTING.md).

## Deploy
O projeto usa **Docker** e **Jenkins** no fluxo de publicação. Maiores detalhes nos arquivos `Dockerfile` e `jenkins.yml`.

Nas tarefas npm é possível encontrar as tarefas prefixadas com `build`. Essas tarefas são responsáveis por gerar os assets para publicação.

## Bugs

Issues da equipe do POLIS - [jiraglobal.experian.local/projects/POLIS/issues/](https://jiraglobal.experian.local/projects/POLIS/issues/)

E-mail equipe POLIS - [Team Polis <TeamPolis@br.experian.com>](mailto:TeamPolis@br.experian.com)

