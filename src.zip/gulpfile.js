require("@babel/register");

const { clean } = require('./gulp-tasks/clean');

const { paths, files } = require('./config/gulp.config');
const { task, watch, series, parallel, registry } = require('gulp');
const HubRegistry = require('gulp-hub');
const hub = new HubRegistry([
  './gulp-tasks/*.js',
]);

registry(hub);

// This task is used for building production ready
// minified JS/CSS files into the build/ folder
task('build', series(['banner', clean, 'config', 'assets', parallel(['layers', 'js:prod', 'styles'])]));

task('build:dev', series(['banner', clean, 'config', 'html', 'styles', 'assets', 'layers', 'templates', 'views']));

task('watch', parallel('browser_sync', function watchFiles() {
  watch(paths.src.styles, {}, series(['styles']));
  watch(files.html, {}, series(['html']));
  watch(paths.src.templates, {}, series(['templates']));
  watch(paths.src.img, {}, series(['sprite']));
  watch(paths.src.views, {}, series(['views']));
  watch(paths.src.json, {}, series(['assets:copy']));
}));

task('default', series(['build:dev', 'watch']));
