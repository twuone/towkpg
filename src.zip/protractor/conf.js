// conf.js
exports.config = {
    framework: 'jasmine',
    seleniumAddress: 'http://localhost:4444/wd/hub',
    specs: ['./specs/*.js'],
    // capabilities: {
	// 	'browserName': 'chrome',
    //     chromeOptions: {
    //         args: ["--headless", "disable-gpu", "--ignore-certificate-errors", "--window-size=1024,768"]
    //     }
    // }
}