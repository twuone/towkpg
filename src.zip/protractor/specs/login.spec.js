const Commons = require('../commons.js');
const Login = require('../page-objects/login.js');
const Mapa = require('../page-objects/mapa.js');
const commons = new Commons();

describe('Login', function() {
    beforeEach(function() {
        commons.visity();
    });

    afterEach(function() {
        commons.clearBrowser();
    });

    it('Acesso com senha errada', function() {

        const login = new Login()
        login.inputEmail('gft.lucas.yoshioka@teste.com');
        login.inputPassword('Lumaba13!1');
        login.submit();
        login.closeModalInvalidPassword();
        const resp = login.getTextFrominvalidPasswordModal()

        expect('E-mail ou senha inválidos').toBe(resp);
    });
    
    it('Acessar com dados correto', function() {
        
        const login = new Login()
        login.inputEmail('gft.lucas.yoshioka@teste.com');
        login.inputPassword('Lumaba13!');
        login.submit();

        expect(new Mapa().hasBrand()).toBeTruthy();
    });
  });