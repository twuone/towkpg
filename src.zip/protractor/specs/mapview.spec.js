const Mapa = require('../page-objects/mapa.js');

const Commons = require('../commons.js');
const commons = new Commons();

describe('MapaView', function() {
   
    beforeEach(function() {
        commons.visity();
        commons.login('gft.lucas.yoshioka@teste.com','Lumaba13!');
    })

    afterEach(function(){
        commons.clearBrowser();
    });
    
    it('Clicar ', function() {
        const mapa = new Mapa();
        mapa.clickInterestPointsButton();
        mapa.clicklayersSelectToggleButton();
        mapa.loadDataButton();
        const resp = mapa.getTextFromSerasaVariablesGroupLabel();

        expect('VARIÁVEIS SERASA').toBe(resp);
    })
    
  });