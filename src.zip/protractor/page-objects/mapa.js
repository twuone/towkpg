class Mapa{

    constructor(){
        this.brandImage = element(by.xpath('/html/body/div[1]/app-header/div/h1/img'));
        this.interestPontsButton = element(by.xpath('/html/body/div[1]/app-header/div/button'));
        this.layersSelectToggleButton = element(by.xpath('//*[@id="tabFilters"]/div[2]/div[1]/div[2]/div/label'));
        this.loadeDataButton = element(by.xpath('//*[@id="tabFilters"]/div[5]/div/button'));
        this.serasaVariablesGroupLabel = element(by.xpath('/html/body/div[1]/div/panel-primary/div/div/div/div/div[1]'));
    }

    hasBrand(){
        return browser.isElementPresent(this.brandImage);
    }

    clickInterestPointsButton(){
        this.interestPontsButton.click();
    }

    clicklayersSelectToggleButton(){
        this.layersSelectToggleButton.click();
    }

    loadDataButton(){
        this.loadeDataButton.click();
    }

    getTextFromSerasaVariablesGroupLabel(){
        return this.serasaVariablesGroupLabel.getText();
    }


};

module.exports = Mapa;