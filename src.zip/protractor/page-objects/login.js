class Login {
    constructor() {
        this.emailInput = element(by.id('authEmail'));
        this.passwordInput = element(by.id('authPassword'));
        this.submitButton = element(by.id('authSubmit'));
        this.invalidPasswordModalButton = element(by.xpath('/html/body/div[3]/div/div[3]/button[1]'));
        this.invalidPasswordModalH1 = element(by.id('swal2-title'));
    }

    inputEmail(text) {
        this.emailInput.sendKeys(text);
    }

    inputPassword(text) {
        this.passwordInput.sendKeys(text);
    }

    submit() {
        this.submitButton.click();
    }

    closeModalInvalidPassword() {
        this.invalidPasswordModalButton.click()
    }

    getTextFrominvalidPasswordModal(){
        return this.invalidPasswordModalH1.getText();
    }

};
module.exports = Login;