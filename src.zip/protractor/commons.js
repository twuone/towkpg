const Login = require('./page-objects/login.js');

class Commons{
    login(user,pass) {
        const login = new Login();
        login.inputEmail(user);
        login.inputPassword(pass);
        login.submit();
    }

    visity(){
        browser.get('https://polis-next-polis-qa.f-internal.br.appcanvas.net/');
        this.waitElementLoad($('.text-center a'));
    }
    
    waitElementLoad(elementSelector){
        const EC = protractor.ExpectedConditions;
        browser.wait(EC.visibilityOf(elementSelector, 10000));
    }
    

    clearBrowser(){
        browser.executeScript('window.sessionStorage.clear();');
		browser.executeScript('window.localStorage.clear();');
		browser.driver.manage().deleteAllCookies();
    }

    clickElement(elementSelected){
        element(elementSelected).click();
    }
};


module.exports = Commons;