## To install Protractor
npm install -g protractor

webdriver-manager update --proxy http://user:senha@spobrproxy.serasa.intranet:3128

webdriver-manager start

