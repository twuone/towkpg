module.exports = {
  linters: {
    '**/*.+(js)': [
      'eslint --fix --quiet',
      'git add',
    ],
  },
};
