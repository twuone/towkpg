# Contribuindo com Polis Next Smartzones

## Estilo de código
Por se tratar de um projeto em migração de uma área focada em entregas rápidas, 
o Polis não possuía um padrão de código. Como a manutenção no projeto é muito 
custosa e não tem exatamente no roadmap do projeto a reescrita total, faz-se 
necessária a migração gradual do projeto visando sustentabilidade do mesmo. 

Para auxiliar no processo de adequação do código, foi colocado no processo de 
commit um linter e um formatador de código para iniciar um processo de 
padronização da base de código atual.

### Princípios
Como o projeto está em migração, não há exatamente um styleguide com muitas 
regras definidas, mas existe algumas coisas que facilitam a manutenção do 
código:
- Use nomes para variáveis e funções que signifiquem algo
- Não se repita
- Respeite a régua horizontal de 80 colunas
- Lembre que **passamos mais tempo lendo código do que escrevendo**.
Pense em como será a reação da próxima pessoa ao se deparar com o que você fez

### Linter
O projeto usa o [ESLint](https://eslint.org/) como linter de código, com algumas regras básicas por 
enquanto, e muitas delas modificadas de `error` para `warn` já que o projeto 
ainda está em migração. Para que a manutenção fique cada vez mais fácil e se 
estabeleça um padrão de código, procure trocar a gravidade de alguma regra do 
linter de `warn` para `error`. As regras podem ser encontradas no arquivos `.eslintrc.json`.

#### Trocando a gravidade de uma regra
Vamos supor que queremos aumentar a gravidade do uso de `var` no código. No 
`.eslintrc` modifique a linha:
```gitignore
//...
 "no-var": 1, 
//...
```
E incremente o número do peso da regra:
```gitignore
//...
 "no-var": 2, 
//...
```
Deixando o linter cada vez mais rigoroso vai exigir uma base de código cada vez mais coerente e fácil de manter.

### Formatador de código
O projeto usa o [Prettier](https://prettier.io/) como formatador de código. Ele 
está configurado para se basear nas regras do linter. Mais detalhes no arquivo 
`.prettierrc`.

### Política de commit
A cada tentativa de commit de código, o plugin `lint-staged` passa e impede o 
código de ser submetido se ele quebrar algumas das regras do linter  ou do 
formatador de código.

### Melhorando as regras
As regras foram baseadas em exemplos da internet, mas podem e devem ser 
modificadas de acordo com a evolução do projeto. O importante é que elas sejam 
observadas e aplicadas em toda a base de código. Se encontrar alguma que não 
goste ou tenha preferência de outra forma, não ignore as regras atuais ou 
desative o `lint-staged`. Se estiver insatisfeita(o), modifique as regras e 
aplique-as em todos os arquivos. O importante é a base de código falar uma 
mesma língua.


### Migração
[Guia de migração de AngularJS -> Angular](/MIGRATING.md)
