const webpackConfig = require('./webpack.config.common');
const path = require('path');
const merge = require('webpack-merge');
const webpack = require('webpack');

module.exports = merge(webpackConfig, {
  entry: {
    main: [
        './src/js/main.ts',
        'webpack/hot/dev-server',
        'webpack-hot-middleware/client'
    ]
},
  mode: 'development',
  devtool: 'eval-source-map',
  devServer: {
    overlay: true,
    compress: true,
    hot: false,
    contentBase: path.join(__dirname, 'build')
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
  ]
});

