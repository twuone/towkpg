const { task, src, series, dest, registry } = require('gulp');
const uglify = require('gulp-uglify');
const sourcemaps = require('gulp-sourcemaps');
const buffer = require('vinyl-buffer');
const browserify = require('browserify');
const source = require('vinyl-source-stream');
const babelify = require('babelify');
const envify = require('envify');
const HubRegistry = require('gulp-hub');
const { files, paths, interceptErrors, isProd } = require('../config/gulp.config');

const hub = new HubRegistry([
  './views.js',
  './webpack.js',
]);

registry(hub);

function compile(opts = {
  sourceMaps: false
}) {
  return browserify(files.mainJs, {
      debug: opts.sourceMaps
    })
    .transform(babelify, {
      sourceMaps: opts.sourceMaps
    })
    .transform(envify, {
      NODE_ENV: isProd ? 'production' : 'development',
    });
}

task('compile:dev', () =>
  compile({
    sourceMaps: false
  })
  .bundle()
  .on('error', interceptErrors)
  .pipe(source('index.js'))
  .pipe(dest(paths.build.js)));

task('compile:prod', () =>
  src(files.buildMainJs)
  .pipe(uglify())
  .pipe(dest(paths.build.js)));

// task('js:prod', series(['browserify:prod', 'compile:prod']));

task('js:prod', series(['webpack']));

task('browserify:prod', series(['views', 'compile:dev']));

// task('js', () =>
//   compile({
//     sourceMaps: true
//   })
//   .bundle()
//   .on('error', interceptErrors)
//   .pipe(source('index.js'))
//   .pipe(buffer())
//   .pipe(sourcemaps.init({
//     loadMaps: true,
//   }))
//   .pipe(sourcemaps.write({
//     includeContent: true,
//     sourceRoot: '/'
//   }))
//   .pipe(dest(paths.build.js)));

task('js', series(['webpack']));
