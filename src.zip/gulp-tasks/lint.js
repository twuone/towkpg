const { task, src } = require('gulp');
const eslint = require('gulp-eslint');
const { paths } = require('../config/gulp.config');

task('lint', () =>
  src(paths.src.js)
  .pipe(eslint({
    ignorePath: '.eslintignore'
  }))
  .pipe(eslint.format())
  .pipe(eslint.failAfterError())
);
