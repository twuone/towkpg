const { task, src, dest, series } = require('gulp');
const { files, paths, interceptErrors } = require('../config/gulp.config');

task('html', () =>
  src(files.html)
  .on('error', interceptErrors)
  .pipe(dest(paths.build.root))
);

task('html:prod', series(['html', () =>
  src(files.buildHtml)
  .pipe(dest(paths.build.root))
]));
