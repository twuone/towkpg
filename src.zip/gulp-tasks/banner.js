const { task } = require('gulp');
const log = console.log;
const chalk = require('chalk');
const packageJson = require('../package.json');
const { isProd, BUILD_ENV } = require('../config/gulp.config');

task('banner', (done) => {
  function envColor(env) {
    switch (env) {
      case 'qa':
        return chalk.black.bgYellow.bold(env);
      case 'prod':
        return chalk.white.bgRed.bold(env);
      default:
        return chalk.black.bgGreen.bold(env);
    }
  }

  log(`Building ${chalk.white.bgMagenta.bold('POLIS Next v' + packageJson.version)}`);
  log('Prod mode? ', isProd ? 'Yes' : 'No');
  log(`Targeting environment: ${envColor(BUILD_ENV)}`);
  done();
});