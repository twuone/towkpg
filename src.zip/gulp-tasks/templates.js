const { src, task, dest } = require('gulp');
const { paths, interceptErrors } = require('../config/gulp.config');

task('templates', () =>
  src(paths.src.templates)
  .on('error', interceptErrors)
  .pipe(dest(paths.build.templates))
);
