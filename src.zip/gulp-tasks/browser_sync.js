const { task, watch } = require('gulp');
const browserSync = require('browser-sync').create();
const webpackDevMiddleware = require('webpack-dev-middleware');
const webpackHotMiddleware = require('webpack-hot-middleware');
const webpack = require('webpack');
const webpackConfig = require('../webpack.config.dev');

const bundler = webpack(webpackConfig);

task('browser_sync', (done) => {
  browserSync.init(['./build/**/**.**'], {
    server: './build',
    open: false,
    middleware: [
      webpackDevMiddleware(bundler),
      webpackHotMiddleware(bundler),
    ],
    port: 5000,
    notify: true,
    ghostMode: false,
    ui: {
      port: 5001
    }
  });

  watch('./build/**/**.**')
    .on('change', () => browserSync.reload());
});
