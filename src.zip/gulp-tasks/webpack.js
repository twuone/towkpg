const { task, src, dest } = require('gulp');
const webpack = require('webpack-stream');
const compiler = require('webpack');
const webpackDevServer = require('webpack-dev-server');
const { files, paths, interceptErrors } = require('../config/gulp.config');

const log = console.log;

task('webpack', () =>
  src(files.mainJs)
  .pipe(
    webpack(require('../webpack.config.prod')),
    compiler
  )
  .on('error', interceptErrors)
  .pipe(dest(paths.build.root)));

task('webpack-dev-server', (done) => {
  const webpackConfig = require('../webpack.config.dev.js');

  new webpackDevServer(compiler(webpackConfig))
    .listen(webpackConfig.devServer.port, 'localhost', (err) => {
      if (err) {
        log('webpack-dev-server error', err);
        done(err);
      }
      log('[webpack-dev-server]', `http://localhost:${webpackConfig.devServer.port}`);
    });
});
