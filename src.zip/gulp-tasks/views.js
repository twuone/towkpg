const { task, src, dest } = require('gulp');
const templateCache = require('gulp-angular-templatecache');
const rename = require('gulp-rename');
const { paths, interceptErrors } = require('../config/gulp.config');

const templateHeader = `import angular from 'angular';

export const TemplatesModule = angular
  .module('<%= module %>'<%= standalone %>)
  .run(function TemplatesRun($templateCache) {
    'ngInject';
`;

const templateFooter = '}).name;';

const fileSystemPathSlashes = /^(\/|\\)+/g;

task('views', () =>
  src(paths.src.views)
  .pipe(templateCache({
    standalone: true,
    // Remove leading slash which occurs in gulp 4
    transformUrl: (url) => url.replace(fileSystemPathSlashes, ''),
    templateHeader: templateHeader,
    templateFooter: templateFooter
  }))
  .on('error', interceptErrors)
  .pipe(rename('templates.module.js'))
  .pipe(dest('./src/js/templates/')));
