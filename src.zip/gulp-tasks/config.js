const { task, src, dest } = require('gulp');
const rename = require('gulp-rename');
const { BUILD_ENV } = require('../config/gulp.config');

task('config', () => {
  function getConfigPathByEnv() {
    switch (BUILD_ENV) {
      case 'prod':
        return 'environment.prod.js';
      case 'qa':
        return 'environment.qa.js';
      default:
        return 'environment.dev.js';
    }
  }

  return src(`./src/environments/${getConfigPathByEnv()}`)
    .pipe(rename('environment.js'))
    .pipe(dest('./src/environments/'));
});
