const { task } = require('gulp');
const rimraf = require('rimraf');
const { paths } = require('../config/gulp.config');

export const clean = (cb) => {
  rimraf(`{${paths.build.root},./src/environments/environment.js}`, cb);
}

task('clean', clean);
