var { paths } = require('../config/gulp.config');
const { task, src, dest, parallel, series } = require('gulp');

var spritesmith = require('gulp.spritesmith');

task('sprite', function () {
  var spriteData = src('src/assets/img/mosaic/*.png').pipe(spritesmith({
    imgName: 'mosaic-sprite.png',
    cssName: 'sprite.css'
  }));
  return spriteData.pipe(dest('./build/assets/_mosaic'));
});