const { task, src, dest } = require('gulp');
const decompress = require('gulp-decompress');
const { paths, files } = require('../config/gulp.config');

task('layers', () =>
  src(files.layers)
  .pipe(decompress({
    strip: 1
  }))
  .pipe(dest(paths.build.layers)));
