const { task, src, dest, parallel, series } = require('gulp');
const { paths, interceptErrors }  = require('../config/gulp.config');

task('assets:favicon', () =>
  src('src/favicon.ico')
  .on('error', interceptErrors)
  .pipe(dest(paths.build.root)));

task('assets:fonts', () =>
  src(paths.src.fonts)
  .on('error', interceptErrors)
  .pipe(dest(paths.build.fonts)));

task('assets:copy', () =>
  src(paths.src.assets)
  .on('error', interceptErrors)
  .pipe(dest(paths.build.assets)));

task('assets', series(['assets:copy', parallel(['assets:fonts', 'assets:favicon'])]));
