const { task, src, dest } = require('gulp');
const { paths } = require('../config/gulp.config');
const sass = require('gulp-sass');

task('styles', () =>
  src(paths.src.styles)
  .pipe(
    sass({
      includePaths: ['node_modules']
    })
    .on('error', sass.logError))
  .pipe(dest(paths.build.styles)));
