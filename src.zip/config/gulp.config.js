const notify = require('gulp-notify');
const argv = require('yargs').argv; 

const paths = {
  src: {
    assets: 'src/assets/**/*',
    img: 'src/assets/img/mosaic/*.png',
    fonts: 'node_modules/@mdi/font/fonts/**/*',
    js: 'src/js/**/*.js',
    json: 'src/js/**/*.json',
    styles: 'src/scss/**/*.scss',
    templates: 'templates/**/*',
    views: 'src/js/**/*.html',
      // 'window.$': 'jquery',
      // 'window.jQuery': 'jquery',
      // 'Popper': 'popper.js',
      // 'window.Popper': 'popper.js',
  },
  build: {
    assets: './build/assets',
    img: './build/assets/_mosaic',
    root: './build/',
    js: './build/assets/js',
    fonts: './build/assets/fonts/mdi',
    layers: './build/assets/layers',
    styles: './build/assets/css',
    templates: './build/templates',
    preBuiltJs: './assets/js',
  },
};

const files = {
  buildHtml: 'build/index.html',
  buildMainJs: 'build/assets/js/index.js',
  html: 'src/index.html',
  layers: './layers.tar.gz',
  mainJs: './src/js/main.ts',
  preBuiltJs: './assets/js/index.js',
};

const interceptErrors = function(...args) {
  // Send error to notification center with gulp-notify
  notify
    .onError({
      title: 'Compile Error',
      message: '<%= error.message %>',
    })
    .apply(this, args);

  // Keep gulp from hanging on this task
  this.emit('end');
};

const BUILD_ENV = argv.env || 'dev';
const isProd = BUILD_ENV !== 'dev' && BUILD_ENV !== 'development';

module.exports = {
  paths: paths,
  files: files,
  interceptErrors: interceptErrors,
  BUILD_ENV: BUILD_ENV,
  isProd: isProd,
};
