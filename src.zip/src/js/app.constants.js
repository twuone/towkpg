import environment from '../environments/environment';

const AppConstants = {
  api(version = 'v1', endpoint = '/api/') {
    const protocol =
      String(environment.apiUrl).indexOf('http') === -1

        // ? `${window.location.protocol}//`
        ? `https://`
        : '';
    const hostname = environment.apiUrl;
    const resource = endpoint === '/api/' ? `${endpoint}${version}` : endpoint;

    return protocol + hostname + resource;
  },
  jwtKey: environment.jwtKey,
  appName: environment.appName,
  google_api_key: environment.googleApiKey,
};

export default AppConstants;
