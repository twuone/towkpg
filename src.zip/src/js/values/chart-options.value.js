const ChartOptions = {
  estimated_revenue($translate, ESTIMATED_REVENUE) {
    return {
      chart: { 
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.ESTIMATED_REVENUE.VALUES.' +
              ESTIMATED_REVENUE[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key" ta-id="teste-">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.ESTIMATED_REVENUE.VALUES.' +
                      d.data.label.toUpperCase(),
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  number_of_employees($translate, NUMBER_OF_EMPLOYEES) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.NUMBER_OF_EMPLOYEES.VALUES.' +
              NUMBER_OF_EMPLOYEES[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.NUMBER_OF_EMPLOYEES.VALUES.' +
                      NUMBER_OF_EMPLOYEES[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  existence_time($translate, EXISTENCE_TIME) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.EXISTENCE_TIME.VALUES.' +
              EXISTENCE_TIME[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.EXISTENCE_TIME.VALUES.' +
                      EXISTENCE_TIME[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  size($translate, SIZE) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.SIZE.VALUES.' + SIZE[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant('CARDS.SIZE.VALUES.' + SIZE[d.data.label.toLowerCase()])}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  company_credit_risk($translate, COMPANY_CREDIT_RISK) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.COMPANY_CREDIT_RISK.VALUES.' +
              COMPANY_CREDIT_RISK[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.COMPANY_CREDIT_RISK.VALUES.' +
                      COMPANY_CREDIT_RISK[d.data.label.toUpperCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  credit_risk($translate, CREDIT_RISK) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.CREDIT_RISK.VALUES.' + CREDIT_RISK[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.CREDIT_RISK.VALUES.' +
                      CREDIT_RISK[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  age($translate, AGE) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.AGE.VALUES.' + AGE[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant('CARDS.AGE.VALUES.' + AGE[d.data.label.toLowerCase()])}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  mosaic($translate, MOSAIC) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.MOSAIC.VALUES.' + MOSAIC[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        color(d) {
          let mosaicColor;

          switch (d.label.toLowerCase()) {
            case 'a01':
            case 'a02':
              mosaicColor = '#4C4686';
              break;
            case 'b03':
            case 'b04':
            case 'b05':
              mosaicColor = '#2A616E';
              break;
            case 'c06':
            case 'c07':
            case 'c08':
              mosaicColor = '#53ABA3';
              break;
            case 'd09':
            case 'd10':
            case 'd11':
            case 'd12':
            case 'd13':
            case 'd14':
              mosaicColor = '#8A3235';
              break;
            case 'e15':
            case 'e16':
            case 'e17':
            case 'e18':
              mosaicColor = '#D0BD30';
              break;
            case 'f19':
            case 'f20':
            case 'f21':
              mosaicColor = '#8D8A82';
              break;
            case 'g22':
            case 'g23':
            case 'g24':
              mosaicColor = '#9B3480';
              break;
            case 'h25':
            case 'h26':
            case 'h27':
            case 'h28':
            case 'h29':
              mosaicColor = '#C47030';
              break;
            case 'i30':
            case 'i31':
            case 'i32':
              mosaicColor = '#6EC03A';
              break;
            case 'j33':
            case 'j34':
              mosaicColor = '#785A43';
              break;
            case 'k35':
            case 'k36':
            case 'k37':
            case 'k38':
            case 'k39':
            case 'k40':
              mosaicColor = '#006845';
              break;
            default:
              mosaicColor = '#333'; // Worst color in case of error
          }
          return mosaicColor;
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.MOSAIC.VALUES.' + MOSAIC[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },

        // labelSunbeamLayout: true,
        showLegend: false,
        donut: true,
      },
    };
  },
  'mosaic-pj'($translate, MOSAIC_PJ) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.MOSAIC_PJ.VALUES.' + MOSAIC_PJ[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        color(d) {
          let mosaicColor;

          switch (d.label[0]) {
            case 'a':
              mosaicColor = '#4C4686';
              break;
            case 'b':
              mosaicColor = '#2A616E';
              break;
            case 'c':
              mosaicColor = '#53ABA3';
              break;
            case 'd':
              mosaicColor = '#8A3235';
              break;
            case 'e':
              mosaicColor = '#D0BD30';
              break;
            case 'f':
              mosaicColor = '#8D8A82';
              break;
            case 'g':
              mosaicColor = '#9B3480';
              break;
            default:
              mosaicColor = '#333'; // Worst color in case of error
          }
          return mosaicColor;
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.MOSAIC_PJ.VALUES.' +
                      MOSAIC_PJ[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },

        // labelSunbeamLayout: true,
        showLegend: false,
        donut: true,
      },
    };
  },
  cnae($translate, CNAE_GROUP) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.CNAE_GROUP.VALUES.' + CNAE_GROUP[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.CNAE_GROUP.VALUES.' +
                      CNAE_GROUP[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
        donut: true,
      },
    };
  },
  socialClass($translate, SOCIAL_CLASS) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          bottom: 120,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.SOCIAL_CLASS.VALUES.' + SOCIAL_CLASS[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: true,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.SOCIAL_CLASS.TITLE'),
          rotateLabels: -45,
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.RESIDENTS'),
          axisLabelDistance: -10,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.SOCIAL_CLASS.VALUES.' +
                      SOCIAL_CLASS[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  weekDays($translate, WEEK_DAYS) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        x: (d) => {
          return $translate
            .instant('CARDS.WEEK_DAYS.VALUES.' + WEEK_DAYS[d.label])
            .substring(0, 3);
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: true,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.WEEK_DAYS.TITLE'),
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.AUDIENCE'),
          axisLabelDistance: -10,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.WEEK_DAYS.VALUES.' +
                      WEEK_DAYS[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  hotHours($translate, HOT_HOURS) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        x: (d) => {
          return $translate.instant(
            'CARDS.HOT_HOURS.VALUES.' + HOT_HOURS[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        y(d) {
          return d.percentage;
        },
        showValues: true,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.HOT_HOURS.TITLE'),
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.AUDIENCE'),
          axisLabelDistance: -10,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.HOT_HOURS.VALUES.' +
                      HOT_HOURS[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  displacementHome($translate, DISPLACEMENT_HOME) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 350,
        width: 400,
        margin: {
          top: 20,
          right: 20,
          bottom: 120,
          left: 60,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.DISPLACEMENT_HOME.VALUES.' +
              DISPLACEMENT_HOME[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: false,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.DISPLACEMENT_HOME.TITLE'),
          axisLabelDistance: 100,
          rotateLabels: -45,
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.AUDIENCE'),
          axisLabelDistance: -15,
          showMaxMin: true,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.DISPLACEMENT_HOME.VALUES.' +
                      DISPLACEMENT_HOME[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  displacementWork($translate, DISPLACEMENT_WORK) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 350,
        width: 400,
        margin: {
          top: 20,
          right: 20,
          bottom: 120,
          left: 60,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.DISPLACEMENT_WORK.VALUES.' +
              DISPLACEMENT_WORK[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: false,
        valueFormat(d) {
          return d.toFixed(0) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.DISPLACEMENT_WORK.TITLE'),
          axisLabelDistance: 100,
          rotateLabels: -45,
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.AUDIENCE'),
          axisLabelDistance: -15,
          showMaxMin: true,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.DISPLACEMENT_WORK.VALUES.' +
                      DISPLACEMENT_WORK[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  duration($translate, DURATION) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 350,
        width: 400,
        margin: {
          top: 20,
          right: 20,
          bottom: 120,
          left: 60,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.DURATION.VALUES.' + DURATION[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: false,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.DURATION.TITLE'),
          axisLabelDistance: 100,
          rotateLabels: -45,
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.AUDIENCE'),
          axisLabelDistance: -15,
          showMaxMin: true,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.DURATION.VALUES.' +
                      DURATION[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  residents_quantity($translate, RESIDENTS_QUANTITY) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          bottom: 120,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.RESIDENTS_QUANTITY.VALUES.' +
              RESIDENTS_QUANTITY[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: true,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.RESIDENTS_QUANTITY.TITLE'),
          rotateLabels: -45,
        },
        yAxis: {
          axisLabel: $translate.instant(
            'CARDS.RESIDENTS_QUANTITY.Y_AXIS_LABEL',
          ),
          axisLabelDistance: -10,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.RESIDENTS_QUANTITY.VALUES.' +
                      RESIDENTS_QUANTITY[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  socialClass2($translate, SOCIAL_CLASS) {
    return {
      chart: {
        type: 'discreteBarChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 300,
        width: 400,
        margin: {
          bottom: 120,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.SOCIAL_CLASS.VALUES.' + SOCIAL_CLASS[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showValues: true,
        valueFormat(d) {
          return d.toFixed(1) + '%';
        },
        duration: 500,
        xAxis: {
          axisLabel: $translate.instant('CARDS.SOCIAL_CLASS.TITLE'),
          rotateLabels: -45,
        },
        yAxis: {
          axisLabel: $translate.instant('COMPONENTS.CARD.RESIDENTS'),
          axisLabelDistance: -10,
          tickFormat(d) {
            return d.toFixed(0) + '%';
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.SOCIAL_CLASS.VALUES.' +
                      SOCIAL_CLASS[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        yDomain: [0, 100],
      },
    };
  },
  generic() {
    return {
      chart: {
        type: 'pieChart',
        height: 340,
        x: (d) => {
          return d.label;
        },
        y: (d) => {
          return d.percentage;
        },
        showLabels: true,
        duration: 500,
        labelThreshold: 0.01,
        labelSunbeamLayout: false,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
										 <div class="tooltip-key">
											${d.data.label}
										 </div>
										 <div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        donut: true,
        labelType: 'value',
        valueFormat(d) {
          if (d > 3) {
            return d.toFixed(1) + '%';
          }
        },
        showLegend: false,
        callback: () => {
          // Dispatch a resize event on every tab change
          // so D3 awakens to do any necessary redrawing
          setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
          }, 200);
        },
      },
    };
  },
  cs_cbfs($translate, CS_CBFS) {
    const cbfsChart = ChartOptions.generic_pie($translate);

    cbfsChart.chart.x = (d) =>
      $translate.instant(
        'CARDS.CS_CBFS.VALUES.' + CS_CBFS[d.label.toLowerCase()],
      );

    cbfsChart.chart.tooltip.contentGenerator = (d) => `
    <div class="tooltip-key">
      <span class="tooltip-color-indicator" style="background-color: ${
        d.color
      };"></span>

    ${$translate.instant(
      'CARDS.CS_CBFS.VALUES.' + CS_CBFS[d.data.label.toLowerCase()],
    )}
    </div>
    <div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;

    return cbfsChart;
  },
  gender($translate, GENDER) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.GENDER.VALUES.' + GENDER[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.GENDER.VALUES.' + GENDER[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  generic_pie($translate) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return d.label;
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${d.data.label}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  scholarity($translate, SCHOLARITY) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.SCHOLARITY.VALUES.' + SCHOLARITY[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.SCHOLARITY.VALUES.' + SCHOLARITY[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  occupation($translate, OCCUPATION) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.OCCUPATION.VALUES.' + OCCUPATION[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.OCCUPATION.VALUES.' +
                      OCCUPATION[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  cs_score($translate, CS_SCORE) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.CS_SCORE.VALUES.' + d.label.toUpperCase(),
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant('CARDS.CS_SCORE.VALUES.' + d.data.label.toUpperCase())}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  cs_csba($translate, CS_CSBA) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.CS_CSBA.VALUES.' + CS_CSBA[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.CS_CSBA.VALUES.' +
                      CS_CSBA[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  cs_csba_bv($translate, CS_CSBA_BV) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.CS_CSBA_BV.VALUES.' + CS_CSBA_BV[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.CS_CSBA_BV.VALUES.' +
                      CS_CSBA_BV[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  cs_c2ba($translate, CS_C2BA) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant('CARDS.CS_C2BA.VALUES.' + CS_C2BA[d.label]);
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant('CARDS.CS_C2BA.VALUES.' + d.data.label.toUpperCase())}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  cs_c2ba_riachuelo($translate, CS_C2BA_RIACHUELO) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.CS_C2BA_RIACHUELO.VALUES.' + CS_C2BA_RIACHUELO[d.label],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.CS_C2BA_RIACHUELO.VALUES.' +
                      d.data.label.toUpperCase(),
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  address_accuracy($translate, ADDRESS_ACCURACY) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.ADDRESS_ACCURACY.VALUES.' +
              ADDRESS_ACCURACY[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.ADDRESS_ACCURACY.VALUES.' +
                      ADDRESS_ACCURACY[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  registration_status($translate, REGISTRATION_STATUS) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.REGISTRATION_STATUS.VALUES.' + d.label.toUpperCase(),
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.REGISTRATION_STATUS.VALUES.' +
                      d.data.label.toUpperCase(),
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  marital_status($translate, MARITAL_STATUS) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.MARITAL_STATUS.VALUES.' +
              MARITAL_STATUS[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.MARITAL_STATUS.VALUES.' +
                      MARITAL_STATUS[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  income_range($translate, INCOME_RANGE) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.INCOME_RANGE.VALUES.' + INCOME_RANGE[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) =>
            `<div class="tooltip-key">
              <span class="tooltip-color-indicator" style="background-color: ${
                d.color
              };"></span>
              ${$translate.instant(
                'CARDS.INCOME_RANGE.VALUES.' +
                  INCOME_RANGE[d.data.label.toLowerCase()],
              )}
              </div>
            <div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`,
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  cs_renda_bv($translate, CS_RENDA_BV) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) =>
          $translate.instant(
            'CARDS.CS_RENDA_BV.VALUES.' + CS_RENDA_BV[d.label.toLowerCase()],
          ),
        y: (d) => d.percentage,
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) =>
            `<div class="tooltip-key">
                <span class="tooltip-color-indicator" style="background-color: ${
                  d.color
                };"></span>
                ${$translate.instant(
                  'CARDS.CS_RENDA_BV.VALUES.' +
                    CS_RENDA_BV[d.data.label.toLowerCase()],
                )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`,
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },

  cs_restritivo($translate, CS_RESTRITIVO) {
    const chartCsRestritivo = ChartOptions.generic_pie($translate, CS_RESTRITIVO);

    chartCsRestritivo.chart.x = (d) =>
      $translate.instant(
        'CARDS.CS_RESTRITIVO.VALUES.' + CS_RESTRITIVO[d.label.toLowerCase()],
      );

    chartCsRestritivo.chart.tooltip.contentGenerator = (d) => `<div class="tooltip-key">
    <span class="tooltip-color-indicator" style="background-color: ${d.color};"></span>
      ${$translate.instant(
    'CARDS.CS_RESTRITIVO.VALUES.' +  CS_RESTRITIVO[d.data.label.toLowerCase()],
  )}
    </div>
    <div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;

    return chartCsRestritivo;
  },

  simples_nacional($translate, SIMPLES_NACIONAL) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.SIMPLES_NACIONAL.VALUES.' +
              SIMPLES_NACIONAL[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.SIMPLES_NACIONAL.VALUES.' +
                      SIMPLES_NACIONAL[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  operability_index($translate, OPERABILITY_INDEX) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.OPERABILITY_INDEX.VALUES.' +
              OPERABILITY_INDEX[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.OPERABILITY_INDEX.VALUES.' +
                      OPERABILITY_INDEX[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  number_of_branch_offices($translate, NUMBER_OF_BRANCH_OFFICES) {
    return {
      chart: {
        type: 'pieChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        height: 200,
        width: 400,
        margin: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
        x: (d) => {
          return $translate.instant(
            'CARDS.NUMBER_OF_BRANCH_OFFICES.VALUES.' +
              NUMBER_OF_BRANCH_OFFICES[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.percentage;
        },
        cornerRadius: 0,
        tooltip: {
          contentGenerator: (d) => {
            const content = `
								<div class="tooltip-key">
									<span class="tooltip-color-indicator" style="background-color: ${
                    d.color
                  };"></span>
									${$translate.instant(
                    'CARDS.NUMBER_OF_BRANCH_OFFICES.VALUES.' +
                      NUMBER_OF_BRANCH_OFFICES[d.data.label.toLowerCase()],
                  )}
								</div>
								<div class="tooltip-value">${d.data.percentage.toFixed(1)}%</div>`;
            return content;
          },
        },
        showLabels: true,
        showLegend: false,
        duration: 500,
        labelThreshold: 0.01,
        labelType: 'value',
        valueFormat(d) {
          if (d > 5) {
            return d.toFixed(1) + '%';
          }
        },
      },
    };
  },
  places($translate, PLACES, $rootScope) {
    let colorScale = d3.scale
      .linear()
      .domain([1, Object.keys(PLACES).length])
      .interpolate(d3.interpolateHcl)
      .range([d3.rgb('#007AFF'), d3.rgb('#FFF500')]);

    let maxw = 0;
    let lastScope = {};

    $rootScope.$on('$translateChangeEnd', () => {
      maxw = 0;

      d3.select(lastScope.container)
        .selectAll('.nvd3 .tick')
        .each(function() {
          if (this.getBBox().width > maxw) maxw = this.getBBox().width;
        });

      d3.select(lastScope.container)
        .select('.nvd3')
        .attr('transform', 'translate(' + (maxw + 10) + ',' + 0 + ')');
    });

    return {
      chart: {
        type: 'multiBarHorizontalChart',
        noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
        x: (d) => {
          return $translate.instant(
            'CARDS.PLACES.VALUES.' + PLACES[d.label.toLowerCase()],
          );
        },
        y: (d) => {
          return d.value;
        },
        margin: {
          left: 170,
          right: 50,
          top: 20,
          bottom: 20,
        },
        yAxis: {
          tickFormat(d) {
            return d.toFixed(0);
          },
        },
        tooltip: {
          contentGenerator: (d) => {
            const content = `
						<div class="tooltip-key">
						<span class="tooltip-color-indicator" style="background-color: ${
              d.color
            };"></span>
						${$translate.instant('CARDS.PLACES.VALUES.' + d.data.label)}
						</div>
						<div class="tooltip-value">${d.data.value}</div>`;
            return content;
          },
        },
        barColor(d, i) {
          return colorScale(i);
        },
        showLabels: false,
        duration: 300,
        labelThreshold: 0.01,
        labelType: 'value',
        showLegend: false,
        showControls: false,
        groupSpacing: 0.5,
        callback(scope) {
          lastScope = scope;

          d3.select(scope.container)
            .selectAll('.nvd3 .tick')
            .each(function() {
              if (this.getBBox().width > maxw) maxw = this.getBBox().width;
            });

          d3.select(scope.container)
            .select('.nvd3')
            .attr('transform', 'translate(' + (maxw + 10) + ',' + 0 + ')');
        },
      },
    };
  },
};

export default ChartOptions;
