const Tab = {
  cards: 'residents',
  applied: null,
  available: [
    'companies',
    'residents'
  ],
  isResidents() {
    return this.cards === 'residents';
  },
  isCompanies() {
    return this.cards === 'companies';
  },
  isVisitors() {
    return this.cards === 'visitors';
  }
};

export default Tab;
