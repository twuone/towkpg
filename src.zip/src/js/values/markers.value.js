let Markers = {
	primary: {
		guid: "",
		desc: "",
		center: {},
		type: ""
	},
	compare: {
		guid: "",
		desc: "",
		center: {}
	},
	reset() {
		this.primary.guid = "";
		this.primary.desc = "";
		this.primary.center = {};
		this.primary.type = "";

		this.compare.guid = "";
		this.compare.desc = "";
		this.compare.center = {};
	}
};

export default Markers;
