import { module } from 'angular';

import ChartOptions from './chart-options.value';
import MapValues from './map.value';
import MarkersValues from './markers.value';
import TabValues from './tab.value';

// Create the module where our functionality can attach to
export const ValuesModule = module('app.values', [])
  .value('Markers', MarkersValues)
  .value('MapValues', MapValues)
  .value('Tab', TabValues)
  .value('ChartOptions', ChartOptions).name;
