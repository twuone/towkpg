let MapValues = {
	center: {
		lat: 0,
		lng: 0
	}
};

export default MapValues;
