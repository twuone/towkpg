import * as angular from 'angular';
import * as jQuery from 'jquery';
import Popper from 'popper.js';

declare global {
  interface Window {
    jQuery: JQueryStatic;
    $: JQueryStatic;
    Popper: any;
    app: ng.IModule
  }
}

window.jQuery = window.$ = jQuery;

window.Popper = Popper;

import 'bootstrap';
import 'mdbootstrap/js/mdb';

import { AppModule } from './app.module';

window.app = angular.module(AppModule);

angular.bootstrap(document, [AppModule], {
  strictDi: true,
});
