const SIZE = {
	'MEI' : "MEI",	
	'MICRO' : "MICRO",
	'PEQUENA' : "SMALL",
	'MÉDIA' : "MEDIUM",
	'GRANDE' : "LARGE",
	'NA': "UNKNOWN",
	'mei' : "MEI",	
	'micro' : "MICRO",
	'small' : "SMALL",
	'medium' : "MEDIUM",
	'large' : "LARGE",
	'unknown': "UNKNOWN"
};

export default SIZE;