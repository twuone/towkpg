const EXISTENCE_TIME = {
  'até 1 ano' : "1_YEAR",
  '1 a 3 anos' : "1_TO_3_YEARS",
  '3 a 5 anos' : "3_TO_5_YEARS",
  '5 a 10 anos' : "5_TO_10_YEARS",
  '10 a 20 anos' : "10_TO_20_YEARS",
  'Acima de 20 anos' : "ABOVE_20_YEARS",
  '1_year' : "1_YEAR",
  '1_to_3_years' : "1_TO_3_YEARS",
  '3_to_5_years' : "3_TO_5_YEARS",
  '5_to_10_years' : "5_TO_10_YEARS",
  '10_to_20_years' : "10_TO_20_YEARS",
  'above_20_years' : "ABOVE_20_YEARS",
  '[00, 01)' : "1_YEAR",
  '[01, 03]' : "1_TO_3_YEARS",
  '[03, 05)' : "3_TO_5_YEARS",
  '[05, 10)' : "5_TO_10_YEARS",
  '[10, 20)' : "10_TO_20_YEARS",
  '[20, inf)' : "ABOVE_20_YEARS",
  'unknown' : "UNKNOWN",
};

export default EXISTENCE_TIME;
