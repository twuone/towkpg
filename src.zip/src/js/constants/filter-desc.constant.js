export const DEFAULT_AFFINITIES = {
  bolsa_familia: {
    label: 'Bolsa Família',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  broadband_inclination: {
    label: 'Banda Larga',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_cargo_van_inclination: {
    label: 'Veículo Van',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_compact_hatch_inclination: {
    label: 'Veículo Hatch Compacto',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_compact_van_inclination: {
    label: 'Veículo Van Compacta',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_crossover_inclination: {
    label: 'Veículo Crossover',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_insurance_inclination: {
    label: 'Seguro Automotivo',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_jeep_inclination: {
    label: 'Veículo Jeep',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_large_minivan_inclination: {
    label: 'Veículo MiniVan Grande',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_light_crossover_inclination: {
    label: 'Veículo Crossover Leve',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_loan_inclination: {
    label: 'Empréstimo Automotivo',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_premium_hatch_inclination: {
    label: 'Veículo Hatch Premium',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_premium_sedan_inclination: {
    label: 'Veículo Sedan Premium',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_small_minivan_inclination: {
    label: 'Veículo MiniVan Compacta',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_small_pickup_inclination: {
    label: 'Veículo Pickup Compacto',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_small_sedan: {
    label: 'Veículo Sedan Compacto',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_sport_inclination: {
    label: 'Veículo Esportivo',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_standard_hatch_inclination: {
    label: 'Veículo Hatch',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_standard_large_pickup_inclination: {
    label: 'Veículo Pickup Grande',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_standard_minivan_inclination: {
    label: 'Veículo MiniVan',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_standard_sedan_inclination: {
    label: 'Veículo Sedan',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  car_suv_inclination: {
    label: 'Veículo SUV',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  consignado_credit_inclination: {
    label: 'Crédito Consignado',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  credit_card_holding_inclination: {
    label: 'Posse de Cartão de Crédito',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  credit_taking_inclination: {
    label: 'Tomar Crédito',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  discount_hunter_inclination: {
    label: 'Caçador de Descontos',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  early_adopters: {
    label: 'Early Adopters',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  ebook_reader_inclination: {
    label: 'Leitor Digital',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  ecommerce_inclination: {
    label: 'E-commerce',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  fitness_inclination: {
    label: 'Boa Forma',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  gameconsole_inclination: {
    label: 'Console Gamer',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  gameonline_inclination: {
    label: 'Online Gamer',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  health_insurance_inclination: {
    label: 'Plano de Saúde',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },

  pl_card_inclination: {
    label: 'Cartão Private Label',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  house_insurance_inclination: {
    label: 'Seguro Imobiliario',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  internet_high_user_inclination: {
    label: 'Usuário de Internet',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  investor_inclination: {
    label: 'Investidor',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  life_insurance_inclination: {
    label: 'Seguro de Vida',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  luxury_inclination: {
    label: 'Luxo',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  mileage_program_inclination: {
    label: 'Programa de Milhas',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  mobile: {
    label: 'Tem Celular',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  mobile_profile_inclination: {
    label: 'Perfil Mobile',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  movie_buff_inclination: {
    label: 'Cinéfilo',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  multiple_banking_account_inclination: {
    label: 'Múltiplas Contas Bancárias',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  multiple_cards_inclination: {
    label: 'Múltiplos Cartões de Crédito',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  net_banking_inclination: {
    label: 'Internet Banking',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  own_home_inclination: {
    label: 'Casa Própria',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  pessoal_credit_inclination: {
    label: 'Crédito Pessoal',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  phone: {
    label: 'Tem Telefone',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  postpaid_mobile_phone_inclination: {
    label: 'Plano Pós-Pago',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  premium_client_inclination: {
    label: 'Cliente Premium',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  prepaid_mobile_phone_inclination: {
    label: 'Plano Pré-Pago',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  prime_card_inclination: {
    label: 'Cartão Prime',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  private_pension_inclination: {
    label: 'Previdência Privada',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  public_sector: {
    label: 'Funcionário Público',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  public_transportation_inclination: {
    label: 'Transporte Público',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  real_estate_credit_inclination: {
    label: 'Crédito Imobiliário',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  satcbl_tv_inclination: {
    label: 'TV por Assinatura',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  shareholder_inclination: {
    label: 'Sócio',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  tourism_inclination: {
    label: 'Turismo',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
};

export const BV_AFFINITIES = {
  credito_pessoal_bv: {
    label: 'Crédito Pessoal',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  aquisicao_bv: {
    label: 'Aquisição de cartão',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
  desbloqueio_bv: {
    label: 'Ativação de cartão',
    values: [
      {
        label: 'Sim',
        value: 'true',
      },
      {
        label: 'Não',
        value: 'false',
      },
      {
        label: 'Ambos',
        value: undefined,
      },
    ],
  },
};

const FILTER_DESC = { ...DEFAULT_AFFINITIES, ...BV_AFFINITIES };

export default FILTER_DESC;
