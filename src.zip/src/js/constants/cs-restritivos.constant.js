const CS_RESTRITIVO = {
  'true' : 'TRUE',
  'false' : 'FALSE'
};

export default CS_RESTRITIVO;
