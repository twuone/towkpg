const SIMPLES_NACIONAL = {
	'true' : "TRUE",
	'false' : "FALSE",
	'inválido' : "UNKNOWN",
	'a' : "UNKNOWN",
	'unknown':'UNKNOWN',
};

export default SIMPLES_NACIONAL;