const BINARY_CHART = {
	'true' : "TRUE",
	'false' : "FALSE",
	'NA': "UNKNOWN",
	'unknown': "UNKNOWN"
};

export default BINARY_CHART;