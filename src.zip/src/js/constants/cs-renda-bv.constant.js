/**
 * Faixas de Renda Pro personalizadas para a BV Financeira (de 2500 a 2500)
 */
const CS_RENDA_BV = {
  "0_to_2500": "0_TO_2500",
  "2500_to_5000": "2500_TO_5000",
  "5000_to_7500": "5000_TO_7500",
  over_7500: "OVER_7500",
  "(0000, 2500]": "0_TO_2500",
  "(5000, 7500]": "5000_TO_7500",
  "(7500, inf)": "OVER_7500",
  unknown: "UNKNOWN"
};

export default CS_RENDA_BV;
