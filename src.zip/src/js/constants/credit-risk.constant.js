const CREDIT_RISK = {
	'BAIXISSIMO RISCO' : "VERY_LOW",
	'BAIXO' : "LOW",
	'MEDIO' : "MEDIUM",
	'ALTO' : "HIGH",
	'ALTISSIMO' : "VERY_HIGH",
	'NA' : "UNKNOWN",
	'very_low' : "VERY_LOW",
	'low' : "LOW",
	'medium' : "MEDIUM",
	'high' : "HIGH",
	'very_high' : "VERY_HIGH",
	'unknown' : "UNKNOWN"
};

export default CREDIT_RISK;