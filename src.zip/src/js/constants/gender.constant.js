const GENDER = {
  "M": "MALE",
  "F": "FEMALE",
  "I": "UNKOWN_TEMP",
  " ": "UNKNOWN",
  "m": "MALE",
  "f": "FEMALE",
  "i": "UNKOWN_TEMP",
  "unknown": "UNKNOWN"
};

export default GENDER;