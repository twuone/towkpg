const NUMBER_OF_EMPLOYEES = {
	"ATE 9 FUNCIONARIOS" : "0_TO_9",
	"DE 10 A 49 FUNCIONARIOS" : "10_TO_49",
	"DE 50 A 199 FUNCIONARIOS" : "50_TO_199",
	"200 FUNCIONARIOS OU MAIS" : "200_OR_ABOVE",
	"NA":"UNKNOWN",
	"0_to_9" : "0_TO_9",
	"10_to_49" : "10_TO_49",
	"50_to_199" : "50_TO_199",
	"200_or_above" : "200_OR_ABOVE",
	"[001, 009]" : "0_TO_9",
    "[010, 049]" : "10_TO_49",
    "[050, 199]" : "50_TO_199",
    "[200, inf)" : "200_OR_ABOVE",
	"unknown":"UNKNOWN"
};

export default NUMBER_OF_EMPLOYEES;