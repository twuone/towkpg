const PERIOD_OF_DAY = {
  "1": "MORNING",
  "2": "AFTERNOON",
  "3": "EVENING",
  "0": "DAWN"
};

export default PERIOD_OF_DAY;