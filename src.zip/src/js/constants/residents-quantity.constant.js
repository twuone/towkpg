const RESIDENTS_QUANTITY = {
	'1' : "1",
    '2' : "2",
    '3' : "3",
    '4' : "4",
    '5' : "5",
    '6+' : "6+",
    'unknown': 'UNKNOWN'
};

export default RESIDENTS_QUANTITY;
