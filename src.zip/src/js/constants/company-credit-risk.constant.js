const COMPANY_CREDIT_RISK = {
	'A' : "A",
	'B' : "B",
	'C' : "C",
	'D' : "D",
	'E' : "E",
	'F' : "F",
	'G' : "G",
	'H' : "H",
	'NA'  : "UNKNOWN",
	'a' : "A",
	'b' : "B",
	'c' : "C",
	'd' : "D",
	'e' : "E",
	'f' : "F",
	'g' : "G",
	'h' : "H",
	'unknown' : "UNKNOWN"
};

export default COMPANY_CREDIT_RISK;