const CS_C2BA = {
	"under_325": "Abaixo de 325",
    "325_to_600": "Entre 325 e 600",
    "601_to_800":"Entre 601 e 800",
    "unknown": "Desconhecido"
};

export default CS_C2BA;
