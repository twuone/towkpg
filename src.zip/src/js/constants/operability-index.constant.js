const OPERABILITY_INDEX = {
    'very_low' : "VERY_LOW",
	'low' : "LOW",
	'medium' : "MEDIUM",
	'high' : "HIGH",
	'very_high' : "VERY_HIGH",
	'unknown':'UNKNOWN',
};

export default OPERABILITY_INDEX;