const OCCUPATION = {
	'0' : "OCUPATION_0",
	'1' : "OCUPATION_1",
    '2' : "OCUPATION_2",
    '3' : "OCUPATION_3",
    '4' : "OCUPATION_4",
    '5' : "OCUPATION_5",
    '6' : "OCUPATION_6",
    '7' : "OCUPATION_7",
    '8' : "OCUPATION_8",
    '9' : "OCUPATION_9",
    'unknown': 'UNKNOWN'
};

export default OCCUPATION;
