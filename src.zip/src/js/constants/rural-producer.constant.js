const RURAL_PRODUCER = {
	'true' : "TRUE",
	'false' : "FALSE"
};

export default RURAL_PRODUCER;