const SERVICE_ERROR = {
  "404": "Card não encontrado",
  "504": "Falha na comunicação: Tente novamente",
  "500": "Falha no servidor: Tente novamente",
  "UNKNOWN": "Erro desconhecido: Tente novamente"
};

export default SERVICE_ERROR;
