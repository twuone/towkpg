const residentsDocuments = [
  {
    name: 'cpf',
    checked: true,
  },
  {
    name: 'nome',
    checked: true,
  },
  {
    name: 'endereco',
    checked: true,
  },
  {
    name: 'telefone',
    checked: true,
  },
  {
    name: 'dataNascimento',
    checked: true,
  },
  {
    name: 'sexo',
    checked: true,
  },
  {
    name: 'nomeMae',
    checked: true,
  },
  {
    name: 'status',
    checked: true,
  },
  {
    name: 'renda',
    checked: true,
  },
  {
    name: 'triagemRisco',
    checked: true,
  },
  {
    name: 'atividadeConsumo',
    checked: true,
  },
  {
    name: 'socioEmpresa',
    checked: true,
  },
  {
    name: 'profissao',
    checked: true,
  },
  {
    name: 'estadoCivil',
    checked: true,
  },
  {
    name: 'escolaridade',
    checked: true,
  },
  {
    name: 'bolsaFamilia',
    checked: true,
  },
  {
    name: 'classeSocial',
    checked: true,
  },
  {
    name: 'mosaic',
    checked: true,
  },
  {
    name: 'afinidadeCartaoCredito',
    checked: true,
  },
  {
    name: 'afinidadeCreditoPessoal',
    checked: true,
  },
  {
    name: 'afinidadeArtigosLuxo',
    checked: true,
  },
  {
    name: 'afinidadePacotesTurismo',
    checked: true,
  },
  {
    name: 'afinidadeImobiliario',
    checked: true,
  },
  {
    name: 'afinidadeTvAssinatura',
    checked: true,
  },
  {
    name: 'afinidadeBandaLarga',
    checked: true,
  },
  {
    name: 'afinidadeEcommerce',
    checked: true,
  },
  {
    name: 'afinidadeSmartPhone',
    checked: true,
  },
  {
    name: 'codigoIbge',
    checked: true,
  },
  {
    name: 'facesClasseMedia',
    checked: true,
  },
  {
    name: 'latitudeLongitude',
    checked: true,
  },
  {
    name: 'nis',
    checked: true,
  },
  {
    name: 'rg',
    checked: true,
  },
  {
    name: 'houseHold',
    checked: true,
  },
  {
    name: 'rendaHousehold',
    checked: true,
  },
  {
    name: 'quantidadeAdultosHousehold',
    checked: true,
  },
];

const companiesDocuments = [
  {
    name: 'cnpj',
    checked: true,
  },
  {
    name: 'razaoSocial',
    checked: true,
  },
  {
    name: 'nomeFantasia',
    checked: true,
  },
  {
    name: 'capitalSocial',
    checked: true,
  },
  {
    name: 'dataAbertura',
    checked: true,
  },
  {
    name: 'naturezaJuridica',
    checked: true,
  },
  {
    name: 'cnae',
    checked: true,
  },
  {
    name: 'endereco',
    checked: true,
  },
  {
    name: 'telefone',
    checked: true,
  },
  {
    name: 'situacaoCadastral',
    checked: true,
  },
  {
    name: 'porte',
    checked: true,
  },
  {
    name: 'quadroSocial',
    checked: true,
  },
  {
    name: 'mosaic',
    checked: true,
  },
  {
    name: 'representanteLegal',
    checked: true,
  },
  {
    name: 'sintegra',
    checked: true,
  },
  {
    name: 'faturamento',
    checked: true,
  },
  {
    name: 'funcionarios',
    checked: true,
  },
  {
    name: 'indicadorOperacionalidade',
    checked: true,
  },
  {
    name: 'codigoIbge',
    checked: true,
  },
  {
    name: 'simplesNacional',
    checked: true,
  },
  {
    name: 'triagemRisco',
    checked: true,
  },
  {
    name: 'matrizFilial',
    checked: true,
  },
  {
    name: 'latitudeLongitude',
    checked: true,
  },
  {
    name: 'suframa',
    checked: true,
  },
];

/**
 * Parâmetros exportáveis pela modal no DataView **SOLICITAR MAIS INFORMAÇÕES**
 */
const REQUEST_DOCUMENTS = {
  residents: residentsDocuments,
  companies: companiesDocuments,
};

export default REQUEST_DOCUMENTS;
