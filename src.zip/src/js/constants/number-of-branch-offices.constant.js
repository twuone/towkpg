const NUMBER_OF_BRANCH_OFFICES = {
	'0' : "0",
	'1' : "1",
	'2' : "2",
	'3' : "3",
	'4+' : "4+",
	'unknown':'UNKNOWN',
};

export default NUMBER_OF_BRANCH_OFFICES;