const SCHOLARITY = {
        'illiterate' : "ILLITERATE",
        'middle_incomplete' : "MIDDLE_INCOMPLETE",
        'middle_complete' : "MIDDLE_COMPLETE",
        'high_incomplete' : "HIGH_INCOMPLETE",
        'high_complete' : "HIGH_COMPLETE",
        'tecnologo_incomplete': "TECNOLOGO_INCOMPLETE",
        'tecnologo_complete': "TECNOLOGO_COMPLETE",
        'college_incomplete' : "COLLEGE_INCOMPLETE",
        'college_complete' : "COLLEGE_COMPLETE",
        'masters_complete' : "MASTERS_COMPLETE",
        'doctorate_complete' : "DOCTORATE_COMPLETE",
        'elementary_incomplete' : "ELEMENTARY_INCOMPLETE",
        'elementary_complete' : "ELEMENTARY_COMPLETE",
        'post_doctorate_complete' : "POST_DOCTORATE_COMPLETE",
        'postgraduation_complete' : "POSTGRADUATION_COMPLETE",
        'vocational_incomplete' : "VOCATIONAL_INCOMPLETE",
        'vocational_complete' : "VOCATIONAL_COMPLETE",
        'unknown': 'UNKNOWN',
        'other':"OTHER"

};

export default SCHOLARITY;
