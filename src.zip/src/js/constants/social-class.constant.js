const SOCIAL_CLASS = {
  'NA': 'UNKNOWN',
  'unknown' : 'UNKNOWN',
  'a': 'A_CLASS',
  'b': 'B_CLASS',
  'c': 'C_CLASS',
  'd': 'D_CLASS',
  'e': 'E_CLASS',
  's': 'S_CLASS'
};

export default SOCIAL_CLASS;
