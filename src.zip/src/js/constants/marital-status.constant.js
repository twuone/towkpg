const MARITAL_STATUS = {
	'S' : "SINGLE",
	'C' : "MARRIED",
	'D' : "DIVORCED",
	'V' : "WIDOWER",
	'O' : "OTHER",
	'NA': "UNKNOWN",
	'single' : "SINGLE",
	'married' : "MARRIED",
	'divorced' : "DIVORCED",
	'widower' : "WIDOWER",
	'other' : "OTHER",
	'unknown': "UNKNOWN"
};

export default MARITAL_STATUS;
