/**
 * Custom CSBA for BV
 * Será habilitado de acordo com o
 */
const BV_DOCUMENTS = {
  residents: [
    {
      name: 'csbaBV',
      checked: true,
      isCustom: true,
      flag: 'extract_cs_csba_bv',
    },
  ],
  companies: [],
};

const CUSTOM_DOCUMENTS = {
  ...BV_DOCUMENTS,
};

export default CUSTOM_DOCUMENTS;
