const CS_CSBA_BV = {
  1: '01',
  2: '02',
  3: '03',
  4: '04',
  unknown: 'UNKNOWN',
  UNKNOWN: 'UNKNOWN',
};

export default CS_CSBA_BV;
