const CS_C2BA_RIACHUELO = {
	"under 250": "Abaixo de 250",
	"under_250": "Abaixo de 250",
	"250_to_500": "Entre 250 e 500",
	"500_to_750": "Entre 500 e 750",
	"750_to_1000": "Entre 750 e 1000",
	"unknown": "Desconhecido"
};

export default CS_C2BA_RIACHUELO;
