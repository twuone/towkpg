const REGISTRATION_STATUS = {
	regular     : 'REGULAR',
	ativa       : 'ACTIVE',
	active      : 'ACTIVE',
	inativa	    : 'INACTIVE',
	canceled    : "CANCELED",
	nulled      : 'NULLED',
	pending	    : 'PENDING',
	Regular	    : 'REGULAR',
	suspended   : 'SUSPENDED',
	unknown     : 'UNKNOWN',
	deactivated : 'DEACTIVATED',
	inapt       : 'INAPT'
};

export default REGISTRATION_STATUS;
