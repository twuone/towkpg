const ADDRESS_ACCURACY = {
	'geolocation' : "GEOLOCATION",
	'address' : "ADDRESS",
	'city' : "CITY",
   'state' : "STATE",
	'none': "UNKNOWN"
};

export default ADDRESS_ACCURACY;
