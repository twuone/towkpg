const FILTERS = {
	'gender': {
		label: 'CARDS.GENDER',
		const: 'GENDER'
	},
	'mosaic': {
		label: 'CARDS.MOSAIC'
	},
	'radius': {
		label: 'FILTERS.RADIUS'
	},
	'social_class': {
		label: 'CARDS.SOCIAL_CLASS',
		const: 'SOCIAL_CLASS'
	},
	'unknownInfo': {
		label: 'FILTERS.UNCLASSIFIED_AUDIENCE'
	}
};

export default FILTERS;