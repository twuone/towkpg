const CS_CBFS = {
  '1': '1',
  '2':'2',
  '3': '3',
  '4': '4',
  '5': '5'
};

export default CS_CBFS;
