import angular from 'angular';

import AddressAccuracyConstant from './address-accuracy.constant';
import AgeConstant from './age.constant';
import BinaryChartConstant from './binary-chart.constant';
import CnaeGroupConstant from './cnae-group.constant';
import CnaeConstant from './cnae.constant';
import CompanyCreditRiskConstant from './company-credit-risk.constant';
import CreditRiskConstant from './credit-risk.constant';
import CsC2baRiachueloConstant from './cs-c2ba-riachuelo.constant';
import CsC2baConstant from './cs-c2ba.constant';
import CsCSBAConstant from './cs-csba.constant';
import CsCSBABVConstant from './cs-csba-bv.constant';
import CsRendaBVConstant from './cs-renda-bv.constant';
import CsRendaConstant from './cs-renda.constant';
import CsScoreConstant from './cs-score.constant';
import DisplacementHomeConstant from './displacement-home.constant';
import DisplacementWorkConstant from './displacement-work.constant';
import DurationConstant from './duration.constant';
import EstimatedRevenueConstant from './estimated-revenue.constant';
import ExistenceTimeConstant from './existence-time.constant';
import FilterDescConstant from './filter-desc.constant';
import FiltersConstant from './filters.constant';
import GenderConstant from './gender.constant';
import HotHoursConstant from './hot-hours.constant';
import IncomeConstant from './income-range.constant';
import MaritalStatusConstant from './marital-status.constant';
import MosaicPJConstant from './mosaic-pj.constant';
import MosaicConstant from './mosaic.constant';
import NumberOfBranchOfficesConstant from './number-of-branch-offices.constant';
import NumberOfEmployeesConstant from './number-of-employees.constant';
import OccupationConstant from './occupation.constant';
import OperabilityIndexConstant from './operability-index.constant';
import PlacesConstants from './places.constants';
import RegistrationStatusConstant from './registration-status.constant';
import REQUEST_DOCUMENTS from './request-documents.constant';
import CUSTOM_DOCUMENTS from './custom-documents.constant';
import ResidentsQuantityConstant from './residents-quantity.constant';
import RuralProducerConstant from './rural-producer.constant';
import ScholarityConstant from './scholarity.constant';
import SimplesNacionalConstant from './simples-nacional.constant';
import SizeConstant from './size.constant';
import SocialClassConstant from './social-class.constant';
import WeekDaysConstant from './week-days.constant';
import CS_RESTRITIVO from './cs-restritivos.constant';
import CS_CBFS from './cs-cbfs.constant';

// Create the module where our functionality can attach to
export const ConstantsModule = angular
  .module('app.constants', [])
  .constant('ADDRESS_ACCURACY', AddressAccuracyConstant)
  .constant('AGE', AgeConstant)
  .constant('BINARY_CHART', BinaryChartConstant) //TODO Change to BooleanChart?
  .constant('CNAE_GROUP', CnaeGroupConstant)
  .constant('CNAE', CnaeConstant)
  .constant('COMPANY_CREDIT_RISK', CompanyCreditRiskConstant)
  .constant('CREDIT_RISK', CreditRiskConstant)
  .constant('CS_C2BA_RIACHUELO', CsC2baRiachueloConstant)
  .constant('CS_C2BA', CsC2baConstant)
  .constant('CS_CSBA', CsCSBAConstant)
  .constant('CS_CSBA_BV', CsCSBABVConstant)
  .constant('CS_RENDA', CsRendaConstant)
  .constant('CS_RENDA_BV', CsRendaBVConstant)
  .constant('CS_RESTRITIVO', CS_RESTRITIVO)
  .constant('CS_CBFS', CS_CBFS)
  .constant('CS_SCORE', CsScoreConstant)
  .constant('DISPLACEMENT_HOME', DisplacementHomeConstant)
  .constant('DISPLACEMENT_WORK', DisplacementWorkConstant)
  .constant('DURATION', DurationConstant)
  .constant('ESTIMATED_REVENUE', EstimatedRevenueConstant)
  .constant('EXISTENCE_TIME', ExistenceTimeConstant)
  .constant('FILTER_DESC', FilterDescConstant)
  .constant('FILTERS', FiltersConstant)
  .constant('GENDER', GenderConstant)
  .constant('HOT_HOURS', HotHoursConstant)
  .constant('INCOME_RANGE', IncomeConstant)
  .constant('MARITAL_STATUS', MaritalStatusConstant)
  .constant('MOSAIC_PJ', MosaicPJConstant)
  .constant('MOSAIC', MosaicConstant)
  .constant('NUMBER_OF_BRANCH_OFFICES', NumberOfBranchOfficesConstant)
  .constant('NUMBER_OF_EMPLOYEES', NumberOfEmployeesConstant)
  .constant('OCCUPATION', OccupationConstant)
  .constant('OPERABILITY_INDEX', OperabilityIndexConstant)
  .constant('PLACES', PlacesConstants)
  .constant('REGISTRATION_STATUS', RegistrationStatusConstant)
  .constant('REQUEST_DOCUMENTS', REQUEST_DOCUMENTS)
  .constant('CUSTOM_DOCUMENTS', CUSTOM_DOCUMENTS)
  .constant('RESIDENTS_QUANTITY', ResidentsQuantityConstant)
  .constant('RURAL_PRODUCER', RuralProducerConstant)
  .constant('SCHOLARITY', ScholarityConstant)
  .constant('SIMPLES_NACIONAL', SimplesNacionalConstant)
  .constant('SIZE', SizeConstant)
  .constant('SOCIAL_CLASS', SocialClassConstant)
  .constant('WEEK_DAYS', WeekDaysConstant).name;
