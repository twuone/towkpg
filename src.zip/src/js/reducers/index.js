import { combineReducers } from 'redux';
import { affinitiesReducer, affinitiesInitialState } from './affinities';
import { router } from 'redux-ui-router';

export const initialState = {
  affinities: affinitiesInitialState,
};

const rootReducer = combineReducers({
  affinities: affinitiesReducer,
  router,
});

export default rootReducer;
