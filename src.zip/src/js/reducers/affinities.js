import { LOAD_AFFINITIES } from '../constants/action-types';

export const affinitiesInitialState = {};

export const affinitiesReducer = (state = affinitiesInitialState, action) => {
  switch (action.type) {
    case LOAD_AFFINITIES:
      return { ...action.affinities };
    default:
      return state;
  }
};
