import template from './auth.html';

function AuthConfig($stateProvider) {
  'ngInject';

  const loginState = {
    name: 'app.login',
    url: '/login',
    controller: 'AuthCtrl as $ctrl',
    template,
    data: {
      title: 'AUTH.LOGIN.SUBMIT',
    },
    resolve: {
      auth: /* @ngInject */ (User) => User.ensureAuthIs(false),
    },
  };

  const forgotPasswordState = {
    name: 'app.forgot',
    url: '/forgot',
    controller: 'AuthCtrl as $ctrl',
    template,
    data: {
      title: 'AUTH.FORGOT.SUBMIT',
    },
    resolve: {
      auth: /* @ngInject */ (User) => User.ensureAuthIs(false),
    },
  };

  const preRegisterState = {
    name: 'app.pre_register',
    url: '/pre_register/:code',
    controller: 'AuthCtrl as $ctrl',
    template,
    data: {
      title: 'AUTH.PRE_REGISTER.SUBMIT',
    },
    resolve: {
      auth: /* @ngInject */ (User) => User.ensureAuthIs(false),
    },
  };

  const smsTokenState = {
    name: 'app.sms',
    url: '/sms/:data',
    controller: 'AuthCtrl as $ctrl',
    template,
    data: {
      title: 'AUTH.SMS.SUBMIT',
    },
    resolve: {
      auth: /* @ngInject */ (User) => User.ensureAuthIs(false),
    },
  };

  $stateProvider
    .state(loginState)
    .state(forgotPasswordState)
    .state(preRegisterState)
    .state(smsTokenState);
}

export default AuthConfig;
