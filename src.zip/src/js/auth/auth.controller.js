export class AuthController {
  constructor(User, $state, $translate, SweetAlert, Modal) {
    'ngInject';

    // init private variables
    this._User = User;
    this._$state = $state;
    this.SweetAlert = SweetAlert;
    this._Modal = Modal;
    this.$translate = $translate;

    // init public variables
    this.title = $state.current.data.title;
    this.authType = $state.current.name.replace('app.', '');
    this.formData = {};
  }

  submitForm() {
    const state = this._$state.current.name.replace('app.', '');

    this.isSubmitting = true;

    switch (state) {
      case 'login':
        this.submitLogin();
        break;
      case 'forgot':
        this.submitForgot();
        break;
      case 'pre_register':
        this.submitPreRegister();
        break;
      case 'sms':
        this.submitSms();
        break;
      default:
        break;
    }
  }

  submitLogin() {
    this._User.attemptAuth(this.authType, this.formData).then(
      () => {
        this._$state.go('app.map-view');

        const waitToModalRender = setInterval(() => {
          if (document.getElementById('modalPasswordChange')) {
            const daysForPasswordUpdate = this._User.info.user.daysForUpdate;
            if (daysForPasswordUpdate > 0 && daysForPasswordUpdate <= 10) {
              const msg1 = this.$translate.instant(
                'AUTH.LOGIN.MESSAGES.RENEW_PASSWORD_1',
              );
              let msg2 = this.$translate.instant(
                'AUTH.LOGIN.MESSAGES.RENEW_PASSWORD_2p',
              );
              if (daysForPasswordUpdate == 1) {
                msg2 = this.$translate.instant(
                  'AUTH.LOGIN.MESSAGES.RENEW_PASSWORD_2s',
                );
              }
              this._Modal.setCurrentModal('modalPasswordChange');
              $('#modalPasswordChange').modal('show');
              this.SweetAlert.error(
                msg1 + ' ' + daysForPasswordUpdate + ' ' + msg2,
              );
            } else if (daysForPasswordUpdate <= 0) {
              const msg3 = this.$translate.instant(
                'AUTH.LOGIN.MESSAGES.RENEW_PASSWORD_3',
              );
              this._Modal.setCurrentModal('modalPasswordChange');
              $('#modalPasswordChange').modal('show');
              this.SweetAlert.error(msg3);
            }
            clearInterval(waitToModalRender);
          }
        }, 1000);
      },
      (err) => {
        this.isSubmitting = false;
        if (err.data && err.data.message == 'IDLE_90_DAYS') {
          this.SweetAlert.error(
            'AUTH.LOGIN.MESSAGES.IDLE_90_DAYS.TITLE',
            'AUTH.LOGIN.MESSAGES.IDLE_90_DAYS.MESSAGE',
          );
        } else {
          this.SweetAlert.error('AUTH.LOGIN.MESSAGES.ERROR');
        }
      },
    );
  }

  submitForgot() {
    this._User.forgot(this.formData).then(
      (res) => {
        this.SweetAlert.success('AUTH.FORGOT.MESSAGES.SUCCESS');
      },
      (err) => {
        this.SweetAlert.success('AUTH.FORGOT.MESSAGES.SUCCESS');
      },
    );
  }

  submitPreRegister() {
    const reg = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}/;

    if (
      this.formData.password == this.formData.confirmPassword &&
      reg.test(this.formData.password)
    ) {
      const payload = {
        password: this.formData.password,
        pre_register_code: this._$state.params.code,
      };

      this._User.preRegister(payload).then(
        (res) => {
          this._$state.go('app.sms', { data: JSON.stringify(res.data) }); // MOCK
        },
        (err) => {
          this.isSubmitting = false;
          this.SweetAlert.error('AUTH.PRE_REGISTER.MESSAGES.ERROR');
        },
      );
    } else {
      this.isSubmitting = false;
      this.SweetAlert.error(
        'AUTH.LOGIN.MESSAGES.INVALID_PASSWORD_FORMAT.TITLE',
        'AUTH.LOGIN.MESSAGES.INVALID_PASSWORD_FORMAT.BODY',
      );
    }
  }

  submitSms() {
    if (this.formData.sms) {
      // MOCK
      const data = JSON.parse(this._$state.params.data);

      const payload = {
        cnpj: data.cnpj,
        email: data.user.email,
        activation_code: this.formData.sms,
      };

      this._User.smsCode(payload).then(
        (res) => {
          this._$state.go('app.login');
          this.SweetAlert.success('AUTH.SMS.MESSAGES.SUCCESS');
        },
        (err) => {
          this.isSubmitting = false;
          this.SweetAlert.success('AUTH.SMS.MESSAGES.ERROR');
        },
      );
    } else {
      this.isSubmitting = false;
      this.SweetAlert.error('AUTH.SMS.MESSAGES.EMPTY');
    }
  }
}
