import angular from 'angular';
import AuthConfig from './auth.config';
import { AuthController } from './auth.controller';

// Create the home module where our functionality can attach to
export const AuthModule = angular
  .module('app.auth', [])
  .controller('AuthCtrl', AuthController)
  .config(AuthConfig).name;
