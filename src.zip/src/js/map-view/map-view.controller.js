import { loadAffinities } from '../actions/affinities';

class MapViewCtrl {
  constructor(
    $ngRedux,
    AppConstants,
    AudienceTypes,
    Cards,
    DimensionService,
    FilterService,
    MapValues,
    Markers,
    SnapshotService,
    User,
  ) {
    'ngInject';

    // init private variables
    this.$ngRedux = $ngRedux;
    this.MapValues = MapValues;
    this.enableSideMenu = false;
    this.DimensionService = DimensionService;
    this.User = User;
    this.Markers = Markers;
    this.SnapshotService = SnapshotService;
    this.FilterService = FilterService;

    // init public variables
    this.appName = AppConstants.appName;
    this.cards = {};
    this.AudienceTypes = AudienceTypes;
    this.Cards = Cards;

    this.$onInit();
  }

  $onInit() {
    this.fetchDimensions();

    if (!this.User.info.account) {
      this.fetchUserData();
    } else {
      this.getCards();
      this.SnapshotService.fetch();
    }
  }

  fetchUserData() {
    return this.User.getUserData().then(
      () => {
        this.getCards();
        this.SnapshotService.fetch();
      },
      () => {
        this.info = {};
      },
    );  
  }

  fetchDimensions() {
    return this.DimensionService.fetch().then((dimensions) => {
      this.DimensionService.setAvailableGroups(dimensions, this.User.getConfig());
      this.FilterService.setup();

      const affinities = this.FilterService.getAffinities();

      this.$ngRedux.dispatch(loadAffinities(affinities));
    });
  }

  getCards() {
    return this.AudienceTypes.available.forEach((type) => {
      this.Cards.getCardsNew(type).then((res) => {
        this.onGetCardsNewSuccess(res, type);
      });
    });
  }

  onGetCardsNewSuccess(response, cardType) {
    const allowedCards = this.DimensionService.filterAvailable(
      response,
      this.User.getConfig(),
    );

    this.Cards.available[cardType] = allowedCards;
    this.cards[cardType] = response;
  }
}

export default MapViewCtrl;
