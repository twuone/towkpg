import angular from 'angular';

import MapViewConfig from './map-view.config';
import MapViewCtrl from './map-view.controller';

// Create the module where our functionality can attach to
export const MapViewModule = angular
  .module('app.mapView', [])
  .controller('MapViewCtrl', MapViewCtrl)
  .config(MapViewConfig).name;
