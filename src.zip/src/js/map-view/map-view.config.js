function MapViewConfig($stateProvider) {
  'ngInject';

  const mapViewState = {
    name: 'app.map-view',
    url: '/',
    controller: 'MapViewCtrl',
    controllerAs: '$ctrl',
    template: require('./map-view.html'),
    data: {
      title: 'Map View',
    },
    resolve: {
      auth: /* @ngInject */ (User) => User.ensureAuthIs(true),
      userData: /* @ngInject */ (User) => User.getUserData(),
      onEnter: /* @ngInject */ (Cards) => {
        Cards.showComparison = false;
        Cards.dataCardComparison = {};
        Cards.baseIdCompare = null;
      },
    },
  };

  $stateProvider.state(mapViewState);
}

export default MapViewConfig;
