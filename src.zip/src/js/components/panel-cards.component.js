import template from './panel-cards.html';

const PanelCardsComponent = {
  template,
  controller: class PanelCardsComponent {
    constructor(Cards, Filters, Markers, Tab) {
      'ngInject';

      // init private variables
      this._Cards = Cards;
      this._Filters = Filters;
      this._Markers = Markers;
      this._Tab = Tab;

      // init public variables
      this.residents = {};
      this.workers = {};
      this.visitors = {};
      this.markersInfo = [];

      this.markersData = [];
      this.isOpen = true;

      Tab.cards = 'residents';

      // call cards services on init
      // this._getCardsData(Filters.getFilters());

      // call cards services every time the filters are updated (save button is pressed)
      Filters.onChange((filters) => {
        this._getCardsData(filters);
      });
    }

    setTab(tab, index) {
      if (index === 0) {
        this._Tab.cards = tab;

        // Dispatch a resize event on every tab change
        // so D3 awakens to do any necessary redrawing
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 100);
      }
    }

    shouldShowCardCustomVars(card) {
      return (
        this.marker.guid &&
        (!card.flags ||
          this.user.info.account.config.customVars[card.flags.cnpj] ||
          this.user.info.account.config.customVars[card.flags.cpf] ||
          card.flags.unlessPresent ||
          (card.flags.mode == 'layerMode' &&
            this.Layers.activated &&
            this.marker.guid == 'layer'))
      );
    }

    isCurrentTab(tabName) {
      return this._Tab.cards === tabName;
    }

    dismissPanel(panelIndex) {
      this.markersData.splice(1, 1);
      this._Markers.splice(1, 1);

      $('#panel1').remove();

      if (panelIndex === 0) {
        $('.panel-cards').toggleClass('is-open');
      } else {
        $('#panel' + panelIndex).remove();
      }
    }

    _getCardsData(filters) {
      // setting params to be passed on the service calls
      this._Cards.setParams(this._Filters.getParams());

      this._Markers.forEach((marker, i) => {
        // init markerData to this iteration
        this.markersData[i] = {
          residents: {},
          workers: {},
          visitors: {},
        };

        this.markersInfo[i] = {
          desc: marker.desc,
          title: marker.title,
        };

        // set marker id on Cards
        this._Cards.setGuid(marker.guid);

        // Residents cards service call
        this._Cards.getCount('residents').then((data) => {
          this.markersData[i].residents.count = data;
        });

        this._Cards.getMosaic('residents').then((data) => {
          this.markersData[i].residents.mosaic = data;
        });

        this._Cards.getSocialClass('residents').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data.values,
              },
            ],
            error: data.error,
          };

          this.markersData[i].residents.socialClass = obj;
        });

        this._Cards.getGender('residents').then((data) => {
          this.markersData[i].residents.gender = data;
        });

        this._Cards.getPlaces('residents').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data,
              },
            ],
            error: data.error,
            length: data.length,
          };

          // obj.card[0].values.push({
          // 	label: "total",
          // 	value: this.markersData[i].residents.count.value
          // });

          this.markersData[i].residents.places = obj;
        });

        // Workers cards service call
        this._Cards.getCount('workers').then((data) => {
          this.markersData[i].workers.count = data;
        });

        this._Cards.getMosaic('workers').then((data) => {
          this.markersData[i].workers.mosaic = data;
        });

        this._Cards.getSocialClass('workers').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data.values,
              },
            ],
            error: data.error,
          };

          this.markersData[i].workers.socialClass = obj;
        });

        this._Cards.getGender('workers').then((data) => {
          this.markersData[i].workers.gender = data;
        });

        this._Cards.getPlaces('workers').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data,
              },
            ],
            error: data.error,
            length: data.length,
            total: this.markersData[i].workers.count,
          };
          this.markersData[i].workers.places = obj;
        });

        // Visitors cards service call
        this._Cards.getCount('visitors').then((data) => {
          this.markersData[i].visitors.count = data;
        });

        this._Cards.getMosaic('visitors').then((data) => {
          this.markersData[i].visitors.mosaic = data;
        });

        this._Cards.getSocialClass('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data.values,
              },
            ],
            error: data.error,
          };

          this.markersData[i].visitors.socialClass = obj;
        });

        this._Cards.getGender('visitors').then((data) => {
          this.markersData[i].visitors.gender = data;
        });

        this._Cards.getPlaces('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data,
              },
            ],
            error: data.error,
            length: data.length,
            total: this.markersData[i].visitors.count,
          };
          this.markersData[i].visitors.places = obj;
        });

        this._Cards.getHotDays('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data,
              },
            ],
            error: data.error,
          };

          this.markersData[i].visitors.hotDays = obj;
        });

        this._Cards.getHotHours('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data,
              },
            ],
            error: data.error,
          };

          this.markersData[i].visitors.hotHours = obj;
        });

        this._Cards.getDuration('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data.filtered,
              },
            ],
            error: data.error,
          };

          obj.raw = data.raw;

          this.markersData[i].visitors.duration = obj;
        });

        this._Cards.getDisplacementHome('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data.filtered,
              },
            ],
            error: data.error,
          };

          obj.raw = data.raw;

          this.markersData[i].visitors.displacementHome = obj;
        });

        this._Cards.getDisplacementWork('visitors').then((data) => {
          const obj = {
            card: [
              {
                key: 'Cumulative Return',
                values: data.filtered,
              },
            ],
            error: data.error,
          };

          obj.raw = data.raw;

          this.markersData[i].visitors.displacementWork = obj;
        });
      });
    }
  },
};

export default PanelCardsComponent;
