import template from './activity-indicator.html';

export const ActivityIndicatorComponent = {
  bindings: {
    data: '=',
    total: '=',
    isSerasaContext: '<',
  },
  template,
  controller: class ActivityIndicatorComponent {
    constructor() {
      'ngInject';
    }
  },
};
