import { REFRESH_USER_COUNT, NOT_COLUMN_IS_READY } from '../app.actions';

import BasesService from '../services/bases.service';
import CampaignService from '../services/campaign.service';
import CardsService from '../services/cards.service';
import DocumentsService from '../services/documents.service';
import ExportService from '../services/export.service';
import ExtractionService from '../services/extraction.service';
import ModalService from '../services/modal.service';
import { UserService } from '../services/user.service';
import { SweetAlertService } from '../services/sweet-alert.service';

/**
 * Componente de relatório do DataView, colunas usadas na comparação de base
 */
export const ReportNotColumnComponent: ng.IComponentOptions = {
  template: require('./report-not-column.html'),
  bindings: {
    base: '=',
  },
  controller: class ReportNotColumnComponent
    implements ng.IComponentController {
    private counters_are_ready: boolean;
    private counters: {
      state_city: number;
      id_household: number;
      audience: number;
    };

    constructor(
      private $rootScope: ng.IRootScopeService,
      private $scope: ng.IScope,
      private AudienceTypes,
      private Bases: BasesService,
      private Campaign: CampaignService,
      private Cards: CardsService,
      private Documents: DocumentsService,
      private Export: ExportService,
      private ExtractionService: ExtractionService,
      private Modal: ModalService,
      private SweetAlert: SweetAlertService,
      private User: UserService,
    ) {
      'ngInject';
    }

    $onInit() {
      this.counters_are_ready = false;
      this.counters = {
        state_city: 0,
        id_household: 0,
        audience: 0,
      };

      let count = 0;
      const counter = setInterval(() => {
        count++;
        if (!this.counters.state_city || isNaN(this.counters.state_city)) {
          this.recalculateCounters();
        } else {
          clearInterval(counter);
          setTimeout(() => this.$scope.$apply(), 1000);
          this.counters_are_ready = true;
        }
        if (count > 10) {
          clearInterval(counter);
          setTimeout(() => this.$scope.$apply(), 1000);
          this.counters_are_ready = true;
        }
      }, 1000);

      this.$rootScope.$on(NOT_COLUMN_IS_READY, () =>
        this.recalculateCounters(),
      );
    }

    recalculateCounters() {
      this.counters = {
        state_city: Math.abs(
          this.Bases.countersHub[0].state_city -
            this.Bases.countersHub[1].state_city,
        ),
        id_household: Math.abs(
          this.Bases.countersHub[0].id_household -
            this.Bases.countersHub[1].id_household,
        ),
        audience: Math.abs(
          this.Bases.countersHub[0].audience -
            this.Bases.countersHub[1].audience,
        ),
      };
    }

    openModalCampaignSimple(count, baseId = 'serasa') {
      if (count >= 3000) {
        const base =
          this.Bases.selection[0].id === 'serasa'
            ? this.Bases.selection[0]
            : this.Bases.selection[1];
        this.Campaign.multi = false;
        this.Campaign.setSelectedBase(base);

        this.Campaign.setOptions(
          {
            count,
          },
          true,
        );
        $('#modalCampaignSimple').modal({ show: true, backdrop: 'static' });
        this.Modal.setCurrentModal('modal-campaign-simple');
      } else {
        this.SweetAlert.error('CARDS.COUNTER.MESSAGES.AUDIENCE_BELOW_MIN');
      }
    }

    openModalRequestDocuments(userCount, baseId = null) {
      const userConfig = this.User.info.account.config;
      const selectedAudience = this.AudienceTypes.applied;

      const variablesForExtraction = this.ExtractionService.getVariablesForExtractionByUserAndAudience(
        userConfig,
        selectedAudience,
      );
      this.Documents.baseId = this.getBaseId();
      this.Documents.userCount = this.counters.audience;
      this.Documents.setOptions(
        {
          count: userCount,
          fields: variablesForExtraction,
        },
        true,
      );
      this.$rootScope.$broadcast(REFRESH_USER_COUNT);
      $('#modalRequestDocuments').modal('show');
      this.Modal.setCurrentModal('modal-request-documents');
    }

    getBaseId() {
      return this.Bases.selection[0].id === 'serasa'
        ? this.Bases.selection[1].id
        : this.Bases.selection[0].id;
    }
  },
};
