import template from './checkbox-filter.html';

export const CheckboxFilterComponent = {
  bindings: {
    dimension: '<',
    groupId: '<',
  },
  template,
  controller: class CheckboxFilterComponent {
    /* @ngInject */
    constructor(AudienceTypes, FilterService) {
      this.AudienceTypes = AudienceTypes;
      this.FilterService = FilterService;
    }

    $onInit() {
      this.setModel(this.groupId, this.dimension.id);
    }

    setModel(groupId, dimensionId) {
      this.model = this.FilterService.availableGroups[groupId].dimensions[
        this.AudienceTypes.selected
      ][dimensionId].values;
    }

    selectAll() {
      Object.keys(this.model).forEach((key) => {
        this.model[key] = true;
      });
    }

    unselectAll() {
      Object.keys(this.model).forEach((key) => {
        this.model[key] = false;
      });
    }

    invertSelection() {
      Object.keys(this.model).forEach((key) => {
        this.model[key] = !this.model[key];
      });
    }
  },
};
