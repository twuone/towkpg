import {
  CHANGE_BOUNDS,
  CHANGE_LAYER_MODE,
  CLEAN_MAP_DATA,
  FINISH_MAP_LOADING,  
  LOAD_LAYER_SELECTION,
  REMOVE_MAP_EVENTS_OF_THEMES,
  RESET_NOT_PANEL_COMPLETELY,
  SELECT_BY_LAYER,
  SELECT_BY_SUBLAYER,
  STYLIZE_MAP,
} from '../app.actions';
import template from './google-maps.html';

export const GoogleMapsComponent = {
  template,
  controller: class GoogleMapsComponent {
    constructor(
      $injector,
      $log,
      $rootScope,
      $scope,
      $transitions,
      $translate,
      AudienceTypes,
      Bases,
      Cards,
      Filters,
      HeatMap,
      Layers,
      MapValues,
      Markers,
      Modal,
      NgMap,
      PanelStateService,
      Places,
      SweetAlert,
      Tab,
      User,
    ) {
      'ngInject';

      this.$injector = $injector;
      this.$log = $log;
      this.$rootScope = $rootScope;
      this.$scope = $scope;
      this.$transitions = $transitions;
      this.$translate = $translate;
      this.AudienceTypes = AudienceTypes;
      this.Bases = Bases;
      this.Cards = Cards;
      this.HeatMap = HeatMap;
      this.Layers = Layers;
      this.MapValues = MapValues;
      this.Markers = Markers;
      this.Modal = Modal;
      this.NgMap = NgMap;
      this.PanelStateService = PanelStateService;
      this.Places = Places;
      this.SweetAlert = SweetAlert;
      this.Tab = Tab;
      this.User = User;

      this.partialLayer = null;
      this.timerToMapLayerReload = null;

      // init public variables
      this.filters = Filters.filters;
      this.center = Markers.primary.center;
      this.centerMap = MapValues.center;
      this.filterPlaces = null;
      this.dragendEvent = null;
      this.zoomChangeEvent = null;
      this.lockCluster = false;

      // HeatMap
      this.$scope.heatMapData = []; // heatmap-layer need this to be initilized like this (in $scope)
      this.isHeatmapEnabled = false;
      this.isHeatMapLoading = false;
      this.isHeatMapMenuOpen = false;
      this.isClusuredActive = false;

      this.infowindow = new google.maps.InfoWindow();

      this.currentOptions = {
        type: null,
        source: null,
      };

      this.state = {};

      // Other Layers
      this.isBicycleMapEnabled = false;
      this.isTrafficMapEnabled = false;
      this.isTransitMapEnabled = false;
    }

    $onInit() {
      const $ctrl = this;

      // get the instance of map
      this.NgMap.getMap('map').then((map) => {
        this.map = map;
        Object.keys(this.map.bicyclingLayers).map((key) =>
          this.map.bicyclingLayers[key].setMap(null),
        );
        Object.keys(this.map.transitLayers).map((key) =>
          this.map.transitLayers[key].setMap(null),
        );
        this.map.trafficLayers.trafficLayer.setMap(null);
        $ctrl.currentBounds = $ctrl.formatBounds(map.getBounds());
        this.map.addListener(CHANGE_BOUNDS, $ctrl.refreshMap);
        this.map.data.setStyle(() => {
          const color = '#ba2f7d';
          return {
            fillColor: color,
            strokeColor: color,
            strokeWeight: 1,
          };
        });
        this.clickEvent = this.map.data.addListener('click', this.selectLayer);
        this.idleMap = google.maps.event.addListener(
          this.map,
          'zoom_changed',
          this.releaseMap,
        );
      });

      /* =======================================
                    EVENT HANDLES
      ======================================= */
      this.$rootScope.$on(SELECT_BY_LAYER, (e, data) =>
        this.getDataForLayerItem(e, data),
      );

      this.$rootScope.$on(SELECT_BY_SUBLAYER, (e, data) =>
        this.getDataForSubLayerItem(e, data),
      );

      this.$rootScope.$on(LOAD_LAYER_SELECTION, () => {
        this.Bases.applySelection();
        $('.panel-cards').addClass('is-open');
      });

      this.$rootScope.$on(CHANGE_LAYER_MODE, () => {
        if (!this.Layers.activated) {
          this.cleanTheWholeMap();
        }
      });

      this.$rootScope.$on(CLEAN_MAP_DATA, () => this.cleanTheWholeMap());

      this.$transitions.onSuccess({}, () => {
        google.maps.event.removeListener(this.clickEvent);
      });

      this.$rootScope.$on(REMOVE_MAP_EVENTS_OF_THEMES, () => {
        google.maps.event.removeListener(this.clickEvent);
        google.maps.event.removeListener(this.mouseOverEvent);
        google.maps.event.removeListener(this.mouseOutEvent);
        this.clickEvent = this.map.data.addListener('click', this.selectLayer);
      });

      this.$rootScope.$on(STYLIZE_MAP, (evt, preserve) => {
        google.maps.event.removeListener(this.mouseOverEvent);
        google.maps.event.removeListener(this.mouseOutEvent);
        if (!preserve) {
          this.cleanTheWholeMap();
        } else {
          this.map.data.revertStyle();
          return;
        }

        /* Set Colors and Tooltips
        -------------------------- */
        let attempts = 0;
        const timerToSync = setInterval(() => {
          try {
            attempts++;
            if (this.map.data) {
              clearInterval(timerToSync);
              const latlngbounds = new google.maps.LatLngBounds();

              this.map.data.forEach((mapDataFeature) => {
                const propsMetadata = mapDataFeature.getProperty('metadata');

                latlngbounds.extend({
                  lat: mapDataFeature.getProperty('centroid').lon,
                  lng: mapDataFeature.getProperty('centroid').lat,
                });

                // Tooltip Text (format)
                let contentString = '<table><tbody>';
                Object.keys(propsMetadata).map((key) => {
                  const str = propsMetadata[key]
                    .toString()
                    .replace(/\s+/g, ' ')
                    .trim();
                  contentString +=
                    '<tr>' +
                    '<td style="padding:0 7px 0 0; text-align: right">' +
                    `<strong>${key}</strong>` +
                    '</td>' +
                    `<td>${str}</td>` +
                    '</tr>';
                });
                contentString += '</tbody></table>';
                mapDataFeature.setProperty(
                  'toolTipCentroid',
                  this.findCenterAndNavigate(mapDataFeature, true),
                );
                mapDataFeature.setProperty('tooltipText', contentString);
              });

              this.mouseOverEvent = this.map.data.addListener(
                'mouseover',
                (event) => {
                  const centroid = event.feature.getProperty('toolTipCentroid');
                  this.infowindow.setContent(
                    event.feature.getProperty('tooltipText'),
                  );
                  this.infowindow.setPosition({
                    lat: centroid[0],
                    lng: centroid[1],
                  });
                  this.infowindow.open(this.map);
                },
              );

              this.mouseOutEvent = this.map.data.addListener('mouseout', () => {
                if (this.infowindow) {
                  this.infowindow.close(this.map);
                }
              });

              this.clickEvent = this.map.data.addListener('click', (event) => {
                this.Cards.layerMode = true;

                /* Count points for this particular Shape
                ----------------------------------------- */
                let countShapes = 0;
                event.feature.getGeometry().forEachLatLng(() => {
                  countShapes++;
                });

                /* Reset Layers selection
                ------------------------- */
                this.Layers.selection = {
                  coordinates: [],
                };
                event.feature.getGeometry().forEachLatLng((latLong) => {
                  this.Layers.selection.coordinates.push([
                    latLong.lng(),
                    latLong.lat(),
                  ]);
                });

                let attemptsReq = 0;
                const timerToSyncReq = setInterval(() => {
                  try {
                    attemptsReq++;
                    if (
                      this.Layers.selection.coordinates.length == countShapes
                    ) {
                      clearInterval(timerToSyncReq);
                      this.Bases.applySelection();
                      $('.panel-cards').addClass('is-open');
                      this.releaseMap();
                      this.$scope.$apply();
                    }
                    if (attemptsReq >= 10) {
                      clearInterval(timerToSyncReq);
                      this.releaseMap();
                    }
                  } catch (err) {
                    clearInterval(timerToSyncReq);
                    this.releaseMap();
                  }
                }, 250);
              });

              if (!preserve) {
                this.map.fitBounds(latlngbounds);
              }
            } else if (this.attempts >= 10 || this.attempts == undefined) {
              clearInterval(timerToSync);
            }
          } catch (err) {
            clearInterval(timerToSync);
          }
        }, 200);
      });

      this.$rootScope.$on(FINISH_MAP_LOADING, () => {
        let mapFinishedLoadingAttempts = 0;
        let counter = 0;
        const sync = setInterval(() => {
          // - Determine Data length - //
          mapFinishedLoadingAttempts++;
          this.map.data.forEach(() => counter++);
          if (counter) {
            this.$rootScope.$broadcast(REMOVE_MAP_EVENTS_OF_THEMES);
            clearInterval(sync);
            if (this.map.data) {
              let counter = 0;
              this.map.data.forEach(() => {
                counter++;
              });

              const positions = [];
              this.map.data.forEach((mapDataFeature) => {
                const val = $ctrl.findCenterAndNavigate(mapDataFeature, true);
                positions.push(
                  $ctrl.findCenterAndNavigate(mapDataFeature, true),
                );
              });
              const clock = setInterval(() => {
                if (counter <= positions.length) {
                  clearInterval(sync);
                  clearInterval(clock);
                  this.centralizeIbgePolygon(positions);
                }
              }, 1000);
            }
          } else {
            this.mapSignal();
          }
        }, 1000);
      });

      /* === END OF EVENT HANDLES === */
      this.initCoord = () => {
        return [this.centerMap.lat, this.centerMap.lng];
      };

      this.mapSignal = () => {
        this.map.setCenter(
          new google.maps.LatLng(
            this.map.getCenter().lat(),
            this.map.getCenter().lng() + 0.000000001,
          ),
        );
      };

      this.centralizeIbgePolygon = (positions) => {
        /* --------------------------
           Find Centroid And Navigate
        ----------------------------- */
        let latAggreg = 0;
        let lngAggreg = 0;

        for (let i = 0; i < positions.length; i++) {
          latAggreg += positions[i][0];
          lngAggreg += positions[i][1];
        }

        if (
          !isNaN(latAggreg / positions.length) ||
          !isNaN(lngAggreg / positions.length)
        ) {
          $ctrl.navigateToLatLong(
            latAggreg / positions.length,
            lngAggreg / positions.length,
          );
        } else {
          // fallback for async problem: Brasil Center
          if (this.Layers.lastSelectedType == 'country') {
            $ctrl.navigateToLatLong(-12.393181, -48.388712);
          } else {
            // ELSE: do nothing... Just release Map
            this.map.setCenter(
              new google.maps.LatLng(
                this.map.getCenter().lat(),
                this.map.getCenter().lng() + 0.000000001,
              ),
            );
          }
        }

        // Apply theme on drilldown
        if (
          this.state.themeSelection &&
          this.AudienceTypes.applied === this.AudienceTypes.previous
        ) {
          this.fillColorTheme(this.state.themeSelection);
        }
      };

      let countMapInitTimer = 0;
      const mapInitTimer = setInterval(() => {
        countMapInitTimer++;
        if (countMapInitTimer >= 5) {
          if (
            this.MapValues.center.lat == 0 ||
            this.MapValues.center.lng == 0
          ) {
            this.MapValues.center = {
              lat: -23.5505199,
              lng: -46.6333094,
            }; // SP Zero Point as Fallback
            $ctrl.navigateToLatLong(-23.5505199, -46.6333094);
            clearInterval(mapInitTimer);
          }
        }
      }, 1000);

      this.releaseMap = () => {
        if (
          !(this.MapValues.center.lat == 0 && this.MapValues.center.lng == 0)
        ) {
          this.changeCenter();
        }
        this.Layers.status = 'finished';
        this.$scope.$apply();
      };

      this.lockMap = () => {
        this.Layers.status = 'busy';
        this.$scope.$apply();
      };

      this.cleanTheWholeMap = () => {
        let counter = 0;
        this.map.data.forEach(() => counter++);
        let compareLength = 0;
        this.map.data.forEach((item) => {
          compareLength++;
          this.map.data.remove(item);
          if (counter <= compareLength) {
            this.Layers.IsMapClear = true;
          }
        });
      };

      this.formatBounds = (bounds) => {
        // determine map bounds
        const swPoint = bounds.getSouthWest();
        const nePoint = bounds.getNorthEast();

        // lat bounds
        const maxLat = Math.max(swPoint.lat(), nePoint.lat());
        const minLat = Math.min(swPoint.lat(), nePoint.lat());

        // lng bounds
        const maxLng = Math.max(swPoint.lng(), nePoint.lng());
        const minLng = Math.min(swPoint.lng(), nePoint.lng());

        return {
          maxLat,
          minLat,
          maxLng,
          minLng,
        };
      };

      this.getDataForLayerItem = (e, data) => {
        this.map.data.forEach((mapDataFeature) => {
          const compLabel = mapDataFeature.getProperty('UF')
            ? 'UF'
            : 'MUNICIPIO';
          if (
            data.name.toUpperCase() ===
            mapDataFeature.getProperty(compLabel).toUpperCase()
          ) {
            $ctrl.findCenterAndNavigate(mapDataFeature);
          }
        });
      };

      this.getDataForSubLayerItem = (evt, data, map) => {
        const layerInfo = $ctrl.extractInfoFromLayer(data.feature.properties);
        this.findSelectedPolygonAndMarkIt(layerInfo.layerTitle);
      };

      /* this method need to be implemented like this because it's passed to the ngMap,
      so 'this' will be a reference to the ngMaps's scope.
      Marker need to be clusured to the function, then ngMap will be able to access it from it's scope. */
      this.selectMarker = function($event, place) {
        $ctrl.Bases.applySelection();
        $('.panel-cards').addClass('is-open');
        $ctrl.Markers.compare.guid = null;
        $ctrl.Cards.layerMode = false;
        $ctrl.Markers.primary.guid = place.id;
        $ctrl.Markers.primary.title = place.title;
        $ctrl.Markers.primary.desc = place.desc;
        $ctrl.AudienceTypes.previous = $ctrl.AudienceTypes.applied;
        $ctrl.AudienceTypes.applied = $ctrl.Tab.cards;

        if (place.points.length <= 1) {
          $ctrl.Markers.primary.type = 'place';
          $ctrl.Markers.primary.center.lat = place.points[0].latitude;
          $ctrl.Markers.primary.center.lng = place.points[0].longitude;
        } else {
          $ctrl.Markers.primary.type = 'polygon';
        }

        // COMBAK: Consolidate this into function. It has many repetition of same code
        if ($ctrl.Bases.applied[1].id) {
          $ctrl.Markers.compare.guid = $ctrl.Markers.primary.guid;
          $ctrl.Markers.compare.desc = $ctrl.Markers.primary.desc;
          $ctrl.Markers.compare.title = $ctrl.Markers.primary.title;

          if (
            $ctrl.Markers.primary.points &&
            $ctrl.Markers.primary.points.length <= 1
          ) {
            $ctrl.Markers.compare.center.lat =
              $ctrl.Markers.primary.points[0].latitude;
            $ctrl.Markers.compare.center.lng =
              $ctrl.Markers.primary.points[0].longitude;
          }
        }
      };

      this.findSelectedPolygonAndMarkIt = (name) => {
        // this.map.data.revertStyle();
        this.map.data.forEach((mapDataFeature) => {
          if (
            name.toUpperCase() ===
            mapDataFeature.getProperty('metadata').NAME.toUpperCase()
          ) {
            // this.map.data.overrideStyle(data_frag, {strokeWeight: 2, fillOpacity: 0.7});
            $ctrl.findCenterAndNavigate(mapDataFeature);
            this.map.setZoom(this.Layers.zoomLevelLayer.neighborhood + 2);
            this.releaseMap();
          }
        });
      };

      this.selectLayer = function(event, byCombo) {
        $ctrl.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
        $ctrl.Markers.compare.guid = null;
        $ctrl.lockMap();
        $ctrl.Cards.layerMode = true;
        let obj = null;

        if ($ctrl.Layers.selection.cep) {
          delete $ctrl.Layers.selection.cep;
        }
        if ($ctrl.Layers.selection.sector_code) {
          delete $ctrl.Layers.selection.sector_code;
        }
        if ($ctrl.Layers.selection.ibge_query) {
          delete $ctrl.Layers.selection.ibge_query;
        }

        obj = byCombo ? event.feature.properties : event.feature.f;

        const layerInfo = $ctrl.extractInfoFromLayer(obj);

        if (obj.metadata.MUNICIPIO) {
          $ctrl.Layers.selection[layerInfo.layerType] = layerInfo.layerTitle;
          $ctrl.Layers.reloadNextFields(2, false);
        } else if (obj.metadata.UF) {
          $ctrl.Layers.selection[layerInfo.layerType] = layerInfo.layerTitle;
          $ctrl.Layers.reloadNextFields(1, false);
        } else if (obj.metadata.NAME) {
          // ---- Sub Layers Logic ----------------
          $ctrl.Layers.selection[layerInfo.layerType] = layerInfo.layerTitle;
        } else if (obj.metadata.CEP5) {
          $ctrl.Layers.selection.cep = layerInfo.layerTitle;
        } else if (obj.metadata.COD_SETOR) {
          $ctrl.Layers.selection.sector_code = layerInfo.layerTitle;
        }

        if (obj.CEP5 || obj.COD_SETOR) {
          delete $ctrl.Layers.selection.neighborhood;
        }

        $ctrl.Markers.primary.guid = 'layer';
        $ctrl.Markers.primary.title = layerInfo.layerTitle;
        $ctrl.Markers.primary.desc = layerInfo.layerType
          ? $ctrl.$translate.instant(
              `COMPONENTS.MAP.LAYERS.TYPES.${layerInfo.layerType.toUpperCase()}`,
            )
          : $ctrl.Layers.lastSelectedValue;

        if ($ctrl.Layers.selection.neighborhood) {
          $ctrl.findSelectedPolygonAndMarkIt(obj.metadata.NAME);
        }

        $ctrl.AudienceTypes.previous = $ctrl.AudienceTypes.applied;
        $ctrl.AudienceTypes.applied = $ctrl.Tab.cards;

        // COMBAK: Consolidate $ctrl into function.
        // It has many repetition of same code
        if ($ctrl.Bases.selection[1].id) {
          $ctrl.Markers.compare.guid = $ctrl.Markers.primary.guid;
          $ctrl.Markers.compare.desc = $ctrl.Markers.primary.desc;
          $ctrl.Markers.compare.title = $ctrl.Markers.primary.title;

          if (
            $ctrl.Markers.primary.points &&
            $ctrl.Markers.primary.points.length <= 1
          ) {
            $ctrl.Markers.compare.center.lat =
              $ctrl.Markers.primary.points[0].latitude;
            $ctrl.Markers.compare.center.lng =
              $ctrl.Markers.primary.points[0].longitude;
          }
        }
        $ctrl.Bases.applySelection();
        $('.panel-cards').addClass('is-open');
      };

      this.findCenterAndNavigate = (polygon, returnValue) => {
        let count = 0;
        let latAggreg = 0;
        let lngAggreg = 0;
        polygon.getGeometry().forEachLatLng((latLong) => {
          count++;
          latAggreg += latLong.lat();
          lngAggreg += latLong.lng();
        });
        if (returnValue) {
          return [latAggreg / count, lngAggreg / count];
        } else {
          this.navigateToLatLong(latAggreg / count, lngAggreg / count);
        }

        google.maps.event.trigger(this.map, 'resize');
      };

      this.extractInfoFromLayer = (obj) => {
        let layerTitle = '';
        let layerType = '';

        if (obj.metadata.MUNICIPIO) {
          layerTitle = obj.metadata.MUNICIPIO.toLowerCase();
          layerType = 'city';
        } else if (obj.metadata.UF) {
          layerTitle = obj.metadata.UF.toLowerCase();
          layerType = 'state';
        } else if (obj.metadata.NAME) {
          // ---- Sub Layers Logic ---- //
          layerType = 'neighborhood';
          layerTitle = obj.metadata.NAME.toLowerCase();
        } else if (obj.metadata.CEP5) {
          layerType = 'CEP5';
          layerTitle = obj.metadata.CEP5;
        } else if (obj.metadata.COD_SETOR) {
          layerType = 'COD_SETOR';
          layerTitle = obj.metadata.COD_SETOR;
        }
        return {
          layerType,
          layerTitle,
        };
      };

      /*
      This method need to be implemented like this because it's passed to the ngMap,
      so 'this' will be a reference to the ngMaps's scope.
      Marker need to be clusured to the function, then ngMap will be able to access it from it's scope.
      */
      this.finishDrawPolygon = function(event) {
        let points;
        if (event.type === 'polygon') {
          const polygonPath = event.overlay.getPath().getArray();
          points = polygonPath.map((path) => {
            return {
              latitude: path.lat(),
              longitude: path.lng(),
            };
          });
        } else {
          const bounds = event.overlay.getBounds();
          const northEast = bounds.getNorthEast();
          const southWest = bounds.getSouthWest();
          points = [
            {
              latitude: northEast.lat(),
              longitude: northEast.lng(),
            },
            {
              latitude: southWest.lat(),
              longitude: northEast.lng(),
            },
            {
              latitude: southWest.lat(),
              longitude: southWest.lng(),
            },
            {
              latitude: northEast.lat(),
              longitude: southWest.lng(),
            },
          ];
        }

        let minLat = 90;
        let maxLat = -90;
        let minLng = 180;
        let maxLng = -180;
        for (const key in points) {
          if (points[key].latitude > maxLat) {
            maxLat = points[key].latitude;
          }

          if (points[key].latitude < minLat) {
            minLat = points[key].latitude;
          }

          if (points[key].longitude > maxLng) {
            maxLng = points[key].longitude;
          }

          if (points[key].longitude < minLng) {
            minLng = points[key].longitude;
          }
        }

        if (
          $ctrl.Places.places.length >=
          $ctrl.User.info.user.currentInvoice.total_markers_qty
        ) {
          $ctrl.SweetAlert.error(
            'COMPONENTS.MAP.MESSAGES.POLYGON_LIMIT_EXCEEDED',
          );
          event.overlay.setMap(null);
          return;
        }

        if (maxLat - minLat > 0.02 || maxLng - minLng > 0.02) {
          $ctrl.SweetAlert.error('COMPONENTS.MAP.MESSAGES.POLYGON_TOO_BIG');
          event.overlay.setMap(null);
          return;
        }

        $ctrl.Modal.setPolygon({
          points,
          event,
        });

        $ctrl.map.mapDrawingManager[0].setDrawingMode(null);
        $('#newPolygonModal').modal('show');
      };

      this.changeCenter = () => {
        if (this.map) {
          this.MapValues.center.lat = this.map.getCenter().lat();
          this.MapValues.center.lng = this.map.getCenter().lng();
        }
      };

      this.Places.getCurrentLocation().then((coordinates) => {
        this.MapValues.center.lat = coordinates.latitude;
        this.MapValues.center.lng = coordinates.longitude;
        this.$scope.$apply();
      });

      this.getPlaceIcon = (glyph, color) => {
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 30;
        const ctx = canvas.getContext('2d');

        ctx.beginPath();
        if (color) {
          ctx.fillStyle = color;
          ctx.strokeStyle = color;
        }
        ctx.arc(15, 15, 14, 0, 2 * Math.PI, false);
        ctx.fill();
        ctx.closePath();

        ctx.beginPath();
        ctx.fillStyle = 'white';
        ctx.strokeStyle = 'white';
        ctx.font = '18px Material Icons';
        ctx.fillText(glyph, 6, 24);
        ctx.arc(15, 15, 14, 0, 2 * Math.PI, false);
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.closePath();

        return canvas.toDataURL();
      };

      // Place Markers
      this.markerCluster;
      this.placeService = null;

      this.removeClusteredMarkers = () => {
        if (this.markerCluster) {
          this.markerCluster.clearMarkers();
        }
      };

      this.clusteredPlaces = (filterPlaces, refreshOnly = false) => {
        if (this.lockCluster || filterPlaces.length == 0) {
          return;
        } else {
          this.lockCluster = true;
        }

        if (!refreshOnly) {
          this.placeService = new google.maps.places.PlacesService(this.map);
          this.dragendEvent = this.map.addListener('dragend', () =>
            this.refreshMarkerCluster(this.filterPlaces, true),
          );
          this.zoomChangeEvent = this.map.addListener('zoom_changed', () =>
            this.refreshMarkerCluster(this.filterPlaces, true),
          );
          this.filterPlaces = filterPlaces;
        }
        this.removeClusteredMarkers();
        let maxZoom = 20;

        const maxZoomService = new google.maps.MaxZoomService();
        maxZoomService.getMaxZoomAtLatLng(this.map.getCenter(), (response) => {
          if (response.status == 'OK') {
            maxZoom = response.zoom;
          }
        });

        const infoWindow = new google.maps.InfoWindow();
        const zoomLevel = this.map.getZoom();
        const invertedZoom = maxZoom - zoomLevel;
        const radiusCalc =
          Math.pow(2, invertedZoom) * Math.pow(2, invertedZoom) + 1000; // (100 * (invertedZoom * invertedZoom)) + 100;

        // build resquest to google maps radar search
        const request = {
          location: this.map.getCenter(),
          radius: radiusCalc,
          type: this.filterPlaces,
        };

        this.placeService.radarSearch(request, (results, status) => {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            const markers = results.map(function(place, i) {
              const m = new google.maps.Marker({
                position: place.geometry.location,
                place: {
                  placeId: place.place_id,
                  location: place.geometry.location,
                },
              });

              google.maps.event.addListener(m, 'click', () => {
                this.placeService.getDetails(place, (result, status) => {
                  if (status !== google.maps.places.PlacesServiceStatus.OK) {
                    this.$log.error(status);
                    return;
                  }
                  infoWindow.setContent(result.name);
                  infoWindow.open(this.placeService, m);
                });
              });
              return m;
            }, this);

            this.markerCluster = new MarkerClusterer(this.map, markers, {
              maxZoom: 17,
              imagePath:
                'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m',
            });
          }
          this.lockCluster = false;
        });

        $('#modalClusteredPlacesFilter').modal('hide');
      };

      this.refreshMap = () => {
        this.currentBounds = this.formatBounds(this.map.getBounds());
        this.$scope.$apply();
      };

      this.refreshMarkerCluster = () => {
        this.clusteredPlaces(this.filterPlaces, true);
      };

      this.hideFilterOptions = () => {
        this.isClusuredActive = false;
      };

      this.toogleFiltersClusterOptions = () => {
        this.isClusuredActive = !this.isClusuredActive;
        if (this.isClusuredActive) {
          $('#modalClusteredPlacesFilter').modal('show');
        } else {
          if (this.dragendEvent) {
            google.maps.event.removeListener(this.dragendEvent);
          }
          if (this.zoomChangeEvent) {
            google.maps.event.removeListener(this.zoomChangeEvent);
          }
          $('#modalClusteredPlacesFilter').modal('hide');
          this.removeClusteredMarkers();
        }
      };

      this.navigateToLatLong = (latitude, longitude) => {
        this.map.setCenter(
          new google.maps.LatLng(latitude.toFixed(5), longitude.toFixed(5)),
        );
        this.MapValues.center.lat = latitude.toFixed(5);
        this.MapValues.center.lng = longitude.toFixed(5);
        if (this.Layers.activated && !this.Layers.selection.neighborhood) {
          /* The validation above !this.Layers.selection.neighborhood is necessary because, strangely,
          when we call this.map.setZoom()  it break up all click event binding for all polygons */
          if (
            !this.Layers.currentLayer &&
            !this.Layers.selection.neighborhood
          ) {
            this.map.setZoom(4);
            this.releaseMap();
          } else if ( 
            this.Layers.zoomLevelLayer[this.Layers.currentLayer] !=
            this.map.getZoom()
          ) {
            this.map.setZoom(
              this.Layers.zoomLevelLayer[this.Layers.currentLayer],
            );
            this.releaseMap();
          }
        }
      };

      this.getMyCurrentLocation = () => {
        this.Places.getCurrentLocation().then((coordinates) => {
          this.MapValues.center.lat = coordinates.latitude;
          this.MapValues.center.lng = coordinates.longitude;
          this.$scope.$apply();
        });
      };

      // Força um redraw do mapa quando um panel muda de estado
      this.$scope.$watch('$ctrl.PanelStateService.menuFilters.isOpen', () => {
        setTimeout(() => {
          window.dispatchEvent(new Event('resize'));
        }, 50);
      });
    };

    randomColorScale(qty = 1) {
      const colorScale = d3.scale
        .linear()
        .domain([1, qty])
        .interpolate(d3.interpolateHcl)
        .range([d3.rgb('#FFF500'), d3.rgb('#007AFF')]);

      return colorScale;
    }

    lightenDarkenColor(col, amt) {
      let usePound = false;

      if (col[0] == '#') {
        col = col.slice(1);
        usePound = true;
      }

      const num = parseInt(col, 16);

      let r = (num >> 16) + amt;

      if (r > 255) {
        r = 255;
      } else if (r < 0) {
        r = 0;
      }

      let b = ((num >> 8) & 0x00ff) + amt;

      if (b > 255) {
        b = 255;
      } else if (b < 0) {
        b = 0;
      }

      let g = (num & 0x0000ff) + amt;

      if (g > 255) {
        g = 255;
      } else if (g < 0) {
        g = 0;
      }

      return (usePound ? '#' : '') + (g | (b << 8) | (r << 16)).toString(16);
    }

    getVarLength(constName = 'NONE') {
      constName = constName.toUpperCase();
      return this.$injector.has(constName)
        ? Object.keys(this.$injector.get(constName)).length
        : 5;
    }

    fillColorTheme(constant) {
      let key = constant
        .toLowerCase()
        .replace('/', '')
        .replace('-', '_');

      if (!this.state.themeSelection || this.state.themeSelection != constant) {
        this.state.themeSelection = constant;
      }

      if (key == 'cnae_group') {
        key = 'cnae_2';
      }
      if (key == 'operability_index') {
        key = 'operability_index_desc';
      }
      if (key == 'company_credit_risk') {
        key = 'credit_risk';
      }

      const audience = this.AudienceTypes.selected;
      let max = 0;

      this.map.data.forEach((mapDataFeature) => {
        const propsAudience = mapDataFeature.getProperty(audience);

        if (propsAudience && propsAudience[key]) {
          max =
            propsAudience[key].percentage > max
              ? propsAudience[key].percentage
              : max;
        }
      });

      let color;
      const colorMap = {};
      const colorRange = this.randomColorScale(this.getVarLength(key));
      let colorCount = 1;

      this.map.data.forEach((mapDataFeature) => {
        const propsAudience = mapDataFeature.getProperty(audience);
        const propsMetadata = mapDataFeature.getProperty('metadata');

        // COLOR //
        if (!propsAudience || !propsAudience[key]) {
          this.map.data.overrideStyle(mapDataFeature, {
            fillOpacity: 0.5,
            fillColor: '#000000',
            strokeColor: '#000000',
          });
        } else if (
          propsAudience[key].value == true.toString() ||
          propsAudience[key].value == true
        ) {
          const opacity = propsAudience[key].percentage / max;

          this.map.data.overrideStyle(mapDataFeature, {
            fillOpacity: opacity * 0.9,
            fillColor: '#ba2f7d',
            strokeColor: '#ba2f7d',
          });
        } else {
          if (key == 'mosaic') {
            switch (propsAudience[key].value.charAt(0)) {
              case 'a':
                color = '#4C4686';
                break;
              case 'b':
                color = '#2A616E';
                break;
              case 'c':
                color = '#53ABA3';
                break;
              case 'd':
                color = '#8A3235';
                break;
              case 'e':
                color = '#D0BD30';
                break;
              case 'f':
                color = '#8D8A82';
                break;
              case 'g':
                color = '#9B3480';
                break;
              case 'h':
                color = '#C47030';
                break;
              case 'i':
                color = '#6EC03A';
                break;
              case 'j':
                color = '#785A43';
                break;
              case 'k':
                color = '#006845';
                break;
              default:
                color = '#333'; // Worst color in case of error
            }
          } else if (key == 'mosaic_pj') {
            switch (propsAudience[key].value.charAt(0)) {
              case 'a':
                color = '#22498e';
                break;
              case 'b':
                color = '#461f56';
                break;
              case 'c':
                color = '#b83885';
                break;
              case 'd':
                color = '#b83885';
                break;
              case 'e':
                color = '#cd2049';
                break;
              case 'f':
                color = '#1087a6';
                break;
              case 'g':
                color = '#f49045';
                break;
              default:
                color = '#333'; // Worst color in case of error
            }
          } else {
            if (!colorMap[key]) {
              colorMap[key] = {};
            }

            if (!colorMap[key][propsAudience[key].value]) {
              colorMap[key][propsAudience[key].value] = colorRange(
                Object.keys(colorMap[key]).length,
              );
            }

            colorCount++;
            color = colorMap[key][propsAudience[key].value];
          }

          this.map.data.overrideStyle(mapDataFeature, {
            fillOpacity: 0.75,
            fillColor: color,
            strokeColor: this.lightenDarkenColor(color, -60),
          });
        }

        mapDataFeature.setProperty(
          'toolTipCentroid',
          this.findCenterAndNavigate(mapDataFeature, true),
        );

        const tooltipRender = (
          title,
          segment,
          value,
          binary = false,
          tooltipName,
        ) => {
          if (tooltipName == undefined) {
            tooltipName = '';
          } else {
            tooltipName += ' - ';
          }

          if (segment === 'NO_DATA') {
            return `<strong>${tooltipName}${title}</strong>
                    <hr style="margin: 10px 0; opacity:0.6;">
                    ${this.$translate.instant(
                      'COMPONENTS.MAP.MESSAGES.NO_DATA',
                    )}`;
          } else if (binary) {
            return `<strong>${tooltipName}${title}</strong>
                  <hr style="margin: 10px 0; opacity:0.6;">
                  <strong>${segment}:</strong> ${value}%`;
          }
          return `<strong>${tooltipName}${title}</strong>
                  <hr style="margin: 10px 0; opacity:0.6;">
                  <strong>${segment}</strong>
                  <br>
                  ${this.$translate.instant(
                    'COMPONENTS.MAP.MESSAGES.TOOLTIP_PREDOMINANT',
                  )} ${value}%`;
        };

        let tooltip;
        let segment;
        let value;
        let binary;
        const title = this.$translate.instant('CARDS.' + constant + '.TITLE');

        if (propsAudience && propsAudience[key]) {
          if (propsAudience[key].value === 'true') {
            segment = this.$translate.instant(
              'CARDS.' +
                constant +
                '.VALUES.' +
                propsAudience[key].value.toUpperCase(),
            );
            binary = true;
          } else {
            segment = this.$translate.instant(
              'CARDS.' +
                constant +
                '.VALUES.' +
                this.$injector.get(constant)[propsAudience[key].value],
            );
          }

          value = (propsAudience[key].percentage * 100).toFixed(2);
        } else {
          segment = 'NO_DATA';
        }

        mapDataFeature.setProperty(
          'tooltipText',
          tooltipRender(
            title,
            segment,
            value,
            binary,
            propsMetadata.tooltip_name,
          ),
        );
      });

      this.mouseOverEvent = this.map.data.addListener('mouseover', (event) => {
        const centroid = event.feature.getProperty('toolTipCentroid');
        this.infowindow.setContent(event.feature.getProperty('tooltipText'));
        this.infowindow.setPosition({
          lat: centroid[0],
          lng: centroid[1],
        });
        this.infowindow.open(this.map);
      });

      this.mouseOutEvent = this.map.data.addListener('mouseout', (event) => {
        if (this.infowindow) {
          this.infowindow.close(this.map);
        }
      });
    }

    getPolygon(place) {
      if (place.points.length > 1) {
        return place.points.map((point) => {
          return [point.latitude, point.longitude];
        });
      }
    }

    getMarkerColor(place) {
      return place.decorator && place.decorator.color
        ? place.decorator.color.toLowerCase()
        : 'f7584c';
    }

    getMarkerIcon(place) {
      const marker = {
        path:
          'M 7,13.5 A 2.5,2.5 0 0 1 4.5,11 2.5,2.5 0 0 1 7,8.5000004 2.5,2.5 0 0 1 9.5000001,11 2.5,2.5 0 0 1 7,13.5 M 7,4.0000004 A 7,7 0 0 0 0,11 c 0,5.25 7,13 7,13 0,0 7,-7.75 7,-13 A 7,7 0 0 0 7,4.0000004 Z',
        fillColor: '#' + this.getMarkerColor(place),
        strokeColor: '#000000',
        strokeOpacity: '0.4',
        fillOpacity: 1,
        anchor: [7, 22],
        strokeWeight: 1,
        scale: 1.7,
      };

      return marker;
    }

    toggleGridHeatMap(type) {
      const entity = type == 'visitors' ? 'device' : 'data';

      if (type === this.currentOptions.type) {
        this.destroyHeatMap();
        this.currentOptions.type = null;
      } else {
        this.generateHeatMap(type, undefined, undefined, entity).then(() => {
          this.currentOptions.type = type;
          this.currentOptions.source = null;
        });
      }
    }

    toggleMarkerHeatMap(source, entity) {
      if (source === this.currentOptions.source) {
        this.destroyHeatMap();
        this.currentOptions.source = null;
      } else {
        if (this.Markers.primary.guid) {
          this.generateHeatMap(
            'visitors',
            this.Markers.primary,
            source,
            entity,
          ).then((res) => {
            this.currentOptions.type = null;
            this.currentOptions.source = source;
          });
        } else {
          this.SweetAlert.error(
            'COMPONENTS.MAP.MESSAGES.HEATMAP_NO_POINT_SELECTED',
          );
        }
      }
    }

    generateHeatMap(type, marker, source, entity) {
      // this.toggleHeatMapMenu();
      this.isHeatmaploading = true;
      this.isHeatmapEnabled = false;

      this.destroyHeatMap();

      return this.HeatMap.getHeatMap(type, marker, source, entity).then(
        (res) => {
          const heatMapArray = [];
          res.forEach((pos) => {
            for (let i = 0; i < pos.count; i++) {
              heatMapArray.push(
                new google.maps.LatLng(pos.latitude, pos.longitude),
              );
            }
          });

          this.map.heatmapLayers.heatMap.set('radius', 35);
          this.map.heatmapLayers.heatMap.setData(heatMapArray);

          this.isHeatmaploading = false;
          this.isHeatmapEnabled = true;
        },
        (err) => {
          this.$log.error('getHeatMap: ', err);
          this.isHeatmaploading = false;

          this.currentOptions.source = null;
          this.currentOptions.type = null;

          this.SweetAlert.error(
            'COMPONENTS.MAP.MESSAGES.HEATMAP_UNABLE_TO_LOAD',
          );
        },
      );
    }

    themeMasterReset() {
      this.map.data.revertStyle();
      delete this.state.themeSelection;
      google.maps.event.removeListener(this.mouseOverEvent);
      google.maps.event.removeListener(this.mouseOutEvent);
    }

    destroyHeatMap() {
      this.isHeatmapEnabled = false;
      this.map.heatmapLayers.heatMap.setData([]);
    }

    reloadHeatMap() {
      let marker = {};
      let source = '';
      if (this.currentOptions.source) {
        marker = this.Markers.primary;
        source = this.currentOptions.source;
      }
      this.generateHeatMap(this.currentOptions.type, marker, source);
    }

    toggleHeatMapMenu() {
      if (!this.isHeatmaploading) {
        this.isHeatMapMenuOpen = !this.isHeatMapMenuOpen;
      }
    }

    zoomIn() {
      this.map.setZoom(this.map.getZoom() + 1);
    }

    zoomOut() {
      this.map.setZoom(this.map.getZoom() - 1);
    }

    togglebicyclingMap() {
      const bicyckingLayer = this.map.bicyclingLayers[0];
      this.isBicycleMapEnabled = !this.isBicycleMapEnabled;
      this.isBicycleMapEnabled
        ? bicyckingLayer.setMap(this.map)
        : bicyckingLayer.setMap(null);
    }

    toggleTrafficMap() {
      const trafficLayer = this.map.trafficLayers.trafficLayer;
      this.isTrafficMapEnabled = !this.isTrafficMapEnabled;
      this.isTrafficMapEnabled
        ? trafficLayer.setMap(this.map)
        : trafficLayer.setMap(null);
    }

    toggleTransitMap() {
      const transitLayer = this.map.transitLayers[0];
      this.isTransitMapEnabled = !this.isTransitMapEnabled;
      this.isTransitMapEnabled
        ? transitLayer.setMap(this.map)
        : transitLayer.setMap(null);
    }

    openChoroplethSelector() {
      $('#modalChoroplethSelector').modal('show');
    }
  },
};
