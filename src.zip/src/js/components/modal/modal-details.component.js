import template from './modal-details.html';

class ModalDetailsCtrl {
  constructor(Modal, $translate) {
    'ngInject';

    this.modal = Modal;
    this._$translate = $translate;
    this.sorted = [];
    this.descending = true;

    this.resetState();

    $('#detailsModal').on('show.bs.modal', this.onShowDetailsModal.bind(this));
  }

  onShowDetailsModal() {
    this.resetState();
    this.sortBy('index');
  }

  resetState() {
    this.state = {
      desc: null,
      quantity: null,
      percentage: null,
    };
  }

  sortBy(criteria, first) {
    // Set icons -----------------------------
    Object.keys(this.state).forEach((key) => {
      if (criteria === key) {
        this.state[key] = !this.state[key];
      } else {
        this.state[key] = null;
      }
    });

    this.sorted = [];
    let index = 0;

    this.modal.details.data.forEach((element) => {
      let desc_ = this.modal.details.custom
        ? element.label
        : this._$translate.instant(
            'CARDS.' +
              this.modal.details.title +
              '.VALUES.' +
              this.modal.details.desc[element.label.toLowerCase()],
          );

      if (desc_.substring(0, 6) == 'CARDS.') {
        desc_ = this.modal.details.custom
          ? element.label
          : this._$translate.instant(
              'CARDS.' +
                this.modal.details.title +
                '.VALUES.' +
                element.label.toUpperCase(),
            );
      }

      if (desc_.substring(0, 6) == 'CARDS.') {
        desc_ = element.label;
      }

      this.sorted.push({
        index,
        desc: desc_,
        quantity: element.value,
        percentage: parseFloat(element.percentage.toFixed(2)),
      });
      index++;
    });

    // COMBAK: this order must be in elastic search
    if (
      criteria === 'index' &&
      ['CS_SCORE', 'CS_CCS4'].includes(this.modal.details.title)
    ) {
      criteria = 'desc';
    }

    this.sorted.sort((a, b) => {
      const valOne = a[criteria];

      const valTwo = b[criteria];
      if (this.state[criteria]) {
        if (valOne > valTwo) {
          return -1;
        }
        if (valOne < valTwo) {
          return 1;
        }
      } else {
        if (valOne < valTwo) {
          return -1;
        }
        if (valOne > valTwo) {
          return 1;
        }
      }
      return 0;
    });
  }
}

const ModalDetails = {
  template,
  controller: ModalDetailsCtrl,
};

export default ModalDetails;
