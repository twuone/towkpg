import {
  IMPORT_MARKERS_FINISHED,
  REFRESH_PLACES_LIST,
} from '../../app.actions';
import template from './modal-places.html';

class ModalPlacesCtrl {
  constructor(
    $log,
    $rootScope,
    $scope,
    $state,
    $translate,
    Filters,
    MapValues,
    Markers,
    Modal,
    Places,
    SweetAlert,
    User,
  ) {
    'ngInject';

    // init private variables
    this.$log = $log;
    this._Places = Places;
    this._Filters = Filters;
    this._Markers = Markers;
    this._MapValues = MapValues;
    this._$scope = $scope;
    this._$translate = $translate;
    this.$state = $state;
    this._Modal = Modal;
    this.SweetAlert = SweetAlert;

    // init public variables
    this.newPlaces = [];
    this.currentPlace = {};
    this.placeField = '';
    this.batchingFile = null;
    this.user = User;

    // paginator variables
    this.firstPageItem = 0;
    this.lastPageItem = this.numberOfItemsPerPage;
    this.numberOfItemsPerPage = 10;
    this.placesFiltered = this._Places.places;
    this.activeTab = 'points';

    const self = this;

    // it needs to be here because it's passed to the google maps api
    this.placeChange = function() {
      const place = this.getPlace();

      self.currentPlace = {
        desc: place.formatted_address,
        points: [
          {
            latitude: place.geometry.location.lat(),
            longitude: place.geometry.location.lng(),
          },
        ],
        viewport: place.geometry.viewport,
      };
    };

    $('.modal').on('hidden.bs.modal', () =>
      this._Modal.setCurrentModal(undefined),
    );

    this._signalizeChangeOfPlacesList = () => {
      $rootScope.$broadcast(REFRESH_PLACES_LIST, {});
    };

    this._signalizeChangeOfPlacesList = () => {
      $rootScope.$broadcast(REFRESH_PLACES_LIST, {});
    };

    this._slicePlacesList = (index) => {
      // Avoid negative indexes and Handle paginator begin
      if (index < 0) {
        index = 0;
      }

      // Handle paginator overflow
      if (
        index == this._Places.places.length &&
        this._Places.places.length != 0
      ) {
        index =
          Math.floor(this._Places.places.length / this.numberOfItemsPerPage) *
          this.numberOfItemsPerPage;

        // handle indexes multiple of ten
        if (index == this._Places.places.length) {
          index -= this.numberOfItemsPerPage;
        }
      }

      // set first item of page
      this.firstPageItem = index;

      // determine last page item
      this.lastPageItem = index + this.numberOfItemsPerPage - 1;
      if (this.lastPageItem > this._Places.places.length - 1) {
        this.lastPageItem = this._Places.places.length - 1;
      }

      // Note => slice() is NOT inclusive, therefore we must to sum +1 in it
      this._placesPagination = this._Places.places.slice(
        index,
        this.lastPageItem + 1,
      );

      for (let i = 0; i < this._placesPagination.length; i++) {
        let tagsInLine = '';
        if (this._placesPagination[i].tags != undefined) {
          for (let j = 0; j < this._placesPagination[i].tags.length; j++) {
            tagsInLine += this._placesPagination[i].tags[j];
            if (j != this._placesPagination[i].tags.length - 1) {
              tagsInLine += ', ';
            }
          }
        }
        this._placesPagination[i].tagsInLine = tagsInLine;
      }
    };

    $('.modal').on('show.bs.modal', () => this._slicePlacesList(0));

    $rootScope.$on(IMPORT_MARKERS_FINISHED, () => {
      this._Places.getPlaces().finally(() => {
        this._slicePlacesList(0);
      });
    });

    this.$onInit = () => {
      this.getExecutionQueue = this._Places.getExecutionQueue();
    };

    this.nextMarkers = () => {
      if (this.firstPageItem < this._Places.places.length) {
        this.firstPageItem += this.numberOfItemsPerPage;
      }
      this._slicePlacesList(this.firstPageItem);
    };

    this.prevMarkers = () => {
      if (this.firstPageItem < this._Places.places.length) {
        this.firstPageItem -= this.numberOfItemsPerPage;
      }
      this._slicePlacesList(this.firstPageItem);
    };

    $rootScope.$on(REFRESH_PLACES_LIST, (e, data) => {
      this._slicePlacesList(0);
    });

    this.setTab = (tab) => {
      this.activeTab = tab;
    };
  }

  openModal(modalId) {
    this._Modal.setCurrentModal(modalId);
    $('#' + modalId).modal('show');
  }

  addPlace() {
    if (
      this.currentPlace.desc &&
      this.currentPlace.points &&
      this.currentPlace.points.length
    ) {
      this.newPlaces.push(this.currentPlace);

      this.placeField = '';
      this.currentPlace = {};
    }
  }

  removePlace(place) {
    this.newPlaces.splice(this.newPlaces.indexOf(place), 1);
  }

  sendPlaces() {
    if (this.newPlaces.length) {
      this._Places.send(this.newPlaces).then(
        (res) => {
          if (!this._Places.places.length) {
            let place = res.data.markers.primary;
            if (place == undefined) {
              place = res.data.markers[0];
            }
            this._Markers.primary.guid = place.id;
            this._Markers.primary.desc = place.desc;
            if (place.points.length <= 1) {
              this._Markers.primary.center.lat = place.points[0].latitude;
              this._Markers.primary.center.lng = place.points[0].longitude;
            }

            this._MapValues.center.lat = this._Markers.primary.center.lat;
            this._MapValues.center.lng = this._Markers.primary.center.lng;
          }

          this._Places.getPlaces().then((data) => {
            this._signalizeChangeOfPlacesList();
          });

          // clean newPlaces to do not show it in the places modal after save new places
          this.newPlaces = [];

          this.SweetAlert.success(
            'COMPONENTS.PLACES_MODAL.MESSAGES.POINTS_SAVE_SUCCESS',
          );
        },
        (err) => {
          this.$log.error(err);
          this.SweetAlert.error(
            'COMPONENTS.PLACES_MODAL.MESSAGES.POINTS_SAVE_ERROR',
          );
        },
      );
    }
  }

  fileChanged(event, files) {
    const file = files[0];
    if (
      file.name.substr(file.name.length - 4, file.name.length - 1) == '.csv'
    ) {
      this._Places.uploadToQueue(file);
    } else {
      this.SweetAlert.error(
        'COMPONENTS.PLACES_MODAL.MESSAGES.INVALID_FILE_TYPE',
      );
    }
  }

  reloadQueue() {
    this._Places.getExecutionQueue();
  }
}

const ModalPlaces = {
  template,
  controller: ModalPlacesCtrl,
};

export default ModalPlaces;
