import template from './modal-password-change.html';

export const ModalPasswordChangeComponent = {
  template,
  controller: class ModalPasswordChangeComponent {
    constructor(Modal, User, SweetAlert) {
      'ngInject';

      // init private variables
      this._User = User;
      this._Modal = Modal;
      this.SweetAlert = SweetAlert;

      // init public variables
      this.resetFields();

      // reset variables every time the modal is opened
      $('#passwordChangeModal').on('show.bs.modal', () => this.resetFields());
    }

    resetFields() {
      this.oldPassword = '';
      this.newPassword = '';
      this.confirmPassword = '';
      $('#passwordChangeModal *').removeClass('active');
    }

    sendNewPassword() {
      const regexPasswordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!#%*();|<>_+=\-\\/\.,:;\"\'\^?&])[A-Za-z\d$@$!#%*();|<>_+=\-\\/\.,:;\"\'\^?&]{8,}/;

      if (regexPasswordPattern.test(this.newPassword)) {
        this._User.changePassword(this.oldPassword, this.newPassword);
        this.resetFields();
      } else {
        this.resetFields();
        this.SweetAlert.error(
          'COMPONENTS.PASSWORD_MODAL.MESSAGES.INVALID_PASSWORD_FORMAT.TITLE',
          'COMPONENTS.PASSWORD_MODAL.MESSAGES.INVALID_PASSWORD_FORMAT.BODY',
        );

        setTimeout(() => {
          this._Modal.setCurrentModal('modalPasswordChange');
          $('#modalPasswordChange').modal('show');
        }, 1000);
      }
    }
  },
};
