import {
  SET_ALL_PLACES_TYPES,
  REMOVE_ALL_PLACES_TYPES,
  REFRESH_MARKER_CLUSTER,
} from '../../app.actions';
import template from './modal-clustered-places-filter.html';

class ModalClusteredPlacesFilterCtrl {
  constructor(Modal, $translate, $scope) {
    'ngInject';

    // init private variables
    this._Modal = Modal;
    this._$translate = $translate;

    this.cancelModal = () => {
      this.googleMapCtrl.toogleFiltersClusterOptions();
    };

    this.setAllPlacesTypes = () => $scope.$broadcast(SET_ALL_PLACES_TYPES, {});
    this.removeAllPlacesTypes = () =>
      $scope.$broadcast(REMOVE_ALL_PLACES_TYPES, {});
    this.refreshMarkerCluster = () =>
      $scope.$broadcast(REFRESH_MARKER_CLUSTER, {});
  }
}

const ModalClusteredPlacesFilter = {
  require: {
    googleMapCtrl: '^googleMaps',
  },
  template,
  controller: ModalClusteredPlacesFilterCtrl,
};

export default ModalClusteredPlacesFilter;
