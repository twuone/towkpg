import template from './modal-campaign.html';

export const ModalCampaignComponent = {
  template,
  controller: class ModalCampaignComponent {
    constructor(Campaign, Tab, User, PARTNERS) {
      'ngInject';

      // init private variables
      this._Campaign = Campaign;
      this._Tab = Tab;

      // init public variables
      this.user = User;
      this.PARTNERS = PARTNERS;
      this.personGroup = '';

      this.sending = false;

      // init fields model
      this.resetFields();

      $('#campaignModal').on('show.bs.modal', () => this.resetFields());
    }

    resetFields() {
      this.campaign = {
        partners: {},
        id: '',
        name: '',
        ignore_date: false,
      };

      this.personGroup = '';

      $('#campaignModal *').removeClass('active');
    }

    isValid() {
      if (this.sending) {
        return false;
      }

      if (!this.campaign.name || !this.campaign.id) {
        return false;
      }

      let isPartnersSelected = false;
      for (const key in this.campaign.partners) {
        if (this.campaign.partners[key]) {
          isPartnersSelected = true;
        }
      }

      return isPartnersSelected;
    }

    send() {
      this.sending = true;

      const fmtCampaign = angular.copy(this.campaign);

      fmtCampaign.partners = [];

      for (const partner in this.campaign.partners) {
        if (this.campaign.partners[partner]) {
          fmtCampaign.partners.push(partner);
        }
      }

      let promise;

      if (this._Campaign.multi) {
        promise = this._Campaign.sendMulti(this.personGroup, fmtCampaign);
      } else {
        promise = this._Campaign.send(this._Tab.cards, fmtCampaign);
      }

      promise.then(
        () => {
          this.campaign = {
            partners: {},
          };

          this.sending = false;
        },
        () => {
          this.sending = false;
        },
      );
    }
  },
};
