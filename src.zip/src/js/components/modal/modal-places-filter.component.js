import template from './modal-places-filter.html';

class ModalPlacesFilterCtrl {
  constructor(Modal, PlacesFilter, $translate) {
    'ngInject';

    // init private variables
    this._Modal = Modal;
    this._PlacesFilter = PlacesFilter;
    this._$translate = $translate;

    //init public variables
    this.orderedPlaces = this._PlacesFilter.orderedPlaces;
  }
}

const ModalPlacesFilter = {
  template,
  controller: ModalPlacesFilterCtrl,
};

export default ModalPlacesFilter;
