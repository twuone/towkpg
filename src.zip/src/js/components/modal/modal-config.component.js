import template from './modal-config.html';

class ModalConfigCtrl {
  constructor(Modal, User) {
    'ngInject';

    // init private Variables
    this._User = User;

    // init public variables
    this.modal = Modal;
    this.user = User;
  }

  sendNewConfig() {
    this._User.changeConfig(this.user);
  }
}

const ModalConfig = {
  template,
  controller: ModalConfigCtrl,
};

export default ModalConfig;
