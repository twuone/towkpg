import template from './modal-select-dimensions.html';

class ModalSelectDimensionsCtrl {
  constructor(Modal, $translate, Cards, SnapshotService, SweetAlert) {
    'ngInject';

    this.modal = Modal;
    this._$translate = $translate;
    this.sorted = [];
    this.Cards = Cards;
    this.cardsSelected = [];
    this.dimensionSearchFilter = '';
    this.SnapshotService = SnapshotService;
    this.SweetAlert = SweetAlert;

    $('#selectDimensionModal').on('show.bs.modal', () => {
      this.dimensionSearchFilter = '';
      if (this.Cards.cardsSelected.length == 0) {
        this.Cards.rebuildCardSelection();
      }
      this.cardsSelected = this.Cards.cardsSelected;
    });
  }

  filterDimensionOnTextChange() {
    this.cardsSelected = [];
    for (let i = 0; i < this.Cards.cardsSelected.length; i++) {
      if (
        this.Cards.cardsSelected[i].name
          .toLowerCase()
          .includes(this.dimensionSearchFilter.toLowerCase())
      ) {
        this.cardsSelected.push(this.Cards.cardsSelected[i]);
      }
    }
  }

  loadSnapshot() {
    if (!this.SnapshotService.applyFilters()) {
      this.SweetAlert.error(
        'Erro ao aplicar filtro',
        'Não existe filtro salvo para a audiência selecionada.',
      );
    }
  }

  selectAll() {
    for (let i = 0; i < this.cardsSelected.length; i++) {
      this.cardsSelected[i].check = true;
    }
  }

  unselectAll() {
    for (let i = 0; i < this.cardsSelected.length; i++) {
      this.cardsSelected[i].check = false;
    }
  }

  save() {
    this.SnapshotService.save(this.cardsSelected).then((res) => {
      this.SweetAlert.success(
        'Sucesso',
        'Suas configurações de filtros foram salvas.',
      );
    });
  }
}

const ModalSelectDimensions = {
  template,
  controller: ModalSelectDimensionsCtrl,
};

export default ModalSelectDimensions;
