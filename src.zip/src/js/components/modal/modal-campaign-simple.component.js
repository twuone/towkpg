import { isDefined } from 'angular';
import template from './modal-campaign-simple.html';

export const ModalCampaignSimpleComponent = {
  template,
  controller: class ModalCampaignSimpleComponent {
    constructor($log, $scope, $translate, Filters, Tab, Campaign, Modal, SweetAlert) {
      'ngInject';

      // init private variables
      this.$log = $log;
      this._SweetAlert = SweetAlert;
      this._Filters = Filters;
      this._Tab = Tab;
      this._Campaign = Campaign;
      this.formData = {};
      this.formCampaign = undefined;
      this._Modal = Modal;
      this.$scope = $scope;
    }

    $onInit() {
      this.$scope.$watch('formCampaign', (formCampaign) => {
        if (isDefined(formCampaign)) {
          this.formCampaign = formCampaign;
        }
      });
    }

    allowOnlyNumbers(input) {
      this.formData.ids = input.replace(/[^0-9]/g, '');
    }

    clean() {
      this.formData = {};
      this.formCampaign.$setPristine();
      this.formCampaign.$setUntouched();
    }

    close = () => {
      $("#modalCampaignSimple").modal('hide')
      this.clean();
    };

    updateUserCount() {
      this._Campaign.userCount = this.userCount;
    }

    send() {
      if (
        typeof this.formData.name != 'undefined' &&
        this.formData.name != '' &&
        typeof this.formData.ids != 'undefined' &&
        typeof this.formData.emails != 'undefined' &&
        this.formData.emails.length > 0
      ) {
        this._Campaign.sendFacebook(this.formData)
          .then(() => {
            this.close();
          });
      }
    }
  },
};
