import template from './modal-edit-place.html';

class ModalEditPlaceCtrl {
  constructor(Places, $translate, Markers, Modal, SweetAlert) {
    'ngInject';

    // init private variables
    this._Places = Places;
    this._$translate = $translate;
    this._Markers = Markers;
    this._Modal = Modal;
    this.SweetAlert = SweetAlert;
  }

  send() {
    const place = this._Places.formPlace;

    if (place.decorator) {
      place.decorator.color = place.decorator.color.replace('#', '');
    }

    this._Places.sendMarkerEdit(place).then(() => {
      if (place.decorator && place.decorator.color) {
        this._Places.edittingPlace.decorator =
          this._Places.edittingPlace.decorator || {};
        this._Places.edittingPlace.decorator.color = place.decorator.color;
      }
      this._Places.edittingPlace.title = place.title;
      this._Places.edittingPlace.desc = place.desc;
      this._Places.edittingPlace.tags = place.tags;

      if (place.id === this._Markers.primary.guid) {
        this._Markers.primary.title = this._Places.edittingPlace.title;
        this._Markers.primary.desc = this._Places.edittingPlace.desc;
      }

      if (place.id === this._Markers.compare.guid) {
        this._Markers.compare.title = this._Places.edittingPlace.title;
        this._Markers.compare.desc = this._Places.edittingPlace.desc;
      }

      this._Places.availableTags = this._Places.getTagsFromPlaces();

      this.SweetAlert.success('COMPONENTS.EDIT_PLACE_MODAL.MESSAGES.SUCCESS');
    });
  }

  onAddTag(item, model) {
    const newTagTranslatedText = this._$translate.instant(
      'COMPONENTS.EDIT_PLACE_MODAL.FIELDS.NEW_TAG',
    );

    this._Places.formPlace.tags[
      this._Places.formPlace.tags.length - 1
    ] = item.replace(` ${newTagTranslatedText}`, '').trim();
  }
}

const ModalEditPlace = {
  template,
  controller: ModalEditPlaceCtrl,
};

export default ModalEditPlace;
