import template from './modal-cnae-filter.html';

class ModalCnaeFilterCtrl {
  constructor($translate, Filters, CNAE, Modal) {
    'ngInject';

    // init private variables
    this._query = null;
    this._Filters = Filters;
    this._CNAE = CNAE;
    this._Modal = Modal;
  }

  applyFilter() {
    const selectedCNAE = this.getSelectedCNAE(this._CNAE);
    this._Filters.filters.cnae = selectedCNAE;
  }

  getSelectedCNAE(curEls) {
    let curCNAE = [];

    curEls.forEach((curEl) => {
      if (curEl.selected) {
        if (curEl.section) {
          curEl.children.forEach((i, k) => {
            curCNAE.push(i);
          });
        } else {
          curCNAE.push(curEl);
        }
      } else if (curEl.children) {
        curCNAE = curCNAE.concat(this.getSelectedCNAE(curEl.children));
      }
    });

    return curCNAE;
  }
}

const ModalCnaeFilter = {
  template,
  controller: ModalCnaeFilterCtrl,
};

export default ModalCnaeFilter;
