import DocumentsService from '../../services/documents.service';
import Filters from '../../services/filters.service';
import ModalService from '../../services/modal.service';
import { ExtractionField } from '../../core/models';
import { REFRESH_USER_COUNT } from '../../app.actions';
import { UserService } from '../../services/user.service';
import { sortByName } from '../../core/util/arrays';
import { AudienceTypesService } from '../../services/audience-types.service';

export const ModalRequestDocumentsComponent = {
  template: require('./modal-request-documents.component.html'),
  controller: class ModalRequestDocumentsComponent {
    private listeners$ = [] as Function[];
 
    public userCount: number;
    // lógica aplicada para esconder mosaic 
    // caso usuário não tenha permissão para extrair
    public userMosaicRule: boolean;  
    public isResidents: boolean;
    //
    public showMe: boolean;
    public areNoneOfFieldsChecked: boolean;
    public optionsFields: ExtractionField[];

    constructor(
      private $rootScope: ng.IRootScopeService,
      private $scope: ng.IScope,
      private $translate: ng.translate.ITranslateService,
      private Filters: Filters,
      private Tab,
      private User: UserService,
      public AudienceTypes: AudienceTypesService,
      public Documents: DocumentsService,
      public Modal: ModalService,
    ) {
      'ngInject';

      this.listeners$ = [];
    }

    $onInit () {
      this.userCount = this.Documents.userCount;
      this.userMosaicRule = this.User.info.account.config.customVars?.cs_mosaic_pj;
      this.showMe = true;
      this.areNoneOfFieldsChecked = true;
      this.optionsFields = [];

      const refreshUserCount$ = this.$rootScope.$on(
        REFRESH_USER_COUNT,
        this.onRefreshUserCount.bind(this),
      );

      this.listeners$.push(refreshUserCount$);
    }

    $onDestroy() {
      this.unsubscribeListeners();
    }

    private unsubscribeListeners() {
      this.listeners$.forEach((unsubscribeListener) => {
        unsubscribeListener();
      });
    }

    public fieldNameTranslated(field: ExtractionField): string {
      let nameToBeTranslated = field.name;
      const audienceApplied = this.AudienceTypes.applied.toUpperCase();

      if (field.isCustom) {
        nameToBeTranslated = `COMPONENTS.REQUEST_DOCUMENTS_MODAL.CUSTOM_VALUES.${
          nameToBeTranslated
        }`;
      } else {
        nameToBeTranslated = `COMPONENTS.REQUEST_DOCUMENTS_MODAL.VALUES.${audienceApplied}.${
          nameToBeTranslated
        }`
      }

      return this.$translate.instant(nameToBeTranslated);
    }

    onRefreshUserCount() {
      this.userCount = this.Documents.count;
      this.showMe = true;
      this.optionsFields = this.Documents.fields.sort(sortByName);
      this.isResidents = this.Tab.isResidents();
      this.areNoneOfFieldsChecked = true;

      this.selectAllFields();
    }

    public shouldShowExtractBVCSBA(): boolean {
      return (
        this.User.info.account &&
        this.User.info.account.config &&
        this.User.info.account.config.customVars.extract_cs_csba_bv === true
      );
    }  

    public cancel() {
      this.showMe = false;
    }

    public async submitRequest() {

      await this.Documents.submitRequest(this.AudienceTypes.applied);
      this.showMe = false;
    }

    public updateUserCount() {
      this.Documents.userCount = this.userCount;
    }

    public removeAllFields() {
      this.optionsFields.forEach((optionField) => {
        optionField.checked = false;
      });

      this.areNoneOfFieldsChecked = true;
    }

    public selectAllFields() {
      this.optionsFields.forEach((optionField) => {
        optionField.checked = true;
      });

      this.areNoneOfFieldsChecked = false;
    }
  },
};

