import template from './modal-layer-manager.html';

class ModalLayerManagerCtrl {
  constructor(Modal, SweetAlert, Layers) {
    'ngInject';

    // init private variables
    this.SweetAlert = SweetAlert;
    this._Modal = Modal;
    this._Layers = Layers;

    // init public variables
    this.form = {};
  }

  $onInit() {
    this.getExecutionQueue = this._Layers.getExecutionQueue();
  }

  fileChanged(event, files) {
    const file = files[0];
    if (file.size > 5000000) {
      this.SweetAlert.error('COMPONENTS.LAYER_MANAGER_MODAL.MESSAGES.MAX_SIZE');
      return;
    }
    if (
      file.name.substr(file.name.length - 4, file.name.length - 1) == '.zip'
    ) {
      this._Layers.uploadToQueue(file);
    } else {
      this.SweetAlert.error(
        'COMPONENTS.LAYER_MANAGER_MODAL.MESSAGES.INVALID_FILE_TYPE',
      );
    }
  }

  reloadQueue() {
    this._Layers.getExecutionQueue();
  }

  deleteLayer(item) {
    this._Layers.deleteQueueItem(item.shapeFileId);
  }
}

const ModalLayerManager = {
  template,
  controller: ModalLayerManagerCtrl,
};

export default ModalLayerManager;
