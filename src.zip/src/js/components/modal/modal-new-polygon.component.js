import template from './modal-new-polygon.html';

class ModalNewPolygonCtrl {
  constructor(Modal, Places, Markers, Filters, $translate, SweetAlert) {
    'ngInject';

    // init private variables
    this._Places = Places;
    this._Markers = Markers;
    this._Filters = Filters;
    this._$translate = $translate;
    this.SweetAlert = SweetAlert;

    // init public variables
    this.modal = Modal;

    this.modal.polygon.desc = this._$translate.instant(
      'COMPONENTS.NEW_POLYGON_MODAL.DEFAULT_DESC',
    );

    $('#newPolygonModal').on('hide.bs.modal', (e) => {
      this.modal.polygon.event.overlay.setMap(null);
    });
  }

  send() {
    const place = {
      desc: this.modal.polygon.desc,
      title: this.modal.polygon.title,
      points: this.modal.polygon.points,
    };

    this._Places.send([place]).then((res) => {
      this.newPolygon = res.data.markers.pop();

      this.modal.polygon.event.overlay.setMap(null);
      this._Places.places.push(this.newPolygon);

      this._Markers.primary.guid = this.newPolygon.id;
      this._Markers.primary.title = this.newPolygon.title;
      this._Markers.primary.desc = this.newPolygon.desc;
      this._Markers.primary.center.lat = 0;
      this._Markers.primary.center.lng = 0;

      this._Filters.change();

      this.SweetAlert.success('COMPONENTS.NEW_POLYGON_MODAL.MESSAGES.SUCCESS');
    });
  }
}

const ModalNewPolygon = {
  template,
  controller: ModalNewPolygonCtrl,
};

export default ModalNewPolygon;
