import {
  CHANGE_CUSTOM_LAYER_SELECTION,
  CHANGE_AUDIENCE_TYPE_SELECTION,
  CHANGE_LAYER_MODE,
  STYLIZE_MAP,
} from '../../app.actions';
import template from './modal-choropleth-selector.html';

class ModalChoroplethSelectorCtrl {
  constructor(
    Modal,
    Cards,
    AudienceTypes,
    $translate,
    $rootScope,
    $scope,
    DimensionService,
  ) {
    'ngInject';

    // Services
    this.Modal = Modal;
    this.Cards = Cards;
    this.AudienceTypes = AudienceTypes;
    this.DimensionService = DimensionService;
    this._$rootScope = $rootScope;

    // Providers
    this.$translate = $translate;

    // State
    this.state = {};

    // Event Listeners
    $scope.$on(CHANGE_AUDIENCE_TYPE_SELECTION, () => this.removeCurrentTheme());
    $scope.$on(CHANGE_CUSTOM_LAYER_SELECTION, () => this.removeCurrentTheme());
    $scope.$on(CHANGE_LAYER_MODE, () => this.removeCurrentTheme());
  }

  onSearchInputChange() {
    const results = this.Cards.available[this.AudienceTypes.selected].filter(
      (option) => {
        const name = this.$translate
          .instant(`CARDS.${option.config.constName}.TITLE`)
          .toLowerCase();
        return (
          !option.config.custom &&
          option.config.constName != 'ADDRESS_ACCURACY' &&
          name.indexOf(this.state.searchInput.toLowerCase()) != -1
        );
      },
    );
    this.state.filteredOptions = results;
  }

  applyThemeToMap() {
    this.googleMapCtrl.fillColorTheme(this.state.itemSelection);
  }

  removeCurrentTheme() {
    delete this.state.itemSelection;
    delete this.googleMapCtrl.state.themeSelection;

    // this.googleMapCtrl.themeMasterReset(false)
    this._$rootScope.$broadcast(STYLIZE_MAP, true);
  }
}

const ModalChoroplethSelector = {
  require: {
    googleMapCtrl: '^googleMaps',
  },
  template,
  controller: ModalChoroplethSelectorCtrl,
};

export default ModalChoroplethSelector;
