import { RESET_NOT_PANEL_COMPLETELY } from '../app.actions';
import template from './base-selector.html';

export const BaseSelectorComponent = {
  template,
  controller: class BaseSelectorComponent {
    constructor($rootScope, Bases, Tab, Cards, Markers, Filters) {
      'ngInject';

      this._Bases = Bases;
      this._Tab = Tab;
      this._Cards = Cards;
      this._Markers = Markers;
      this._$rootScope = $rootScope;
      this.Filters = Filters;

      Bases.get().then((data) => {
        this.availableBases = data;
      });
    }

    onChange(index) {
      this.Filters.custom = {};
      this._$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);

      if (index == 1) {
        this._Markers.compare.guid = null;
        if ($('.panel-primary').hasClass('is-open')) {
          $('.panel-compare').addClass('is-open');
        } else {
          $('.panel-compare').removeClass('is-open');
        }
      }

      this._Cards.baseId = this._Bases.selection[0].id;
      this._Cards.baseIdCompare = this._Bases.selection[1].id;

      const selectionId = this._Bases.selection[index].id;

      if (selectionId) {
        const sourceObj = this.availableBases.filter((obj) => {
          return obj.id == selectionId;
        })[0];

        this._Bases.selection[index].name = sourceObj.name;
        if (sourceObj.id !== 'serasa') {
          this._Bases.selection[index].fields = sourceObj.fields;
        } else {
          delete this._Bases.selection[index].fields;
        }
        this._Bases.consolidateCustomFields();
      } else if (index === 0) {
        this._Bases.selection[0].name = 'Serasa Experian';
        this._Bases.selection[0].id = 'serasa';
      }

      this._Bases.tempBasesNames[index] = this._Bases.selection[index].name;
    }
  },
};
