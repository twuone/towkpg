import template from './omni-search.html';
import {
  RESET_NOT_PANEL_COMPLETELY,
  CHANGE_LAYER_MODE,
  CHANGE_BOUNDS,
} from '../app.actions';

class OmniSearchCtrl {
  constructor(
    $scope,
    $state,
    $log,
    Bases,
    Cards,
    AudienceTypes,
    Tab,
    Places,
    MapValues,
    NgMap,
    Filters,
    Markers,
    $rootScope,
    SweetAlert,
    Layers,
  ) {
    'ngInject';

    // private variables
    this.$log = $log;
    this._MapValues = MapValues;
    this._Places = Places;
    this._Filters = Filters;
    this._Markers = Markers;
    this._$scope = $scope;
    this._$rootScope = $rootScope;
    this._Layers = Layers;
    this.SweetAlert = SweetAlert;
    this._Bases = Bases;
    this._Cards = Cards;
    this.AudienceTypes = AudienceTypes;
    this.Tab = Tab;

    // public variables
    this.selected = '';
    this.matches = {};
    this.isOpen = false;

    // scope variables
    let isDone = true;

    // Get instance of map
    NgMap.getMap('map').then((map) => {
      this.map = map;
    });

    $scope.$watch('$ctrl.selected', (newValue, oldValue) => {
      this.matches.local = [];

      if (newValue && newValue.length) {
        this.isOpen = true;

        const regex = new RegExp(`.*${newValue.toLowerCase()}.*`, 'i', 'g');

        const placeMatches = this._Places.places.filter((place) => {
          const searchableIdentifier = `${place.title} - ${
            place.desc
          }`.toLowerCase();
          return regex.test(searchableIdentifier);
        });

        this.matches.local = placeMatches.slice(0, 5);

        if (isDone) {
          isDone = false;
          Places.autoComplete(newValue).then(
            (res) => {
              this.matches.google = res;
              isDone = true;
              $scope.$apply();
            },
            (err) => {
              isDone = true;

              // this.$log.error(err);
            },
          );
        }
      } else {
        this.isOpen = false;
        this.matches.google = [];
      }
    });
  }

  closePlaces() {
    this.isOpen = false;
  }

  moveToPlace(place, refresh = true) {
    if (place.viewport) {
      // set zoom based on what is returned on google's API viewport
      this.map.fitBounds(place.viewport);
    } else {
      // set default zoom instead
      this.map.setZoom(14);
    }

    this.map.setZoom(14);
    if (refresh) {
      this._Filters.change('primary');
    }

    this.isOpen = false;
    this._$rootScope.$broadcast(CHANGE_BOUNDS);
  }

  selectPlace(place) {
    this._$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
    this._Markers.primary.guid = null;
    this._Markers.compare.guid = null;
    this._Cards.layerMode = false;
    $('.panel-cards').addClass('is-open');

    if (this._Layers.activated) {
      this._Layers.reset();
    }
    this._Layers.activated = false;
    this._$rootScope.$broadcast(CHANGE_LAYER_MODE, {});
    $('.panel-primary').addClass('is-open');
    this.moveToPlace(place);

    this._Markers.primary.guid = place.id;
    this._Markers.primary.desc = place.desc;
    this._Markers.primary.title = place.title;
    this.AudienceTypes.previous = this.AudienceTypes.applied;
    this.AudienceTypes.applied = this.Tab.cards;

    if (place.points.length <= 1) {
      this._Markers.primary.type = 'place';
      this._Markers.primary.center.lat = place.points[0].latitude;
      this._Markers.primary.center.lng = place.points[0].longitude;
    } else {
      this._Markers.primary.type = 'polygon';
    }

    this._MapValues.center.lat = place.points[0].latitude;
    this._MapValues.center.lng = place.points[0].longitude;

    this._Bases.applySelection();
    this._Filters.change();
  }

  selectGooglePlace(match) {
    this.selected = '';
    this._Places.getDetails(match.place_id).then((place) => {
      this.moveToPlace(place, false);
      this._$scope.$apply();
    });
    this.isOpen = false;
  }
}

const OmniSearch = {
  template,
  controller: OmniSearchCtrl,
};

export default OmniSearch;
