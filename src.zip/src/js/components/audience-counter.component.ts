import { REFRESH_USER_COUNT } from '../app.actions';
import { UserService } from '../services/user.service';
import { SweetAlertService } from '../services/sweet-alert.service';
import ModalService from '../services/modal.service';
import LayersService from '../services/layers.service';
import FiltersService from '../services/filters.service';
import ExtractionService from '../services/extraction.service';
import DocumentsService from '../services/documents.service';
import CardsService from '../services/cards.service';
import CampaignService from '../services/campaign.service';
import BasesService from '../services/bases.service';

export const AudienceCounterComponent: ng.IComponentOptions = {
  bindings: {
    filterWatch: '<',
    marker: '=',
    panelIndex: '<',
    type: '<',
  },
  template: require('./audience-counter.html'),
  controller: class AudienceCounterComponent
    implements ng.IComponentController {
    filterWatch: string;
    marker: any;
    panelIndex: number;
    type: string;
    data;

    constructor(
      private $rootScope: ng.IRootScopeService,
      private AudienceTypes,
      private Bases: BasesService,
      private Campaign: CampaignService,
      private Cards: CardsService,
      private Documents: DocumentsService,
      private ExtractionService: ExtractionService,
      private Filters: FiltersService,
      private Layers: LayersService,
      private Modal: ModalService,
      private SweetAlert: SweetAlertService,
      private User: UserService,
    ) {
      'ngInject';
    }

    $onInit() {
      // setting refresh data callback
      this.$rootScope.$watch(this.filterWatch, this.onFilterChanged.bind(this));
    }

    onFilterChanged() {
      if (this.marker.guid && this.filterWatch !== 'notColumn') {
        this.data = null;
        this.Cards.getCardDetails(
          '/count',
          this.AudienceTypes.applied,
          this.Filters.getParams(),
          this.marker,
          this.AudienceTypes.applied === 'visitors' ? 'device' : 'data',
          this.Filters.getFilters(true),
          this.Layers.selection,
          this.filterWatch,
        )
          .then(this.setCardData.bind(this))
          .then(
            this.onGetCardDetailsSuccess.bind(this),
            this.onGetCardDetailsError.bind(this),
          );
      } else if (this.filterWatch === 'notColumn') {
        this.data = this.Cards.dataCardComparison.not_column_cards.count;
      }
    }

    onGetCardDetailsSuccess(res) {
      if (this.Layers.activated) {
        this.Cards.dataCardComparison[this.filterWatch].count = res;
      }
    }

    onGetCardDetailsError(err) {
      this.setCardData({
        error: err.status,
      });
    }

    setCardData(data) {
      this.data = data;

      return data;
    }

    openModalCampaign(group, count, minCampaignAudience) {
      if (count >= (minCampaignAudience || 10)) {
        this.Campaign.multi = false;
        this.Campaign.setOptions({
          count,
          group,
        });

        $('#campaignModal').modal('show');
      } else {
        this.SweetAlert.error('CARDS.COUNTER.MESSAGES.AUDIENCE_BELOW_MIN');
      }
    }

    openModalCampaignSimple(count: number, baseId = 'serasa', exclude = false) {
      if (count >= 3000) {
        const base = {
          id: this.Bases.selection[this.panelIndex].id,
          name: this.Bases.selection[this.panelIndex].name,
        };
        this.Campaign.multi = false;

        this.Campaign.setSelectedBase(base);

        this.Campaign.setOptions(
          {
            count,
          },
          exclude,
        );
        $('#modalCampaignSimple').modal({ show: true, backdrop: 'static' });
        this.Modal.setCurrentModal('modal-campaign-simple');
      } else {
        this.SweetAlert.error('CARDS.COUNTER.MESSAGES.AUDIENCE_BELOW_MIN');
      }
    }

    openModalRequestDocuments(count: number, baseId = 'serasa', exclude = false) {
      const userConfig = this.User.info.account.config;
      const audience = this.AudienceTypes.applied;
      const variablesForExtraction = this.ExtractionService.getVariablesForExtractionByUserAndAudience(
        userConfig,
        audience,
      );
      this.Documents.baseId = this.getBaseId();
      this.Documents.userCount = count;

      this.Documents.setOptions(
        {
          count,
          fields: variablesForExtraction,
        },
        exclude,
      );
      this.$rootScope.$broadcast(REFRESH_USER_COUNT);
      $('#modalRequestDocuments').modal('show');
      this.Modal.setCurrentModal('modal-request-documents');
    }

    getBaseId() {
      return this.Bases.selection[this.panelIndex].id;
    }
  },
};
