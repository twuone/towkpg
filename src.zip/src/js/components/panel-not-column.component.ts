import { REFRESH_USER_COUNT, SHOW_COMPARISON_PANEL } from '../app.actions';
import DimensionService from '../services/dimension.service';
import ExtractionService from '../services/extraction.service';
import CardsService from '../services/cards.service';
import { UserService } from '../services/user.service';
import LayersService from '../services/layers.service';
import DocumentsService from '../services/documents.service';
import ModalService from '../services/modal.service';
import BasesService from '../services/bases.service';
import { AudienceTypesService } from '../services/audience-types.service';
import CampaignService from '../services/campaign.service';
import { Base } from '../core/models';
import { SweetAlertService } from '../services/sweet-alert.service';

/**
 * Coluna usada na comparação de base do MapView
 */
export const PanelNotColumnComponent: ng.IComponentOptions = {
  bindings: {
    cards: '=',
  },
  template: require('./panel-not-column.html'),
  controller: class PanelNotColumnComponent implements ng.IComponentController {
    private user: UserService;
    private cards: Object;
    private Math = Math;
    private filterWatch = 'notColumn';
    private isPanelPrimary = false;
    private tab: any;
    private marker: any;
    private scrollBind = false;
    private customCards: any;
    private currentTab: string;
    isFacebookEnabled = false;
    isAudienceResidents = false;

    constructor(
      private $rootScope: ng.IRootScopeService,
      private $scope: ng.IScope,
      private AudienceTypes: AudienceTypesService,
      private Bases: BasesService,
      private Cards: CardsService,
      private Campaign: CampaignService,
      private DimensionService: DimensionService,
      private Documents: DocumentsService,
      private ExtractionService: ExtractionService,
      private Layers: LayersService,
      private Markers,
      private Modal: ModalService,
      private Tab,
      private SweetAlert: SweetAlertService,
      User: UserService,
    ) {
      'ngInject';

      // init public variables
      this.cards = this.Cards.available;
      this.marker = Markers.notColumn;
      this.tab = Tab;
      this.marker = Markers.primary;
      this.user = User;
    }

    $onInit() {
      this.$rootScope.$on(
        SHOW_COMPARISON_PANEL,
        this.showComparisonPanel.bind(this),
      );

      this.$rootScope.$watch(this.filterWatch, () => {
        this.createCustomCards();
      });
    }

    $onChanges() {
      this.isAudienceResidents =
        this.AudienceTypes.applied === 'residents';
      this.isFacebookEnabled = this.user.getConfig().facebookEnabled === true;
    }

    showComparisonPanel() {
      this.$scope.$apply();

      $('.panel-primary').toggleClass('is-open');
    }

    setTab(tab: string) {
      this.currentTab = tab;
      this.Tab.cards = tab;

      // Dispatch a resize event on every tab change
      // so D3 awakens to do any necessary redrawing
      setTimeout(() => {
        window.dispatchEvent(new Event('resize'));
      }, 100);
    }

    dismissPanel() {
      $('.panel-not-column').removeClass('is-open');
    }

    openModalCampaignSimple(userCount: number) {
      if (userCount >= 3000) {
        this.Campaign.multi = false;
        this.Campaign.setSelectedBase(this.getBase());

        const base = {
          id: 'serasa',
          name: 'Serasa Experian',
        };

        this.Campaign.setSelectedBase(base);

        this.Campaign.setOptions(
          {
            count: userCount,
          },
          true,
        );

        $('#modalCampaignSimple').modal({ show: true, backdrop: 'static' });
        this.Modal.setCurrentModal('modal-campaign-simple');
      } else {
        this.SweetAlert.error('CARDS.COUNTER.MESSAGES.AUDIENCE_BELOW_MIN');
      }
    }

    openModalRequestDocuments(userCount: number) {
      const userConfig = this.user.info.account.config;
      const audience = this.AudienceTypes.applied;

      const variablesForExtraction = this.ExtractionService.getVariablesForExtractionByUserAndAudience(
        userConfig,
        audience,
      );
      this.Documents.baseId = this.getBaseId();
      this.Documents.userCount = userCount;
      this.Documents.setOptions(
        {
          count: userCount,
          fields: variablesForExtraction,
        },
        true,
      );

      this.$rootScope.$broadcast(REFRESH_USER_COUNT);
      $('#modalRequestDocuments').modal('show');
      this.Modal.setCurrentModal('modal-request-documents');
    }

    getBase(): Base {
      return this.Bases.selection[0].id === 'serasa'
        ? this.Bases.selection[1]
        : this.Bases.selection[0];
    }

    getBaseId(): string {
      return this.getBase().id;
    }

    createCustomCards() {
      if (this.Bases.customFields) {
        this.customCards = {};
        const customKeys = Object.keys(this.Bases.customFields);

        customKeys.sort().forEach((customKey) => {
          const card = this.createCustomCard(customKey);

          this.AudienceTypes.available.forEach((audience) => {
            if (!Boolean(this.customCards[audience])) {
              this.customCards[audience] = [];
            }

            this.customCards[audience].unshift(card);
          });
        });
      } else {
        this.customCards = null;
      }
    }

    createCustomCard(customKey: string) {
      return {
        chartType: 'generic',
        url: `/${customKey}`,
        iconClass: 'mdi-chart-arc',
        customName: customKey.toUpperCase(),
        custom: true,
      };
    }
  },
};
