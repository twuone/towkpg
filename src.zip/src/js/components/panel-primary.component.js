import template from './panel-cards.html';

class PanelPrimaryCtrl {
  constructor(
    Cards,
    Tab,
    Markers,
    AudienceTypes,
    $scope,
    User,
    Bases,
    Layers,
    $rootScope,
    DimensionService,
  ) {
    'ngInject';

    // init private variables
    this._Tab = Tab;
    this._Markers = Markers;
    this.Cards = Cards;
    this._Bases = Bases;
    this.Bases = Bases;
    this.Layers = Layers;
    this.$rootScope = $rootScope;
    this.DimensionService = DimensionService;

    // init public variables
    this.cards = {};
    this.marker = Markers.primary;
    this.tab = Tab;
    this.isPanelPrimary = true;
    this.user = User;
    this.panelIndex = 0;

    this.filterWatch = 'primary';
    this.$scope = $scope;

    this.AudienceTypes = AudienceTypes;

    this.$onInit = () => {
      $rootScope.$watch(this.filterWatch, () => {
        this.createCustomCards();
      });
    };
  }

  setTab(tab) {
    this.currentTab = tab;
    this._Tab.cards = tab;

    // Dispatch a resize event on every tab change
    // so D3 awakens to do any necessary redrawing
    setTimeout(() => {
      window.dispatchEvent(new Event('resize'));
    }, 100);
  }

  dismissPanel(panelIndex) {
    if ($('.panel-primary').hasClass('is-open')) {
      $('.panel-cards').removeClass('is-open');
    } else {
      $('.panel-cards').addClass('is-open');
    }

    /* if (this._Markers.compare.guid || this._Cards.showComparison) {
      $('.panel-cards').toggleClass('is-open')
    } else {
      $('.panel-primary').toggleClass('is-open')
    } */
  }

  createCustomCards() {
    if (this.Bases.customFields) {
      this.customCards = {};
      const customKeys = Object.keys(this.Bases.customFields).sort();

      for (let i = customKeys.length - 1; i >= 0; i--) {
        const card = {
          chartType: 'generic',
          url: '/' + customKeys[i],
          iconClass: 'mdi-chart-arc',
          customName: customKeys[i].toUpperCase(),
          custom: true,
          values: this.Bases.customFields[customKeys[i]],
        };

        for (let a = 0; a < this.AudienceTypes.available.length; a++) {
          if (!this.customCards[this.AudienceTypes.available[a]]) {
            this.customCards[this.AudienceTypes.available[a]] = [];
          }
          this.customCards[this.AudienceTypes.available[a]].unshift(card);
        }
      }
    } else {
      this.customCards = null;
    }
  }
}

const PanelPrimary = {
  bindings: {
    cards: '=',
  },
  template,
  controller: PanelPrimaryCtrl,
};

export default PanelPrimary;
