import { RESET_NOT_PANEL_COMPLETELY } from '../app.actions';
import template from './layer-selector.html';

export const LayerSelectorComponent = {
  template,
  controller: class LayerSelectorComponent {
    constructor(Bases, Layers, $state, $rootScope, User, Markers) {
      'ngInject';

      this._Bases = Bases;
      this._Layers = Layers;
      this._$state = $state;
      this._User = User;
      this._Markers = Markers;

      Bases.get().then((data) => {
        this.availableBases = data;
      });
    }

    activateSubLayer(option) {
      if (option != this._Layers.currentSubLayer) {
        this._Layers.selectSubLayerOption(option);
      }
    }

    onChange(index) {
      this._$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
      this._Markers.compare.guid = null;
      const sourceObj = this.availableBases.filter((obj) => {
        return obj.id == this._Bases.selection[index].id;
      });
      this._Bases.selection[index].name = sourceObj[0].name;
    }
  },
};
