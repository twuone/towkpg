import template from './card.html';

export const CardComponent = {
  bindings: {
    config: '=',
    marker: '=',
    values: '<',
    type: '<',
    filterWatch: '<',
    customName: '<',
    isSerasaData: '<',
  },
  template,
  controller: class CardComponent {
    constructor(
      $injector,
      $log,
      $rootScope,
      $scope,
      $translate,
      Cards,
      ChartOptions,
      Filters,
      Layers,
      Modal,
      User,
    ) {
      'ngInject';

      this.$injector = $injector;
      this.$log = $log;
      this.$rootScope = $rootScope;
      this.$scope = $scope;
      this.$translate = $translate;
      this.Cards = Cards;
      this.ChartOptions = ChartOptions;
      this.Filters = Filters;
      this.Layers = Layers;
      this.Modal = Modal;
      this.User = User;

      // init public variables
      this.data = null;
      this.options = {};
      this.rawData = null;
      this.total = 1;

      this.optionsVivo = {
        chart: {
          type: 'pieChart',
          height: 340,
          x: (d) =>
            this.$translate.instant(
              this.getValueTrans(this.config.constName, d.label),
            ),
          y: (d) => {
            return d.percentage;
          },
          showLabels: true,
          duration: 500,
          labelThreshold: 0.01,
          labelSunbeamLayout: false,
          tooltip: {
            contentGenerator: (d) => `
                        <div class="tooltip-key">
                          ${this.$translate.instant(
                            this.getValueTrans(
                              this.config.constName,
                              d.data.label,
                            ),
                          )}
                        </div>
                        <div class="tooltip-value">${d.data.percentage.toFixed(
                          1,
                        )}%</div>`,
          },
          donut: true,
          labelType: 'value',
          valueFormat(d) {
            if (d > 3) {
              return d.toFixed(1) + '%';
            }
          },
          showLegend: false,
          callback: () => {
            // Dispatch a resize event on every tab change
            // so D3 awakens to do any necessary redrawing
            setTimeout(() => {
              window.dispatchEvent(new Event('resize'));
            }, 200);
          },
        },
      };

      this.optionsGeneric = (translations) => ({
        chart: {
          type: 'pieChart',
          noData: $translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
          height: 200,
          width: 400,
          margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          },
          showLabels: true,
          duration: 500,
          labelThreshold: 0.01,
          labelSunbeamLayout: false,
          donut: false,
          labelType: 'value',
          showLegend: false,
          x: (d) => translations[d.label],
          y: (d) => d.percentage,
          tooltip: {
            contentGenerator: (d) => `
                <div class="tooltip-key">
                  ${translations[d.data.label]}
                </div>
                <div class="tooltip-value">${d.data.percentage.toFixed(
                  1,
                )}%</div>`,
          },
          valueFormat(d) {
            if (d > 3) {
              return d.toFixed(1) + '%';
            }
          },
          callback: () => {
            // Dispatch a resize event on every tab change
            // so D3 awakens to do any necessary redrawing
            setTimeout(() => {
              window.dispatchEvent(new Event('resize'));
            }, 200);
          },
        },
      });
    }

    $onInit() {
      // getting nvd3 options
      const optionsFunc = this.ChartOptions[this.config.chartType];

      if (this.config.chartType === 'generic_pie') {
        this.options = this.optionsGeneric(this.config.translations);
      }

      if (
        optionsFunc instanceof Function &&
        this.config.chartType != 'generic_pie'
      ) {
        // To assure
        this.options = optionsFunc(
          this.$translate,
          this.$injector.has(this.config.constName)
            ? this.$injector.get(this.config.constName)
            : {},
          this.$rootScope,
        );

        this.options.chart.xAxis = this.options.chart.xAxis || {};
        this.options.chart.yAxis = this.options.chart.yAxis || {};
      }

      // add event to refresh the language of each card
      this.$rootScope.$on('$translateChangeEnd', () => {
        if (this.options.chart.type !== 'multiBarHorizontalChart') {
          this.options.chart.xAxis.axisLabel = this.$translate.instant(
            'CARDS.' + this.config.constName + '.TITLE',
          );
          this.options.chart.yAxis.axisLabel = this.$translate.instant(
            'COMPONENTS.CARD.AUDIENCE',
          );
        }

        this.options.chart.noData = this.$translate.instant(
          'COMPONENTS.CARD.MESSAGES.NO_DATA',
        );
      });

      // setting refresh data callback
      const deregister = this.$rootScope.$watch(this.filterWatch, () => {
        if (this.marker.guid && this.filterWatch != 'notColumn') {
          this.data = null;
          const { constName } = this.config;

          this.Cards.getCardDetails(
            this.config.url,
            this.type,
            this.Filters.getParams(),
            this.marker,
            this.config.entity,
            this.Filters.getFilters(true),
            this.Layers.selection,
            this.filterWatch

            //, constName.toLowerCase(),
          ).then(
            (res) => {
              this.rawData = res;
              if (
                res &&
                !res.error &&
                this.options.chart &&
                (this.options.chart.type === 'discreteBarChart' ||
                  this.options.chart.type === 'multiBarHorizontalChart')
              ) {
                this.data = [
                  {
                    values: res,
                  },
                ];
              } else {
                this.data = res == undefined ? [] : res;
              }
              this.total = 0;

              try {
                res.forEach((el) => (this.total += el.value));
              } catch (err) {}
            },
            (err) => {
              this.$log.error(err);
              this.data = {
                error: err.status,
              };
            },
          );
        } else {
          if (this.filterWatch == 'notColumn') {
            let it_name = this.config.url
              .replace('/inclination/', '')
              .replace('/', '')
              .replace('-', '_');
            if (this.Cards.dataCardComparison['not_column_cards'][it_name]) {
              let item =
                this.Cards.dataCardComparison['not_column_cards'][it_name];

              this.rawData = item;
              if (
                this.options.chart &&
                (this.options.chart.type === 'discreteBarChart' ||
                  this.options.chart.type === 'multiBarHorizontalChart')
              ) {
                this.data = [
                  {
                    values: item,
                  },
                ];
              } else {
                this.data = item;
              }

              this.total = 0;
              for (let i = 0; i < item.length; i++) {
                this.total += item[i]['value'];
              }

              this.rawData = item;
            }
          }
        }
      });

      if (this.marker.guid && this.filterWatch != 'notColumn') {
        this.Cards.watcherInstances.push(deregister);

        // Failsafe for deregister
        this.$scope.$on('$destroy', () => {
          deregister(); // Deregister $rootScope watcher
        });
      }
    }

    getValueTrans(segment, value) {
      try {
        const description = this.$translate.instant(
          'CARDS.' + segment.toUpperCase() + '.VALUES.' + value.toUpperCase(),
        );
        if (description.substring(0, 6) === 'CARDS.') {
          return value;
        } else {
          return description;
        }
      } catch (err) {
        return value;
      }
    }

    openModalDetails(group, data, title, custom) {
      this.Modal.setDetails({
        title,
        data: data[0].values ? data[0].values : data,
        desc: this.$injector.has(this.config.constName)
          ? this.$injector.get(this.config.constName)
          : this.config.progress
            ? this.$injector.get('BINARY_CHART')
            : this.makeObjectFromValues(),
        custom,
      });

      $('#detailsModal').modal('show');
    }

    makeObjectFromValues() {
      const obj = {};
      this.values.forEach((value) => {
        obj[value] = value.toUpperCase();
      });
      if (!this.values.includes('unknown')) {
        obj.unknown = 'UNKNOWN';
      }
      return obj;
    }
  },
};
