import template from './filters-output.html';

export const FiltersOutputComponent = {
  bindings: {
    data: '=',
  },
  template,
  controller: class FiltersOutputComponent {
    constructor() {
      'ngInject';
    }
  },
};
