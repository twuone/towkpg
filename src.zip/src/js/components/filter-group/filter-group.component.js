import template from './filter-group.html';

export const FilterGroupComponent = {
  bindings: {
    name: '<',
    groupId: '<',
    dimensions: '<',
  },
  template,
  controller: class FilterGroupComponent {
    constructor(AudienceTypes, Cards) {
      'ngInject';

      this.AudienceTypes = AudienceTypes;
      this.Cards = Cards;

      this.state = {
        collapsed: false,
      };
    }

    toggleGroupCollapse() {
      this.state.collapsed = !this.state.collapsed;
    }
  },
};
