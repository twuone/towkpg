import { REFRESH_USER_COUNT } from '../app.actions';
import template from './report-column.html';

export const ReportColumnComponent = {
  template,
  bindings: {
    base: '=',
  },
  controller: class ReportColumnComponent {
    constructor(
      $rootScope,
      AudienceTypes,
      Bases,
      Campaign,
      Cards,
      Documents,
      Export,
      ExtractionService,
      Modal,
      SweetAlert,
      User,
    ) {
      'ngInject';

      this.$rootScope = $rootScope;
      this.AudienceTypes = AudienceTypes;
      this.Bases = Bases;
      this.Campaign = Campaign;
      this.Cards = Cards;
      this.Documents = Documents;
      this.Export = Export;
      this.ExtractionService = ExtractionService;
      this.Modal = Modal;
      this.SweetAlert = SweetAlert;
      this.User = User;
    }

    $onInit() {
      if (this.Bases.countersHub.length >= 2) {
        this.Bases.countersHub = [];
      }
      const role = this.base.column == 'primary' ? 'masterReport' : 'slaveReport';
      if (this.base.column == 'primary') {
        this.Bases.getReport(this.base.id, this.base.column).then((data) => {
          this.base.data = data[role];
          this.Bases.countersHub.push(data[role].counters);
          this.Bases.getAvailableSegments();
          this.Bases.getAvailableValues();
        });
      } else {
        const timerAwait = setInterval(() => {
          if (this.Bases.data_view[role]) {
            clearInterval(timerAwait);
            this.base.data = this.Bases.data_view[role];
            this.Bases.countersHub.push(this.Bases.data_view[role].counters);
            this.Bases.getAvailableSegments();
            this.Bases.getAvailableValues();
          }
        }, 1000);
      }
    }

    openModalCampaignSimple(count, baseId = 'serasa', exclusion = false) {
      if (count >= 3000) {
        this.Campaign.setSelectedBase(this.base);
        this.Campaign.multi = false;
        this.Campaign.setOptions(
          {
            count,
          },
          exclusion,
        );
        $("#modalCampaignSimple").modal({ show: true, backdrop: 'static' });
        this.Modal.setCurrentModal('modal-campaign-simple');
      } else {
        this.SweetAlert.error('CARDS.COUNTER.MESSAGES.AUDIENCE_BELOW_MIN');
      }
    }

    openModalRequestDocuments(userCount, baseId = 'serasa', exclusion = false) {
      const userConfig = this.User.info.account.config;
      const audience = this.AudienceTypes.applied;

      const fields = this.ExtractionService.getVariablesForExtractionByUserAndAudience(
        userConfig,
        audience,
      );
      this.Documents.baseId = baseId;
      this.Documents.userCount = userCount;
      this.Documents.setOptions(
        {
          count: userCount,
          fields,
        },
        exclusion,
      );
      this.$rootScope.$broadcast(REFRESH_USER_COUNT);
      $('#modalRequestDocuments').modal('show');
      this.Modal.setCurrentModal('modal-request-documents');
    }
  },
};
