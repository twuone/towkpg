import CardBase from './card-base';
import template from './card-mosaic.html';

export const CardMosaicComponent = {
  bindings: {
    data: '=',
    group: '<',
  },
  template,
  controller: class CardMosaicComponent extends CardBase {
    constructor(Modal, MOSAIC, $translate, $rootScope) {
      'ngInject';

      super(Modal, MOSAIC, $translate);

      this._$translate = $translate;

      this.options = {
        chart: {
          type: 'pieChart',
          noData: this._$translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
          height: 300,
          width: 400,
          margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          },
          x: (d) =>
            this._$translate.instant('CARDS.MOSAIC.VALUES.' + MOSAIC[d.label]),
          y: (d) => d.percentage,
          cornerRadius: 0,
          color(d) {
            let mosaicColor;

            switch (d.label) {
              case 'A01':
              case 'A02':
                mosaicColor = '#4C4686';
                break;
              case 'B03':
              case 'B04':
              case 'B05':
                mosaicColor = '#2A616E';
                break;
              case 'C06':
              case 'C07':
              case 'C08':
                mosaicColor = '#53ABA3';
                break;
              case 'D09':
              case 'D10':
              case 'D11':
              case 'D12':
              case 'D13':
              case 'D14':
                mosaicColor = '#8A3235';
                break;
              case 'E15':
              case 'E16':
              case 'E17':
              case 'E18':
                mosaicColor = '#D0BD30';
                break;
              case 'F19':
              case 'F20':
              case 'F21':
                mosaicColor = '#8D8A82';
                break;
              case 'G22':
              case 'G23':
              case 'G24':
                mosaicColor = '#9B3480';
                break;
              case 'H25':
              case 'H26':
              case 'H27':
              case 'H28':
              case 'H29':
                mosaicColor = '#C47030';
                break;
              case 'I30':
              case 'I31':
              case 'I32':
                mosaicColor = '#6EC03A';
                break;
              case 'J33':
              case 'J34':
                mosaicColor = '#785A43';
                break;
              case 'K35':
              case 'K36':
              case 'K37':
              case 'K38':
              case 'K39':
              case 'K40':
                mosaicColor = '#006845';
                break;
              default:
                mosaicColor = '#333'; // Worst color in case of error
            }
            return mosaicColor;
          },
          tooltip: {
            contentGenerator: (d) => {
              const content = `
                  <div class="tooltip-key">
                    <span class="tooltip-color-indicator" style="background-color: ${
                      d.color
                    };"></span>
                    ${this._$translate.instant(
                      'CARDS.MOSAIC.VALUES.' + MOSAIC[d.data.label],
                    )}
                  </div>
                  <div class="tooltip-value">${d.data.percentage.toFixed(
                    1,
                  )}%</div>`;
              return content;
            },
          },
          showLabels: true,
          duration: 500,
          labelThreshold: 0.01,
          labelType: 'value',
          valueFormat(d) {
            if (d > 5) {
              return d.toFixed(1) + '%';
            }
          },

          // labelSunbeamLayout: true,
          showLegend: false,
          donut: true,
        },
      };

      $rootScope.$on('$translateChangeEnd', () => {
        this.options.chart.noData = this._$translate.instant(
          'COMPONENTS.CARD.MESSAGES.NO_DATA',
        );
      });
    }
  },
};
