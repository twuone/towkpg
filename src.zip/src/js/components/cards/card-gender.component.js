import CardBase from './card-base';
import template from './card-gender.html';

const CardGenderComponent = {
  bindings: {
    data: '=',
    group: '<',
  },
  template,
  controller: class CardGenderComponent extends CardBase {
    constructor(Modal, GENDER, $translate, $rootScope) {
      'ngInject';

      super(Modal, GENDER, $translate);

      this._$translate = $translate;

      this.options = {
        chart: {
          type: 'pieChart',
          noData: this._$translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
          height: 200,
          width: 400,
          margin: {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          },
          x: (d) => this._$translate.instant(
            'CARDS.GENDER.VALUES.' + GENDER[d.label],
          ),
          y: (d) => d.percentage,
          cornerRadius: 0,
          tooltip: {
            contentGenerator: (d) => (
              `<div class="tooltip-key">
                    <span class="tooltip-color-indicator" style="background-color: ${
                     d.color
                    };"></span>
                    ${this._$translate.instant(
                      'CARDS.GENDER.VALUES.' + GENDER[d.data.label],
                    )}
                  </div>
                  <div class="tooltip-value">${d.data.percentage.toFixed(
                    1,
                  )}%</div>`),
          },
          showLabels: true,
          showLegend: false,
          duration: 500,
          labelThreshold: 0.01,
          labelType: 'value',
          valueFormat: (d) => {
            if (d > 5) {
              return d.toFixed(1) + '%';
            }
          },
        },
      };

      $rootScope.$on('$translateChangeEnd', () => {
        this.options.chart.noData = this._$translate.instant(
          'COMPONENTS.CARD.MESSAGES.NO_DATA',
        );
      });
    }
  },
};

export default CardGenderComponent;
