import CardBase from './card-base';
import template from './card-count.html';

export const CardCountComponent = {
  bindings: {
    data: '=',
    group: '<',
  },
  template,
  controller: class CardCountComponent extends CardBase {
    constructor(Campaign, User, $translate) {
      'ngInject';

      super(Campaign, undefined, $translate);

      // init public variables
      this.user = User;
    }
  },
};
