export default class CardBase {
	constructor(Service, desc, SweetAlert) {
		this._Service = Service;
		this._desc = desc;
	}

	openModalCampaign(group, count, minCampaignAudience) {
		if(count >= (minCampaignAudience || 10)) {
			this._Service.setCount(count);
			this._Service.setGroup(group);

			$('#campaignModal').modal('show');
		} else {
			this.SweetAlert.error('CARDS.COUNTER.MESSAGES.AUDIENCE_BELOW_MIN')
		}
	}

	openModalDetails(group, data, title) {
		this._Service.setDetails({
			title,
			data: (data[0].values ? data[0].values : data),
			desc: this._desc
		});

		$('#detailsModal').modal('show');
	}
}
