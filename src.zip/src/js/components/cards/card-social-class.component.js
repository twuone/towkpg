import CardBase from './card-base';
import template from './card-social-class.html';

export const CardSocialClassComponent = {
  bindings: {
    data: '=',
    group: '<',
  },
  template,
  controller: class CardSocialClassCtrl extends CardBase {
    constructor(Modal, SOCIAL_CLASS, $translate, $rootScope) {
      'ngInject';

      super(Modal, SOCIAL_CLASS, $translate);

      this._$translate = $translate;
      this.api = this.options = {
        chart: {
          type: 'discreteBarChart',
          noData: this._$translate.instant('COMPONENTS.CARD.MESSAGES.NO_DATA'),
          height: 300,
          width: 400,
          margin: {
            bottom: 120,
          },
          x: (d) => {
            return this._$translate.instant(
              'CARDS.SOCIAL_CLASS.VALUES.' + SOCIAL_CLASS[d.label],
            );
          },
          y: (d) => {
            return d.percentage;
          },
          showValues: true,
          valueFormat: function(d) {
            return d.toFixed(1) + '%';
          },
          duration: 500,
          xAxis: {
            axisLabel: this._$translate.instant('CARDS.SOCIAL_CLASS.TITLE'),
            rotateLabels: -45,
          },
          yAxis: {
            axisLabel: this._$translate.instant('COMPONENTS.CARD.AUDIENCE'),
            axisLabelDistance: -10,
            tickFormat: function(d) {
              return d.toFixed(0) + '%';
            },
          },
          tooltip: {
            contentGenerator: (d) => {
              const content = `
                  <div class="tooltip-key">
                    <span class="tooltip-color-indicator" style="background-color: ${
                      d.color
                    };"></span>
                    ${this._$translate.instant(
                      'CARDS.SOCIAL_CLASS.VALUES.' + SOCIAL_CLASS[d.data.label],
                    )}
                  </div>
                  <div class="tooltip-value">${d.data.percentage.toFixed(
                    1,
                  )}%</div>`;
              return content;
            },
          },
          yDomain: [0, 100],
        },
      };

      $rootScope.$on('$translateChangeEnd', () => {
        this.options.chart.xAxis.axisLabel = this._$translate.instant(
          'CARDS.SOCIAL_CLASS.TITLE',
        );
        this.options.chart.yAxis.axisLabel = this._$translate.instant(
          'COMPONENTS.CARD.AUDIENCE',
        );
        this.options.chart.noData = this._$translate.instant(
          'COMPONENTS.CARD.MESSAGES.NO_DATA',
        );
      });
    }
  },
};
