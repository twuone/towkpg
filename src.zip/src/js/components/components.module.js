import angular from 'angular';

import { ActivityIndicatorComponent } from './activity-indicator.component';
import { AudienceCounterComponent } from './audience-counter.component';
import { BaseSelectorComponent } from './base-selector.component';
import { CardComponent } from './card.component';
import { FilterClusterPlacesComponent } from './filter-cluster-places.component';
import { FilterGroupComponent } from './filter-group/filter-group.component';
import { FiltersOutputComponent } from './filters-output.component';
import { CheckboxFilterComponent } from './checkbox-filter/checkbox-filter.component';
import { GoogleMapsComponent } from './google-maps.component';
import { LayerSelectorComponent } from './layer-selector.component';
import { MenuFiltersComponent } from './menu-filters.component';
import { ModalCampaignSimpleComponent } from './modal/modal-campaign-simple.component';
import { ModalCampaignComponent } from './modal/modal-campaign.component';
import ModalChoroplethSelector from './modal/modal-choropleth-selector.component';
import ModalClusteredPlacesFilter from './modal/modal-clustered-places-filter.component';
import ModalCnaeFilter from './modal/modal-cnae-filter.component';
import ModalConfig from './modal/modal-config.component';
import ModalDetails from './modal/modal-details.component';
import ModalEditPlace from './modal/modal-edit-place.component';
import ModalLayerManager from './modal/modal-layer-manager.component';
import ModalNewPolygon from './modal/modal-new-polygon.component';
import { ModalPasswordChangeComponent } from './modal/modal-password-change.component';
import ModalPlaces from './modal/modal-places.component';
import { ModalRequestDocumentsComponent } from './modal/modal-request-documents.component';
import ModalSelectDimensions from './modal/modal-select-dimensions.component';
import MosaicFilter from './mosaic-filter.component';
import MosaicPjFilter from './mosaic-pj-filter.component';
import OmniSearch from './omni-search.component';
import OnFileChange from './on-file-change.directive';
import PanelCompare from './panel-compare.component';
import PanelManager from './panel-manager.component';
import { PanelNotColumnComponent } from './panel-not-column.component';
import PanelPrimary from './panel-primary.component';
import { PolisInboxComponent } from './polis-inbox/polis-inbox.component';
import { ReportColumnComponent } from './report-column.component';
import { ReportNotColumnComponent } from './report-not-column.component';
import ReportSegment from './report-segment.component';
import ShowAuthed from './show-authed.directive';

export const ComponentsModule = angular
  .module('app.components', [])
  .component('activityIndicator', ActivityIndicatorComponent)
  .component('audienceCounter', AudienceCounterComponent)
  .component('baseSelector', BaseSelectorComponent)
  .component('card', CardComponent)
  .component('checkboxFilter', CheckboxFilterComponent)
  .component('filterClusterPlaces', FilterClusterPlacesComponent)
  .component('filterGroup', FilterGroupComponent)
  .component('filtersOutput', FiltersOutputComponent)
  .component('googleMaps', GoogleMapsComponent)
  .component('layerSelector', LayerSelectorComponent)
  .component('menuFilters', MenuFiltersComponent)
  .component('modalCampaign', ModalCampaignComponent)
  .component('modalCampaignSimple', ModalCampaignSimpleComponent)
  .component('modalChoroplethSelector', ModalChoroplethSelector)
  .component('modalClusteredPlacesFilter', ModalClusteredPlacesFilter)
  .component('modalCnaeFilter', ModalCnaeFilter)
  .component('modalConfig', ModalConfig)
  .component('modalDetails', ModalDetails)
  .component('modalEditPlace', ModalEditPlace)
  .component('modalLayerManager', ModalLayerManager)
  .component('modalNewPolygon', ModalNewPolygon)
  .component('modalPasswordChange', ModalPasswordChangeComponent)
  .component('modalPlaces', ModalPlaces)
  .component('modalRequestDocuments', ModalRequestDocumentsComponent)
  .component('modalSelectDimensions', ModalSelectDimensions)
  .component('mosaicFilter', MosaicFilter)
  .component('mosaicPjFilter', MosaicPjFilter)
  .component('omniSearch', OmniSearch)
  .component('panelCompare', PanelCompare)
  .component('panelManager', PanelManager)
  .component('panelNotColumn', PanelNotColumnComponent)
  .component('panelPrimary', PanelPrimary)
  .component('polisInbox', PolisInboxComponent)
  .component('reportColumn', ReportColumnComponent)
  .component('reportNotColumn', ReportNotColumnComponent)
  .component('reportSegment', ReportSegment)
  .directive('onFileChange', OnFileChange)
  .directive('showAuthed', ShowAuthed).name;
