import {
  SET_ALL_PLACES_TYPES,
  REMOVE_ALL_PLACES_TYPES,
  REFRESH_MARKER_CLUSTER,
} from '../app.actions';
import template from './filter-cluster-places.html';

export const FilterClusterPlacesComponent = {
  require: {
    googleMapCtrl: '^googleMaps',
  },
  bindings: {
    data: '=',
    total: '=',
  },
  template,
  controller: class FilterClusterPlacesComponent {
    constructor(PLACES, $translate, $scope) {
      'ngInject';

      this.PLACES = PLACES;
      this.placesSelection = { ...PLACES };
      this.placesInFilter = { ...PLACES };
      this.$translate = $translate;

      const self = this;

      const keys = Object.keys(this.placesSelection);
      const length = keys.length;

      for (let i = 0; i < length; i++) {
        this.placesSelection[keys[i]] = false;
        this.placesInFilter[keys[i]] = true;
      }

      this.refreshMarkerCluster = () => {
        const places = [];
        for (let i = 0; i < keys.length; i++) {
          if (this.placesSelection[keys[i]]) {
            places.push(keys[i]);
          }
        }
        this.googleMapCtrl.clusteredPlaces(places);
      };

      this.removeFilterPlaces = () => {
        for (let i = 0; i < length; i++) {
          this.placesSelection[keys[i]] = false;
        }
      };

      this.addAllFilterPlaces = () => {
        for (let i = 0; i < length; i++) {
          this.placesSearchFilter = '';
          this.placesSelection[keys[i]] = true;
          this.placesInFilter[keys[i]] = true;
        }
      };

      this.placesSearchFilter = '';

      $scope.$on(SET_ALL_PLACES_TYPES, () => self.addAllFilterPlaces());
      $scope.$on(REMOVE_ALL_PLACES_TYPES, () => self.removeFilterPlaces());
      $scope.$on(REFRESH_MARKER_CLUSTER, () => self.refreshMarkerCluster());

      this.filterPlaceOnTextChange = () => {
        const keys = Object.keys(this.placesSelection);
        for (let i = 0; i < keys.length; i++) {
          if (
            this.$translate
              .instant('CARDS.PLACES.VALUES.' + keys[i])
              .toLowerCase()
              .indexOf(this.placesSearchFilter.toLowerCase()) != -1 ||
            this.placesSearchFilter == ''
          ) {
            this.placesInFilter[keys[i]] = true;
          } else {
            this.placesInFilter[keys[i]] = false;
            this.placesSelection[keys[i]] = false;
          }
        }
      };
    }
  },
};
