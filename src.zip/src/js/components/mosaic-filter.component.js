import template from './mosaic-filter.html';

class MosaicFilterCtrl {
  constructor(MOSAIC, $scope, $rootScope, DimensionService, User) {
    'ngInject';
    this.DimensionService = DimensionService;
    this.user = User;
 
    // init public variables
    // this.mosaic = MOSAIC;
    this.mosaic;

    // this.mosaic = MOSAIC;
    this.all = true;
  
    $rootScope.$on('setMenuFilter', (e, data) => {
      if (data['mosaic'] && data['mosaic'].length > 0) {
        let keys = Object.keys(this.ngModel);
        for (let i = 0; i < keys.length; i++) {
          this.ngModel[keys[i]] = data['mosaic'].includes(keys[i]);
        }
      }
    });
  }

  $onInit() {
    this.fetchDimensions();
  }

  fetchDimensions() {
    return this.DimensionService.fetch().then((dimensions) => {
      this.DimensionService.setAvailableGroups(dimensions, this.user.getConfig());

      this.mosaic = this.DimensionService.getValueChartSame(dimensions, 'mosaic');
    });
  };

  toggle(ctrl, value) {
    ctrl.ngModel = ctrl.ngModel || {};

    if (ctrl.ngModel[value]) {
      ctrl.ngModel[value] = !ctrl.ngModel[value];
    } else {
      ctrl.ngModel[value] = true;
    }
  }

  toggleAll(ctrl) {
    this.all = !this.all;
    for (let key in ctrl.mosaic) {
      // this.toggle(ctrl, key);
      ctrl.ngModel[key] = this.all;
    }
  }
}

let MosaicFilter = {
  bindings: {
    ngModel: '=',
  },
  template,
  controller: MosaicFilterCtrl,
};

export default MosaicFilter;
