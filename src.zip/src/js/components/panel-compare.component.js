import { RESET_NOT_PANEL_COMPLETELY } from '../app.actions';
import template from './panel-cards.html';

class PanelCompareCtrl {
  constructor(
    Cards,
    Markers,
    AudienceTypes,
    User,
    Bases,
    $rootScope,
    Layers,
    DimensionService,
  ) {
    'ngInject';

    // init private variables
    this._Markers = Markers;
    this.Layers = Layers;

    // init public variables
    this.marker = Markers.compare;
    this.currentTab = 'residents';
    this.isPanelCompare = true; // FIXME with CSS
    this.filterWatch = 'compare';
    this.user = User;
    this.Cards = Cards;
    this._Bases = Bases;
    this.Bases = Bases;
    this._$rootScope = $rootScope;
    this.AudienceTypes = AudienceTypes;
    this.panelIndex = 1;
    this.scrollBind = false;
    this.isCompareActive = false;
    this.DimensionService = DimensionService;

    this.$onInit = () => {
      $rootScope.$watch(this.filterWatch, () => {
        this.createCustomCards();
      });
    };
  }

  bindScrollers() {
    this.scrollBind = !this.scrollBind;
    if (this.scrollBind) {
      $('.panel-cards .panel-content').scroll(function() {
        $('.panel-cards .panel-content').scrollTop($(this).scrollTop());
      });
    } else {
      $('.panel-cards .panel-content').off('scroll');
    }
  }

  toggleCompareColumn() {
    this.isCompareActive = !this.isCompareActive;
    if (this.isCompareActive) {
      this.Cards.compareForNotColumn();
    } else {
      $('.panel-not-column').removeClass('is-open');
    }
  }

  setTab(tab) {
    this.currentTab = tab;
  }

  dismissPanel() {
    this._Markers.compare.guid = null;
    this._$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
  }

  createCustomCards() {
    if (this.Bases.customFields) {
      this.customCards = {};
      const customKeys = Object.keys(this.Bases.customFields).sort();

      for (let i = customKeys.length - 1; i >= 0; i--) {
        const card = {
          chartType: 'generic',
          url: '/' + customKeys[i],
          iconClass: 'mdi-chart-arc',
          customName: customKeys[i].toUpperCase(),
          custom: true,
        };

        for (let a = 0; a < this.AudienceTypes.available.length; a++) {
          if (!this.customCards[this.AudienceTypes.available[a]]) {
            this.customCards[this.AudienceTypes.available[a]] = [];
          }
          this.customCards[this.AudienceTypes.available[a]].unshift(card);
        }
      }
    } else {
      this.customCards = null;
    }
  }
}

const PanelCompare = {
  bindings: {
    cards: '=',
  },
  template,
  controller: PanelCompareCtrl,
};

export default PanelCompare;
