import template from './report-segment.html';

class ReportSegmentCtrl {
  constructor(Bases, AudienceTypes, $translate, Cards) {
    'ngInject';

    this._$translate = $translate;
    this._Bases = Bases;
    this._AudienceTypes = AudienceTypes;
    this._Cards = Cards;
    this.options = {
      chart: {
        type: 'pieChart',
        height: 340,
        x: (d) => {
          return this._$translate.instant(
            this.getValueTrans(this.segment, d.label),
          );
        },
        y: (d) => {
          return d.percentage;
        },
        showLabels: true,
        duration: 500,
        labelThreshold: 0.01,
        labelSunbeamLayout: false,
        tooltip: {
          contentGenerator: (d) => {
            let label = this._$translate.instant(
              this.getValueTrans(this.segment, d.data.label),
            );
            if (this.segment == 'state_city') {
              label = this.cityFilterUF(label);
            }

            if (d.data.label == 'others' && this.segment == 'state_city') {
              const frag1 = this._$translate.instant(
                'DATA_VIEW.OTHERS_CITIES.MSG1a',
              );
              const frag2 = this._$translate.instant(
                'DATA_VIEW.OTHERS_CITIES.MSG1b',
              );
              const frag3 = this._$translate.instant(
                'DATA_VIEW.OTHERS_CITIES.MSG1c',
              );
              label = `*Outros: <br />${frag1}<br />${frag2}<br />${frag3}`;
            }

            const content = `
                                  <div class="tooltip-key">
                                    ${label}
                                  </div>
                                  <div class="tooltip-value">${d.data.percentage.toFixed(
                                    1,
                                  )}%</div>`;
            return content;
          },
        },
        donut: true,
        labelType: 'value',
        valueFormat(d) {
          if (d > 3) {
            return d.toFixed(1) + '%';
          }
        },
        showLegend: false,
        callback: () => {
          // Dispatch a resize event on every tab change
          // so D3 awakens to do any necessary redrawing
          setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
          }, 200);
        },
      },
    };

    this.$onInit = () => {
      if (this.segment == 'state_city') {
        this.table = 'state_city_table';
      } else {
        this.table = this.segment;
      }
    };
  }

  cityFilterUF(text) {
    if (text.toLowerCase() == 'none_none') {
      return 'Desconhecido';
    }
    if (text.toLowerCase() == 'unknown_unknown') {
      return 'Desconhecido';
    }

    if (text.indexOf('_') != -1) {
      const temp = text.split('_')[0];
      const frag = text.split('_');
      frag.splice(0, 1);
      let stringConcat = '';
      for (let i = 0; i < frag.length; i++) {
        stringConcat += frag[i] + ' ';
      }
      text = temp.toUpperCase() + ' - ' + stringConcat;
    }
    return text;
  }

  getAvailableValues() {
    this.availableValues = new Set();
    this._Bases.applied.forEach((base) => {
      if (base.data) {
        base.data.cards[this.segment].forEach((item) =>
          this.availableValues.add(item.label),
        );
      }
    });

    this.availableValues = Array.from(this.availableValues);
    return this.availableValues;
  }

  getCurrentValue(obj, label) {
    return obj.filter((item) => {
      return item.label == label;
    })[0].value;
  }

  getTitle() {
    let title = this.segment;
    const info = this._Bases.info[
      this._AudienceTypes.applied + '_' + this.segment
    ];
    if (info) {
      title = 'CARDS.' + info.translation_id + '.TITLE';
    }
    return title;
  }

  getValueDesc(value) {
    let valueDesc = value;
    try {
      const info = this._Bases.info[
        this._AudienceTypes.applied + '_' + this.segment
      ];

      if (info && info.constants) {
        valueDesc =
          'CARDS.' + info.translation_id + '.VALUES.' + info.constants[value];
      }
    } catch (err) {
      return value;
    }
    return valueDesc;
  }

  getValueTrans(segment, value) {
    try {
      if (this._AudienceTypes.applied == 'companies' && segment == 'mosaic') {
        segment += '_PJ';
      }
      const description = this._$translate.instant(
        'CARDS.' + segment.toUpperCase() + '.VALUES.' + value.toUpperCase(),
      );
      if (description.substring(0, 6) == 'CARDS.') {
        return value;
      } else {
        return description;
      }
    } catch (err) {
      return value;
    }
  }

  getTitleTrans(value) {
    const description = this._$translate.instant(
      'CARDS.' + value.toUpperCase() + '.TITLE',
    );
    if (description.substring(0, 7) == 'CUSTOM_') {
      return value;
    } else {
      return description;
    }
  }
}

const ReportSegment = {
  template,
  controller: ReportSegmentCtrl,
  bindings: {
    segment: '=',
    base: '=',
    extCard: '<',
  },
};

export default ReportSegment;
