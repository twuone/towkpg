import template from './panel-manager.html';

class PanelManagerCtrl {
  constructor(Markers, Cards) {
    'ngInject';

    // init public variables
    this.cards = {};

    // options to the first panel
    this.primary = {
      main: true,
      marker: Markers.primary,
    };

    // options to the second panel
    this.secondary = {
      marker: Markers[1],
    };

    // dynamic cards part
    Cards.getCards('residents').then((res) => {
      this.cards.residents = res;
    });

    Cards.getCards('workers').then((res) => {
      this.cards.workers = res;
    });

    Cards.getCards('visitors').then((res) => {
      this.cards.visitors = res;
    });
  }
}

const PanelManager = {
  controller: PanelManagerCtrl,
  template,
};

export default PanelManager;
