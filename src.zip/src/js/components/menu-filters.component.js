import {
  DefaultFilters,
  DURATION_START_HOUR_INDEX,
  DURATION_STOP_HOUR_INDEX,
} from './menu-filters.model';
import {
  IMPORT_MARKERS_FINISHED,
  CHANGE_AUDIENCE_TYPE_SELECTION,
  RESET_NOT_PANEL_COMPLETELY,
  SELECT_UI_TAG_MANAGER,
  CHANGE_LAYER_MODE,
  REFRESH_PLACES_LIST,
  SET_MENU_FILTER,
} from '../app.actions';
import { sortByProperty as byProperty } from '../core/util/arrays';
import template from './menu-filters.html';

export const MenuFiltersComponent = {
  template,
  controller: class MenuFiltersComponent {
    constructor(
      $filter,
      $q,
      $ngRedux,
      $log,
      $rootScope,
      $scope,
      $state,
      $translate,
      AudienceTypes,
      Bases,
      Campaign,
      Cards,
      CS_RENDA,
      CS_CSBA_BV,
      CS_RENDA_BV,
      CS_RESTRITIVO,
      CS_CBFS,
      CS_SCORE,
      DimensionService,
      FILTER_DESC,
      Filters,
      FilterService,
      Layers,
      MapValues,
      Markers,
      Modal,
      NgMap,
      PanelStateService,
      Places,
      SweetAlert,
      Tab,
      User,
      WEEK_DAYS,
    ) {
      'ngInject';

      this.$filter = $filter;
      this.$q = $q;
      this.$rootScope = $rootScope;
      this.$scope = $scope;
      this.$state = $state;
      this.$ngRedux = $ngRedux;
      this.$translate = $translate;
      this.$log = $log;

      this.AudienceTypes = AudienceTypes;
      this.Bases = Bases;

      this.Campaign = Campaign;
      this.Cards = Cards;

      this.CS_CSBA_BV = CS_CSBA_BV;
      this.CS_RENDA = CS_RENDA;
      this.CS_RENDA_BV = CS_RENDA_BV;
      this.CS_RESTRITIVO = CS_RESTRITIVO;
      this.CS_CBFS = CS_CBFS;
      this.CS_SCORE = CS_SCORE;
      this.DURATION_START_HOUR_INDEX = DURATION_START_HOUR_INDEX;
      this.DURATION_STOP_HOUR_INDEX = DURATION_STOP_HOUR_INDEX;
      this.DimensionService = DimensionService;
      this.FILTER_DESC = FILTER_DESC;
      this.Filters = Filters;
      this.FilterService = FilterService;

      this.GENDER;
      this.INCOME_RANGE;
      this.Layers = Layers;
      this.MapValues = MapValues;

      this.Markers = Markers;
      this.Modal = Modal;
      this.NgMap = NgMap;
      this.PanelStateService = PanelStateService;
      this.Places = Places;
      this.REGISTRATION_STATUS;

      this.SweetAlert = SweetAlert;
      this.Tab = Tab;
      this.user = User;
      this.WEEK_DAYS = WEEK_DAYS;
    }

    $onInit() {
      this.fetchDimensions();

      this.state = {
        collapsed: {},
      };
      this.filters = this.Filters.filters;
      this.filters.mosaic = {};
      this.dateRange = this.Filters.dateRange;
      this.marker = this.Markers.primary;
      this.isAllMarkersSelected = true;
      this.isActiveTabFilters = true;
      this.tags = [];
      this.tagManagerOpen = false;
      this.defaults = {
        activesFiltersDesc: [],
      };
      this.firstPageItem = 0;
      this.lastPageItem = this.numberOfItemsPerPage;
      this.numberOfItemsPerPage = 10;
      this.placesFiltered = [];

      // attempts to calculate NOT column
      this.maximumOfAttempts = 60;

      this.AudienceTypes.available.forEach((audience) => {
        this[audience] = this.Filters[audience].filters;
      });

      // Affinities
      this.isOpenDropdownAffinities = false;

      // Get instance of map (only in Map View)
      if (this.$state.current.name === 'app.map-view') {
        this.NgMap.getMap('map').then((map) => {
          this.map = map;
        });
      }

      this.nextMarkers = () => {
        if (this.firstPageItem < this.Places.places.length) {
          this.firstPageItem += this.numberOfItemsPerPage;
        }
        this.slicePlacesList(this.firstPageItem);
      };

      this.prevMarkers = () => {
        if (this.firstPageItem < this.Places.places.length) {
          this.firstPageItem -= this.numberOfItemsPerPage;
        }
        this.slicePlacesList(this.firstPageItem);
      };

      this.$rootScope.$on(
        IMPORT_MARKERS_FINISHED,
        this.onMarkersImportFinished.bind(this),
      );

      this.filters.mosaic = this.Filters.getMosaicFilter(this.Tab.cards);

      const defaultFilters = { ...DefaultFilters };

      if (this.visitors) {
        this.visitors.social_class = defaultFilters.visitors.socialClass;

        this.visitors.dayofweek = {};
        for (const key in this.WEEK_DAYS) {
          this.visitors.dayofweek[key] = true;
        }

        this.visitors.period = defaultFilters.visitors.period;

        this.visitors.duration = defaultFilters.visitors.duration;

        this.$scope.$watch(
          `$ctrl.visitors.duration[${DURATION_START_HOUR_INDEX}]`,
          this.onVisitorsDurationStartChanged.bind(this),
        );

        this.$scope.$watch(
          `$ctrl.visitors.duration[${DURATION_STOP_HOUR_INDEX}]`,
          this.onVisitorsDurationStopChanged.bind(this),
        );
      }

      this.filters.unknownInfo = defaultFilters.filters.unknownInfo;

      this.registrationStatusPool = {
        residents: [
          'regular',
          'unknown',
          'suspended',
          'nulled',
          'pending',
          'canceled',
        ],
        companies: [
          'active',
          'inactive',
          'deactivated',
          'suspended',
          'nulled',
          'inapt',
          'unknown',
        ],
      };

      this.checkRegStatus = (key) => {
        return this.registrationStatusPool[
          this.AudienceTypes.selected
        ].includes(key);
      };

      this.$scope.$on(CHANGE_LAYER_MODE, this.onLayerModeChanged.bind(this));

      // BV financeira: CSBA
      this.residents.cs_csba_bv = {
        ...defaultFilters.residents.csCsbaBV,
      };

      // Renda Presumida BV
      this.residents.cs_renda_bv = defaultFilters.residents.csRendaBv;

      // CS restritivos
      this.residents.cs_restritivo = defaultFilters.residents.csRestritivo;

      this.$ngRedux.subscribe(() => {
        const { affinities } = this.$ngRedux.getState();

        this.fillAffinities(
          Object.values(affinities).map((affinity) => affinity.name),
        );
      });

      this.isAllFiltersSelected = false;
      this.searchFilter = '';

      this.Places.getPlaces().then(() => {
        this.slicePlacesList(0);
      });

      this.$rootScope.$on(REFRESH_PLACES_LIST, () => this.slicePlacesList(0));
      this.$rootScope.$on(SET_MENU_FILTER, this.onSetMenuFilter.bind(this));
    }

    fetchDimensions() {
      return this.DimensionService.fetch().then((dimensions) => {
        this.DimensionService.setAvailableGroups(
          dimensions,
          this.user.getConfig(),
        );

        const defaultFilters = { ...DefaultFilters };

        this.filters.registration_status =
          defaultFilters.filters.registrationStatus;

        this.filters.credit_risk = this.Filters.getCreditRiskFilter(
          this.AudienceTypes.applied,
        );

        this.residents.gender = defaultFilters.residents.gender;
        this.residents.social_class = defaultFilters.residents.socialClass;
        this.residents.age = defaultFilters.residents.age;

        this.filters.registration_status =
          defaultFilters.filters.registrationStatus;
        this.REGISTRATION_STATUS = this.filters.registration_status;

        this.residents.social_class = defaultFilters.residents.socialClass;

        // scholarity defaults
        this.residents.scholarity = defaultFilters.residents.scholarity;

        // occupation
        this.residents.occupation = defaultFilters.residents.occupation;

        // mobile defaults
        this.residents.phone = defaultFilters.residents.phone;

        // bolsa_familia defaults
        this.residents.public_sector = defaultFilters.residents.publicSector;

        this.residents.shareholder_inclination =
          defaultFilters.residents.shareholderInclination;

        // residents quantity defaults
        this.residents.residents_quantity =
          defaultFilters.residents.residentsQuantity;

        // income defaults
        this.residents.income_range = defaultFilters.residents.incomeRange;
        this.INCOME_RANGE = this.residents.income_range;

        // CredSystem: Renda Presumida
        this.residents.cs_renda = defaultFilters.residents.csRenda;

        this.residents.cs_csba = defaultFilters.residents.csCsba;


        this.residents.bolsa_familia = defaultFilters.residents.bolsaFamilia;

        // mobile defaults
        this.residents.mobile = defaultFilters.residents.mobile;

        // phone defaults
        this.companies.phone = defaultFilters.companies.phone;

        // marital status
        this.residents.marital_status = defaultFilters.residents.maritalStatus;

        this.companies.rural_producer = defaultFilters.companies.ruralProducer;

        this.companies.existence_time = defaultFilters.companies.existenceTime;

        // rural_producer defaults
        this.companies.headquarters = defaultFilters.companies.headquarters;

        // number_of_employees defaults 
        this.companies.number_of_employees =
          defaultFilters.companies.numberOfEmployees;

        // rural_producer defaults
        this.companies.size = defaultFilters.companies.size;

        // estimated_revenue defaults
        this.companies.estimated_revenue =
          defaultFilters.companies.estimatedRevenue;

        // operability_index_desc defaults
        this.companies.operability_index_desc =
          defaultFilters.companies.operabilityIndexDesc;

        // number_of_branch_offices defaults
        this.companies.number_of_branch_offices =
          defaultFilters.companies.numberOfBranchOffices;

        // number_of_branch_offices defaults
        this.companies.binary_chart = this.DimensionService.getValueChartPJ(
          dimensions,
          'binary_chart',
        );

        // ADDRESS_ACCURACY defaults
        this.filters.address_accuracy = defaultFilters.filters.addressAccuracy;

        // rural_producer defaults
        this.companies.simples_nacional =
          defaultFilters.companies.simplesNacional;
      });
    }

    fillAffinities(affinities) {
      this.defaults.filter_desc = affinities
        .map((filterName) => ({
          name: filterName,
          label: this.FILTER_DESC[filterName].label,
          translatedLabel: this.$translate.instant(
            this.FILTER_DESC[filterName].label,
          ),
        }))
        .sort(byProperty('translatedLabel'));
      this.selectedFilters = this.defaults.filter_desc.reduce(
        (selectedFilters, filter) => {
          selectedFilters[filter.name] = {
            ...filter,
            checked: false,
            isActive: true,
          };
          return selectedFilters;
        },
        {},
      );
    }

    onMarkersImportFinished() {
      this.Places.getPlaces().finally(() => {
        this.slicePlacesList(0);
      });
    }

    onLayerModeChanged() {
      this.filters.address_accuracy = {
        geolocation: true,
        address: true,
        city: true,
        state: true,
        none: true,
      };
    }

    onVisitorsDurationStartChanged(value) {
      if (value >= this.visitors.duration[DURATION_STOP_HOUR_INDEX]) {
        this.visitors.duration[DURATION_STOP_HOUR_INDEX]++;
      }
    }

    onVisitorsDurationStopChanged(value) {
      if (value <= this.visitors.duration[DURATION_START_HOUR_INDEX]) {
        this.visitors.duration[DURATION_START_HOUR_INDEX]--;
      }
    }

    slicePlacesList(index) {
      // filter
      this.placesFiltered = [];
      for (let i = 0; i < this.Places.places.length; i++) {
        if (
          this.Places.places[i].showOnList == true ||
          this.Places.places[i].showOnList == undefined ||
          !this.tags.length
        ) {
          this.placesFiltered.push(this.Places.places[i]);
        }
      }

      // Avoid negative indexes and Handle paginator begin
      if (index < 0) {
        index = 0;
      }

      // Handle paginator overflow
      if (index == this.placesFiltered.length) {
        index =
          Math.floor(this.placesFiltered.length / this.numberOfItemsPerPage) *
          this.numberOfItemsPerPage;

        // handle indexes multiple of ten
        if (index == this.placesFiltered.length) {
          index -= this.numberOfItemsPerPage;
        }
      }

      // set first item of page
      this.firstPageItem = index;

      // determine last page item
      this.lastPageItem = index + this.numberOfItemsPerPage - 1;
      if (this.lastPageItem > this.placesFiltered.length - 1) {
        this.lastPageItem = this.placesFiltered.length - 1;
      }

      // Note => slice() is NOT inclusive, therefore we must to sum +1 in it
      this.placesPagination = this.placesFiltered.slice(
        index,
        this.lastPageItem + 1,
      );
    }

    onSetMenuFilter(e, data) {
      this.AudienceTypes.available.forEach((type) => {
        const keys = Object.keys(this[type]);
        for (let i = 0; i < keys.length; i++) {
          if (data[keys[i]] != undefined) {
            if (this[type][keys[i]].constructor === Array) {
              // TODO: logic for arrays here data type, for residents, if needed
              continue;
            } else {
              const keyItems = Object.keys(this[type][keys[i]]);
              for (let k = 0; k < keyItems.length; k++) {
                this[type][keys[i]][keyItems[k]] = data[keys[i]].includes(
                  keyItems[k],
                );
              }
            }
          }
        }

        const keysFilter = Object.keys(this.filters);
        const affinitiesKeys = Object.keys(this.selectedFilters);
        for (let f = 0; f < keysFilter.length; f++) {
          if (
            data[keysFilter[f]] != undefined &&
            !affinitiesKeys.includes(keysFilter[f])
          ) {
            if (this.filters[keysFilter[f]].constructor === Array) {
              // TODO: logic for arrays here for visitors, in the future
              continue;
            } else {
              const keyItems = Object.keys(this.filters[keysFilter[f]]);
              for (let k = 0; k < keyItems.length; k++) {
                this.filters[keysFilter[f]][keyItems[k]] = data[
                  keysFilter[f]
                ].includes(keyItems[k]);
              }
            }
          }
        }

        for (let af = 0; af < affinitiesKeys.length; af++) {
          if (data[affinitiesKeys[af]] != undefined) {
            this.selectedFilters[affinitiesKeys[af]].checked = true;
            this.filters[affinitiesKeys[af]] = data[affinitiesKeys[af]][0];
          } else {
            this.selectedFilters[affinitiesKeys[af]].checked = false;
            this.selectedFilters[affinitiesKeys[af]].isActive = true;
          }
        }
      });
    }

    addTooltip($event) {
      if (
        !this.Markers.primary.guid &&
        this.$state.current.name == 'app.map-view'
      ) {
        $($event.target).tooltip('show');
      }
    }

    cleanBasesSelection() {
      this.Layers.cleanSelection();
    }

    selectAllFilters() {
      this.isAllFiltersSelected = true;
      const keys = Object.keys(this.selectedFilters);
      keys.forEach((key) => {
        this.selectedFilters[key].checked = true;
      });
    }

    unselectAllFilters() {
      this.isAllFiltersSelected = false;
      const keys = Object.keys(this.selectedFilters);
      keys.forEach((key) => {
        this.selectedFilters[key].checked = false;
      });
    }

    filterOnTextChange() {
      const keys = Object.keys(this.FILTER_DESC);
      keys.map((key) => {
        if (
          !this.selectedFilters[key] ||
          this.selectedFilters[key] === undefined
        ) {
          return;
        } else {
          this.selectedFilters[key].isActive = !(
            this.FILTER_DESC[key].label
              .toUpperCase()
              .indexOf(this.searchFilter.toUpperCase()) === -1
          );
        }
      });
    }

    toggleTagManager() {
      $('.marker-manager-toolbox .tag-manager *').on('click', (evt) => {
        evt.stopPropagation();
      });

      // $('.marker-manager-toolbox .tag-manager .ui-select-search').on('blur', (evt) =>{
      // 	this.toggleTagManager();
      // });

      this.tagManagerOpen = !this.tagManagerOpen;

      // if(this.tagManagerOpen) {
      // 	$('.marker-manager-toolbox .tag-manager .ui-select-search').trigger('focus');
      // }

      if (this.tagManagerOpen) {
        this.$scope.$broadcast(SELECT_UI_TAG_MANAGER);
      }
    }

    // Will be reimplemented whit the places service remake
    toggleClass(dom, className) {
      dom = dom.parentElement;
      if (!dom.classList.contains('marker-item')) {
        dom = dom.parentElement;
      }

      if (dom.classList.contains(className)) {
        dom.classList.remove(className);
      } else {
        dom.classList.add(className);
      }
    }

    toggleGroupCollapse(groupName = 'serasa') {
      this.state.collapsed[groupName] = this.state.collapsed[groupName]
        ? !this.state.collapsed[groupName]
        : true;
    }

    toggleAllMarkers() {
      this.isAllMarkersSelected = !this.isAllMarkersSelected;

      this.Places.places.forEach((place) => {
        place.hidden = !this.isAllMarkersSelected;
      });
    }

    toggleButton(key, args) {
      return (args[key] = args[key] ? false : true);
    }

    applyBaseCompare() {
      // COMBAK: Consolidate this into function. It has many repetition of same code on google maps

      if (
        this.Bases.applied[1].id &&
        (this.Layers.activated || this.Markers.primary.guid)
      ) {
        this.Markers.compare.guid = this.Markers.primary.guid;
        this.Markers.compare.desc = this.Markers.primary.desc;
        this.Markers.compare.title = this.Markers.primary.title;

        if (
          this.Markers.primary.points &&
          this.Markers.primary.points.length <= 1
        ) {
          this.Markers.compare.center.lat = this.Markers.primary.points[0].latitude;
          this.Markers.compare.center.lng = this.Markers.primary.points[0].longitude;
        }
      }
    }

    selectPlace(place) {
      this.Bases.applySelection();
      this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
      this.Markers.compare.guid = null;
      this.Cards.layerMode = false;
      $('.panel-cards').addClass('is-open');

      if (this.Layers.activated) {
        this.Layers.reset();
      }
      this.Layers.activated = false;
      this.$rootScope.$broadcast(CHANGE_LAYER_MODE, {});
      $('.panel-primary').addClass('is-open');
      this.showPlace(place);

      this.Markers.primary.guid = place.id;
      this.Markers.primary.desc = place.desc;
      this.Markers.primary.title = place.title;
      this.AudienceTypes.previous = this.AudienceTypes.applied;
      this.AudienceTypes.applied = this.Tab.cards;

      if (place.points.length <= 1) {
        this.Markers.primary.type = 'place';
        this.Markers.primary.center.lat = place.points[0].latitude;
        this.Markers.primary.center.lng = place.points[0].longitude;
      } else {
        this.Markers.primary.type = 'polygon';
      }

      this.applyBaseCompare();

      this.MapValues.center.lat = place.points[0].latitude;
      this.MapValues.center.lng = place.points[0].longitude;

      // set zoom based on what is returned on google's API viewport
      this.map.setZoom(14);
    }

    comparePlace(place) {
      this.clearBaseSelection();
      this.Bases.applySelection();
      $('.panel-cards').addClass('is-open');
      this.Markers.compare.guid = place.id;
      this.Markers.compare.desc = place.desc;
      this.Markers.compare.title = place.title;
      this.AudienceTypes.previous = this.AudienceTypes.applied;
      this.AudienceTypes.applied = this.Tab.cards;
      if (place.points.length <= 1) {
        this.Markers.compare.center.lat = place.points[0].latitude;
        this.Markers.compare.center.lng = place.points[0].longitude;
      }
    }

    editPlace(place) {
      this.Places.edittingPlace = place;
      this.Places.formPlace = angular.copy(place);

      if (this.Places.formPlace.decorator) {
        this.Places.formPlace.decorator.color =
          '#' + this.Places.formPlace.decorator.color;
      } else {
        this.Places.formPlace.decorator = {
          color: '#FE7569',
        };
      }

      $('#editPlaceModal').modal('show');
      this.Modal.setCurrentModal('modal-edit-place');
    }

    openModalCampaign() {
      const fmtFilters = this.Filters.getFiltersAsString();

      this.Campaign.setOptions({
        multi: true,
        tags: this.tags,
        fmtFilters,
      });

      $('#campaignModal').modal('show');
    }

    openModalCnae() {
      $('#CNAEFilterModal')
        .modal('show')
        .on('hidden.bs.modal', () => {
          this.Modal.setCurrentModal(null);
        });

      //this.Modal.setCurrentModal('modal-cnae-filter');
    }

    openModalLayerManager() {
      $('#layerManagerModal')
        .modal('show')
        .on('hidden.bs.modal', () => {
          this.Modal.setCurrentModal(null);
        });
      this.Modal.setCurrentModal('modal-layer-manager');
    }

    onAddTag(item, model) {
      this.filterPlacesByTag();
    }

    onRemoveTag(item, model) {
      this.filterPlacesByTag();
    }

    removeAffinityFilter(affinity) {
      this.filters[affinity] = false;
      this.selectedFilters[affinity].checked = false;
    }

    filterPlacesByTag() {
      this.Places.places.forEach((place) => {
        place.showOnList = true;
        if (place.tags && place.tags instanceof Array) {
          this.tags.forEach((tag) => {
            if (place.tags.some((t) => t === tag) === false) {
              place.showOnList = false;
            }
          });
        } else {
          place.showOnList = false;
        }
      });
      this.firstPageItem = 0;
      this.slicePlacesList(this.firstPageItem);
    }

    hasPlacesWithTags() {
      return this.Places.places.some((place) => {
        return place.showOnList;
      });
    }

    clearBaseSelection() {
      this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);

      this.Markers.compare.guid = null;
      for (let i = 0; i < this.Bases.selection.length; i++) {
        if (i == 0) {
          continue;
        }
        this.Bases.selection[i].id = null;
        this.Bases.consolidateCustomFields();
      }
      this.Cards.baseIdCompare = null;
    }

    cleanTags() {
      this.tags = [];
      this.slicePlacesList(0);
    }

    setFilterType(type) {
      // Reset Affinities filters to perform a clean request
      if (type == 'companies') {
        const keys = Object.keys(this.filters);
        for (let k = 0; k < keys.length; k++) {
          if (this.defaults.filter_desc.includes(keys[k])) {
            delete this.filters[keys[k]];
          }
        }
      }
      this.Tab.cards = type;
      this.AudienceTypes.selected = type;
      this.filters.credit_risk = this.Filters.getCreditRiskFilter(type);
      this.filters.mosaic = this.Filters.getMosaicFilter(type);
      this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
      this.$rootScope.$broadcast(CHANGE_AUDIENCE_TYPE_SELECTION);
      this.Bases.clearSelection();
      this.Cards.rebuildCardSelection();
      const regisrationStatusKeys = Object.keys(
        this.filters.registration_status,
      );
      for (let i = 0; i < regisrationStatusKeys.length; i++) {
        if (
          regisrationStatusKeys[i] in
          this.registrationStatusPool[this.AudienceTypes.selected]
        ) {
          this.filters.registration_status[regisrationStatusKeys[i]] = true;
        }
      }
    }

    showPlace(place) {
      this.Places.places.find((p) => p === place).hidden = false;
    }

    hidePlace(place) {
      this.Places.places.find((p) => p === place).hidden = true;
    }

    togglePlace(place) {
      const isHidden = this.Places.places.find((p) => p === place).hidden;
      this.Cards.layerMode = false;
      this.Layers.activated = false;

      if (isHidden) {
        this.showPlace(place);
      } else {
        this.hidePlace(place);
      }
    }

    toggleAffinitiesDropdown() {
      this.isOpenDropdownAffinities = !this.isOpenDropdownAffinities;
    }

    toggleDayOfWeek(key) {
      this.visitors.dayofweek[key] = this.visitors.dayofweek[key]
        ? false
        : true;
    }

    submit() {
      this.Bases.applySelection();
      this.Cards.showComparison = false;
      const comparisonElements = Object.keys(this.Cards.dataCardComparison);
      for (let i = 0; i < comparisonElements.length; i++) {
        delete this.Cards.dataCardComparison[comparisonElements[i]];
      }

      this.Markers.compare.guid = null;

      if (this.Layers.activated) {
        if (
          this.Layers.multiField.type != 'invalid' &&
          this.Layers.multiField.value
        ) {
          this.Layers.textFieldSelection();
        } else {
          this.Cards.layerMode = true;
          this.Markers.primary.guid = 'layer';

          let current;

          if (this.Layers.lastSelectedType == 'country') {
            this.Markers.primary.title = this.Layers.lastSelectedValue;
          } else {
            current = this.Layers.options[this.Layers.lastSelectedType].filter(
              (item) => {
                return item.value == this.Layers.lastSelectedValue;
              },
            )[0];
            this.Markers.primary.title = current.label;
          }

          this.Markers.primary.desc = this.$translate.instant(
            `COMPONENTS.MAP.LAYERS.TYPES.${this.Layers.lastSelectedType.toUpperCase()}`,
          );
        }
      } else {
        this.Cards.layerMode = false;
        this.AudienceTypes.previous = this.AudienceTypes.applied;
        this.AudienceTypes.applied = this.Tab.cards;
      }

      this.applyBaseCompare();

      // Reopens Primary Panel if hidden but have new data
      if (
        !$('.panel-primary').hasClass('is-open') &&
        this.Markers.primary.guid
      ) {
        $('.panel-primary').addClass('is-open');
      }

      if (this.Bases.selection[1] && this.Bases.selection[1].id) {
        $('.panel-compare').addClass('is-open');
      }
    }

    /**
     * Ação disparada ao clicar em 'Carregar Dados' a partir do DataView.
     */
    submitDataView() {
      clearInterval(this.sync);
      this.Bases.data_view = {
        masterReport: null,
        slaveReport: null,
      };
      this.Cards.showComparison = false;
      const comparisonElements = Object.keys(this.Cards.dataCardComparison);
      for (let i = 0; i < comparisonElements.length; i++) {
        delete this.Cards.dataCardComparison[comparisonElements[i]];
      }
      this.Bases.applySelection();
      $('.panel-cards').addClass('is-open');
    }

    isValid(value) {
      for (const key in value) {
        if (value[key]) {
          return true;
        }
      }
      return false;
    }

    isFiltersValid() {
      return Boolean(
        (this.isValid(this.filters.mosaic) &&
          this.isValid(this.residents.social_class)) ||
          (this.Tab.isVisitors() &&
            this.filters.unknownInfo &&
            this.isDateRangeValid(this.dateRange)),
      );
    }

    isDateRangeValid(dateRange) {
      // hours * minutes * seconds * miliseconds
      const day = 24 * 60 * 60 * 1000;
      const timeDiference = dateRange.end - dateRange.start;
      if (timeDiference / day < 63) {
        return true;
      }
      return false;
    }

    filterCustomOptions(list, query) {
      const deferred = this.$q.defer();
      deferred.resolve(this.$filter('filter')(list, query));
      return deferred.promise;
    }
 
    onChangeLayerMode() {
      this.Layers.changeMode();
      if (this.Markers.primary.guid != 'layer') {
        this.Markers.primary.guid = null;
        this.Markers.compare.guid = null;
      }
    }

    shouldShowCsRenda() {
      if (this.user.info.account == null) {
        return true;
      }

      const customVars = this.user.getCustomVars();

      return (
        this.Tab.isResidents() &&
        customVars.cs_renda &&
        this.Cards.isCardSelected('CS_RENDA')
      );
    }

    shouldShowIncomeRange() {
      const customVars = this.user.getCustomVars();

      const isCardIncomeRangeSelected = this.Cards.isCardSelected(
        'INCOME_RANGE',
      );
      const hasCustomVarsThatReplaceIt =
        customVars &&
        Object.entries(customVars).some(([name, value]) =>
          this.hasCsRendaCustomVar(name, value),
        );

      return (
        this.Tab.isResidents() &&
        this.DimensionService.hasDimensionInAudience(
          'INCOME_RANGE',
          'residents',
        ) &&
        !hasCustomVarsThatReplaceIt &&
        isCardIncomeRangeSelected
      );
    }

    hasCsRendaCustomVar(name, value) {
      return (name === 'cs_renda' || name === 'cs_renda_bv') && value === true;
    }
  },
};
