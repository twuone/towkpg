import template from './polis-inbox.html';

export const PolisInboxComponent = {
  template,
  controller: class PolisInboxComponent {
    constructor($log, InboxService, AudienceTypes, SweetAlert, $rootScope) {
      'ngInject';

      this.$log = $log;
      this.InboxService = InboxService;
      this.AudienceTypes = AudienceTypes;
      this.SweetAlert = SweetAlert;
      this.$rootScope = $rootScope;

      this.data = {};
      this.data.uploadingBase = [];

      this.state = {
        open: false,
        currentContext: 'customBases',
        previousContext: 'customBases',
        customBases: {
          currentPage: 'queuePage',
          uploadPage: {
            optionsPaneCollapsed: true,
            file: null,
          },
          filters: {
            audienceType: 'all',
          },
          orderBy: {
            key: 'timestamp',
            reverse: true,
            defaultReverse: true,
          },
        },
        documentExtraction: {
          orderBy: {
            key: 'timestamp',
            reverse: true,
            defaultReverse: true,
          },
        },
      };

      this.availableContexts = ['customBases', 'documentExtraction'];

      this.defaultUploadOptions = {
        validFileTypes: ['csv', 'txt'],
        delimiters: {
          csv: [';', ','],
          txt: '*', // any
        },
      };
    }

    toggleInterface() {
      this.state.open = !this.state.open;

      if (this.state.open) {
        this.InboxService.fetchCustomBasesQueue();
        this.InboxService.fetchuploadingBaseQueue().then(
          _ => {
            this.controlUploadingBaseQueue();
          }
        );
        this.InboxService.fetchExtractionsQueue();
      } else {
        this.goToPage('queuePage', 'resetUploadPage');
        this.resetOrderBy();
        this.resetServiceData();
        this.closeUploadingBaseQueue();
      }
    }

    setContext(context = this.state.currentContext) {
      if (context && this.availableContexts.includes(context)) {
        if (context !== this.state.currentContext) {
          this.state.previousContext = this.state.currentContext;
          this.state.currentContext = context;
        }
      } else {
        this.$log.error('Invalid context');
      }
    }

    setOrder(key = 'timestamp', reverse, context = this.state.currentContext) {
      const state = this.state[context].orderBy;

      state.key = key;

      if (typeof reverse !== 'undefined') {
        state.reverse = reverse;
      } else {
        state.reverse = !state.reverse;
      }
    }

    getOrder(context = this.state.currentContext) {
      return this.state[context].orderBy;
    }

    resetOrderBy() {
      this.availableContexts.forEach((context) => {
        this.state[context].orderBy.reverse = this.state[
          context
        ].orderBy.defaultReverse;
      });
    }

    resetServiceData() {
      this.availableContexts.forEach((context) => {
        delete this.InboxService.data[context];
      });
    }

    setFilter(filter, value, context = this.state.currentContext) {
      this.state[context].filters[filter] = value;
    }

    goToPage(page, callback, context = 'customBases') {
      this.state[context].currentPage = page;
      if (callback && typeof this[callback] === 'function') {
        this[callback]();
      }
    }

    onFileChanged(event, files) {
      this.state.customBases.uploadPage.file = files[0];

      // COMBAK: Validate file and set options
      this.validateFile();
    }

    validateFile() {
      const file = this.state.customBases.uploadPage.file;

      const explodedFileName = file.name.toLowerCase().split('.');

      if (explodedFileName.length > 1) {
        const extension = explodedFileName[explodedFileName.length - 1];
        if (this.defaultUploadOptions.validFileTypes.includes(extension)) {
          this.state.customBases.uploadPage.fileIsValid = true;
          this.setUploadOptions(extension);
        } else {
          this.SweetAlert.error(
            'COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.ERROR.INVALID_FILE_TYPE.TITLE',
            'COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.ERROR.INVALID_FILE_TYPE.BODY',
          );
          this.$log.error(
            `Invalid file extension "${extension}". Only these types are accepted: ${
              this.defaultUploadOptions.validFileTypes
            }`,
          );
        }
      } else {
        this.SweetAlert.error(
          'COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.ERROR.INVALID_FILE_TYPE.TITLE',
          'COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.ERROR.INVALID_FILE_TYPE.BODY',
        );
        this.$log.error("File doesn't have a extension");
      }

      if (!this.state.customBases.uploadPage.fileIsValid) {
        delete this.state.customBases.uploadPage.file;
      }
    }

    isFormValid() {
      const state = this.state.customBases.uploadPage;
      let isValid = true;

      if (state.options.extension == 'txt' && !state.options.delimiter) {
        this.$log.warn('Missing Delimiter for TXT');
        isValid = false;
      }

      return isValid;
    }

    setUploadOptions(extension) {
      this.state.customBases.uploadPage.options = {};
      const options = this.state.customBases.uploadPage.options;
      const delimiter = this.defaultUploadOptions.delimiters[extension];

      if (delimiter === '*') {
        options.delimiter = '';
        this.state.customBases.uploadPage.optionsPaneCollapsed = false;
      } else if (Array.isArray(delimiter)) {
        options.delimiter = delimiter[0];
      } else {
        options.delimiter = delimiter;
      }

      options.extension = extension;
    }

    submitFile() {
      this.InboxService.uploadCustomBase(
        this.state.customBases.uploadPage.file,
        this.state.customBases.uploadPage.options,
      ).then(this.goToPage('queuePage', 'resetUploadPage'));
    }

    onChangeExtension() {
      this.setUploadOptions(
        this.state.customBases.uploadPage.options.extension,
      );
    }

    resetUploadPage() {
      this.state.customBases.uploadPage = {};
      const state = this.state.customBases.uploadPage;
      this.setContext('customBases');
      state.file = undefined;
      state.optionsPaneCollapsed = true;
    }

    downloadFile(id) {
      this.InboxService.fetchExtraction(id, id, 'zip');
    }

    controlUploadingBaseQueue(){
      this.data.uploadingBase = [];

      this.InboxService.data.uploadingBase.forEach(row => {
        if (row.currentStatus === 'PROCESS' || row.currentStatus === 'ERROR'){
          this.data.uploadingBase.push(row);
        }
      });

      this.data.uploadingBase.forEach( row => {
        if (row.currentStatus === 'PROCESS' ){
          row.interval = setInterval(InboxService => {
            InboxService.fetchUploadingStatus(row.id);       
            if (InboxService.data.uploadingStatus.currentStep === 'COMPLETED'){
              row.currentStep = 'COMPLETED';
              this.InboxService.fetchCustomBasesQueue();
              clearInterval(row.interval);
            } else if (InboxService.data.uploadingStatus.currentStep === 'ERROR') {
              row.currentStatus = 'ERROR';
              clearInterval(row.interval);
            }
            this.$rootScope.$digest();
          }, 30000, this.InboxService);
        }
      }); 
      
    }

    closeUploadingBaseQueue(){
      this.data.uploadingBase.forEach(row => {
        if (row.currentStatus === 'PROCESS' ){
          clearInterval(row.interval);
        }
      });      
    
    }

    showError(upload){
      if (upload.status === 'ERROR') {
        this.SweetAlert.error(
          'Ocorreu um erro no seu arquivo',
          'Mensagem: ' + upload.errorMessage,
        );    
      }
    }
  },
};
