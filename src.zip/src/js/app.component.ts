import { CHANGE_PAGE_TITLE } from './app.actions';

export const AppComponent: ng.IComponentOptions = {
  template: require('./app.html'),
  controller: class AppComponent {
    constructor(
      private $scope: ng.IScope,
      private $window: ng.IWindowService,
      private $translate: ng.translate.ITranslateService,
    ) {
      'ngInject';
    }

    $onInit() {
      this.$scope.$on(CHANGE_PAGE_TITLE, async (_, title) => {
        let pageTitle = '';

        if (title) {
          if (!this.$translate.isReady) {
            await this.$translate.onReady();
          }

          pageTitle += this.$translate.instant(title);
          pageTitle += ' - ';
        }

        pageTitle += 'Polis';

        this.$window.document.title = pageTitle;
      });
    }
  },
};
