import { module } from 'angular';
import ngAnimate from 'angular-animate';
import ngCookies from 'angular-cookies';
import 'angular-ivh-treeview';
import nvd3 from 'angular-nvd3';
import ngSanitize from 'angular-sanitize';
import 'angular-translate';
import 'angular-translate-loader-static-files';
import 'angular-translate-storage-cookie';
import 'angular-translate-storage-local';
import uiRouter, {
  TransitionService,
  Transition,
  StateDeclaration,
} from '@uirouter/angularjs';
import 'ng-tags-input';
import ngMap from 'ngmap';
import uiSelect from 'ui-select';
import ngRedux from 'ng-redux';
import ngReduxUiRouter from 'redux-ui-router';
import appConfig from './app.config';
import constants from './app.constants';

import { AuthModule } from './auth/auth.module';
import { ComponentsModule } from './components/components.module';
import { ConstantsModule } from './constants/constants.module';
import { DataViewModule } from './data-view/data-view.module';
import { FiltersModule } from './filters/filters.module';
import { MapViewModule } from './map-view/map-view.module';
import { LayoutModule } from './layout/layout.module';
import { ServicesModule } from './services/services.module';
import { ValuesModule } from './values/value.module';
import Filters from './services/filters.service';
import { CHANGE_PAGE_TITLE } from './app.actions';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';

export const AppModule = module('app', [
  uiRouter,
  ngRedux,
  ngReduxUiRouter,
  nvd3,
  ngCookies,
  ngMap,
  'pascalprecht.translate',
  uiSelect,
  'ivh.treeview',
  'ngTagsInput',
  ngSanitize,
  ngAnimate,
  CoreModule,
  AuthModule,
  ComponentsModule,
  ConstantsModule,
  DataViewModule,
  FiltersModule,
  MapViewModule,
  LayoutModule,
  ServicesModule,
  ValuesModule,
])
  .constant('AppConstants', constants)
  .component('app', AppComponent)
  .config(appConfig)
  .run(
    (
      $rootScope: ng.IRootScopeService,
      $transitions: TransitionService,
      Filters: Filters,
      Markers,
    ) => {
      'ngInject';

      $transitions.onSuccess({}, (transition: Transition) => {
        const toState = transition.to();

        changePageTitleByState(toState);
      });

      function changePageTitleByState(state: StateDeclaration) {
        $rootScope.$broadcast(CHANGE_PAGE_TITLE, state.data.title);
        Markers.reset();
        Filters.deregisterWatchers();
      }
    },
  ).name;
