import { LOAD_AFFINITIES } from '../constants/action-types';

export const loadAffinities = (affinities) => ({
  type: LOAD_AFFINITIES,
  affinities,
});
