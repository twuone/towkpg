export const FilterTypes = {
  Affinity: 'affinity',
  Button: 'button',
  Checkbox: 'checkbox',
  Mosaic: 'mosaic',
  MosaicPF: 'mosaic-pf',
  MosaicPJ: 'mosaic-pj',
  Toogle: 'toggle',
};
