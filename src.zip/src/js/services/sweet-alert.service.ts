import SweetAlert, { SweetAlertType } from 'sweetalert2';

export class SweetAlertService {
  constructor(private $translate: ng.translate.ITranslateService) {
    'ngInject';
  }

  create(title: string, body, type: SweetAlertType = 'info', translate = true) {
    if (translate) {
      title = this.$translate.instant(title);

      if (body) {
        body = this.$translate.instant(body);
      }
    }

    SweetAlert(title, body, type);
  }

  success(title: string, body?, translate?: boolean) {
    this.create(title, body, 'success', translate);
  }

  info(title: string, body?, translate?: boolean) {
    this.create(title, body, 'info', translate);
  }

  error(title, body?, translate?: boolean) {
    this.create(title, body, 'error', translate);
  }

  warning(title: string, body?, translate?: boolean) {
    this.create(title, body, 'warning', translate);
  }

  dialog(title: string, body?, translate = true) {
    if (translate) {
      if (title) {
        title = this.$translate.instant(title);
      }

      if (body) {
        body = this.$translate.instant(body);
      }
    }

    return SweetAlert({
      title,
      text: body,
      type: 'warning',
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
    });
  }

  async confirmation(text: string, translate = true) {
    if (translate && text != undefined) {
      text = this.$translate.instant(text);
    }

    return SweetAlert({
      text,
      type: 'info',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#A9A9A9',
      confirmButtonText: 'Confirmar',
      cancelButtonText: 'Cancelar'
    });
  }
}
