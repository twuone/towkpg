export default class HeatMap {
	constructor($http, AppConstants, JWT, ParamSerializer, MapValues, Filters, User) {
		'ngInject';

		// init private variables
		this._$http = $http;
		this._AppConstants = AppConstants;
		this._JWT = JWT;
		this._ParamSerializer = ParamSerializer;
		this._MapValues = MapValues;
		this._Filters = Filters;
		this.user = User;

		// init public variables
		this.params = {};
		this.guid = '';
	}

	getHeatMap(type, marker = {}, source = '', entity = 'data') {
		// make params based on this method parameters
		if(marker.guid) {
			this.guid = marker.guid + '/';

			this.params = this._Filters.getParams();
		} else {
			let params = {};
			this.guid = '';

			params.points = [{
	            latitude: this._MapValues.center.lat,
	            longitude: this._MapValues.center.lng
	        }];

	        params.filters = [{
				name: "radius",
				value: ["5000"]
			}];

			params.start = "2017-12-01";
			params.end = "2018-01-31";

			this.params = params;
		}

		return this._$http({	
			url: `${this._AppConstants.api()}/${entity}/${this.guid}${type}/heatmap/${source}`, // theres's no / between ${this.guid} and ${type} because it's is set if needed in the begining of the method
			method: 'GET',
			headers: {
				Authorization: 'Bearer ' + this._JWT.get()
			},
			params: this.params,
			paramSerializer: this._ParamSerializer.base64
		}).then(
			(res) => {
				return res.data;
			}
		);
	}
}
