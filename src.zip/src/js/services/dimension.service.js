import { flatMap } from '../core/util/arrays';
import { createObjectKeys as objKeys, createObjectKeysSame as objKeysSame } from '../core/util/arrays';

export const FLAG_TYPES = ['cnpj', 'unlessPresent'];

export default class DimensionService {
  availableGroups = [];

  constructor(AppConstants, $http, $log, JWT) {
    'ngInject';

    this.AppConstants = AppConstants;
    this.$http = $http;
    this.$log = $log;
    this.JWT = JWT;
  }

  fetch() {
    const httpOptions = {
      url: `${this.AppConstants.api('v2')}/dimensions/groups?full=true`,
      method: 'GET',
      headers: {
        Authorization: `Bearer ${this.JWT.get()}`,
      },
    };

    return this.$http(httpOptions).then(
      (response) => response.data,
      (err) => {
        return {
          error: err.status,
        };
      },
    );
  }

  setAvailableGroups(dimensionGroups, userConfig) {
    this.availableGroups = this.getGroupWithOnlyAvailableDimensions(dimensionGroups,userConfig);
  }

  getValueChart(data, nameChart){
    var dt = {};
    data[0].dimensions.residents.forEach((obj) => {
      if(obj.name === nameChart){
        dt = objKeys(obj.values);
      }
    });
    return dt;
  }

  getValueChartPJ(data, nameChart){
    var dt = {};
    data[0].dimensions.companies.forEach((obj) => {
      if(obj.name === nameChart){
        dt = objKeys(obj.values);
      }
    });
    return dt;
  }

  getValueChartSame(data, nameChart){
    var dt = {};
    data[0].dimensions.residents.forEach((obj) => {
      if(obj.name === nameChart){
        dt = objKeysSame(obj.values);
      }
    });
    return dt;
  }

  getValueChartSamePJ(data, nameChart){
    var dt = {};
    data[0].dimensions.companies.forEach((obj) => {
      if(obj.name === nameChart){
        dt = objKeysSame(obj.values);
      }
    });
    return dt;
  }

  getGroupWithOnlyAvailableDimensions(dimensionGroups, userConfig) {
    return [...dimensionGroups].map((dimensionGroup) => {
      Object.entries(dimensionGroup.dimensions)
        .forEach(([audience, dimensions]) => {
          dimensionGroup.dimensions[audience] = dimensions.filter((dimension) => this.isDimensionAllowed(dimension, userConfig));
        });
      return dimensionGroup;
    });
  }

  hasDimensionInAudience(dimensionName, audience) {
    return this.getGroupsByAudience(audience)
      .map((group) => Object.values(group.dimensions))
      .reduce((groups, audience) => flatMap(groups, audience), [])
      .some((dimension) => dimension.name.toUpperCase() === dimensionName);
  }

  groupHasAudience(group, audience) {
    return group[audience] !== undefined;
  }

  getGroups() {
    return [...this.availableGroups];
  }

  getDimensionsFromGroupAsArray(group) {
    return Object.values(group.dimension)
      .reduce((dimensions, audience) => flatMap(dimensions, audience), []);
  }

  getDimensionsByAudience(audience) {
    return this.getGroupsByAudience(audience)
      .map((group) => this.getDimensionsFromGroupAsArray(group));
  }

  getGroupsByAudience(audience) {
    return this.availableGroups
      .filter((group) =>
        this.getAudiencesByGroupId(group.id)
          .some((group) => this.groupHasAudience(group, audience)));
  }

  getAudiencesByGroupId(groupId) {
    return this.availableGroups
      .filter((group) => group.id === groupId)
      .map((group) => group.dimensions);
  }

  filterAvailable(dimensions, userConfig) {
    return dimensions.filter((dimension) =>
      this.isDimensionAllowed(dimension, userConfig),
    );
  }

  /**
   * Check for enabled flags on User's model:
   * - **"cnpj"** are `boolean` feature flags enabled on the account level
   * - **"unlessPresent"** are conditionaly based on another dimension's presence/absence
   * @param {Object} dimension
   * @param {Object} userConfig
   */
  isDimensionAllowed(dimension, userConfig) {
    let isAllowed = true;

    FLAG_TYPES.filter((flagType) =>
      this.hasFlagsDefined(dimension.config, flagType),
    ).some((flagType) =>
      dimension.config.flags[flagType]
        .filter((flag) => this.hasCustomVarsFlag(userConfig, flag))
        .some((flag) => {
          const flagValue = userConfig.customVars[flag];

          isAllowed = this.getFlagValue(flagType, flagValue);

          return true;
        }),
    );

    return isAllowed;
  }

  getFlagValue(flagType, flagValue) {
    return flagType === 'unlessPresent' ? !flagValue : flagValue;
  }

  hasCustomVarsFlag(config, flag) {
    return config.customVars && config.customVars[flag] !== undefined;
  }

  hasFlagsDefined(dimensionConfig, flagType) {
    return (
      dimensionConfig.flags && dimensionConfig.flags[flagType] !== undefined
    );
  }
}
