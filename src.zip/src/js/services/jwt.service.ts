export default class JWT {
  constructor(
    private AppConstants,
    private $window: ng.IWindowService,
  ) {
    'ngInject';
  }

  save(token) {
    this.$window.localStorage[this.AppConstants.jwtKey] = token;
  }

  get(): string {
    return this.$window.localStorage[this.AppConstants.jwtKey];
  }

  destroy() {
    this.$window.localStorage.removeItem(this.AppConstants.jwtKey);
  }
}
