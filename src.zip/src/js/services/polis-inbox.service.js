import { LOGOUT_USER } from '../app.actions';

export default class InboxService {
  /*@ngInject*/
  constructor(
    AppConstants,
    JWT,
    $log,
    $http,
    $rootScope,
    ParamSerializer,
    SweetAlert,
  ) {
    this.$log = $log;
    this._AppConstants = AppConstants;
    this._JWT = JWT;
    this._ParamSerializer = ParamSerializer;
    this.$http = $http;
    this.SweetAlert = SweetAlert;

    this.data = {};

    this.state = {
      customBases: {},
      uploadingBase: {},
      uploadingStatus: {},
      documentExtraction: {},
    };

    $rootScope.$on(LOGOUT_USER, () => {
      this.data = {};
    });
  }

  fetchCustomBasesQueue() {
    this.state.customBases.isBusy = true;
    this.state.customBases.hasError = false;

    return this.$http({
      url: `${this._AppConstants.api('v2')}/database/customer-database`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then(
      (res) => {
        this.state.customBases.isBusy = false;
        return (this.data.customBases = res.data);
      },
      (err) => {
        this.state.customBases.isBusy = false;
        this.state.customBases.hasError = true;
        return false;
      },
    );
  }

  fetchuploadingBaseQueue() {
    this.state.uploadingBase.isBusy = true;
    this.state.uploadingBase.hasError = false;

    return this.$http({

      // url: `${this._AppConstants.api('v2')}/base/uploads/`,
      url: `${this._AppConstants.api('v2')}/base/uploads/findAllByCompany/`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then(
      (res) => {
        this.state.uploadingBase.isBusy = false;
        return (this.data.uploadingBase = res.data);
      },
      (err) => {
        this.state.uploadingBase.isBusy = false;
        this.state.uploadingBase.hasError = true;
        return false;
      },
    );
  }

  fetchUploadingStatus(id) {
    this.state.uploadingStatus.isBusy = true;
    this.state.uploadingStatus.hasError = false;
    
    return this.$http({
      url:  `${this._AppConstants.api('v2')}/base/uploads/${id}/`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then(
      (res) => {
        this.state.uploadingStatus.isBusy = false;
        console.log(this.data.uploadingStatus);
        return (this.data.uploadingStatus = res.data);
        
      },
      (err) => {
        this.state.uploadingStatus.isBusy = false;
        this.state.uploadingStatus.hasError = true;
        return false;
      },
    );
  }

  uploadCustomBase(file, options) {
    const requestObject = options;

    const fd = new FormData();

    Object.keys(requestObject).forEach((key) => {
      fd.append(key, requestObject[key]);
    });

    fd.append('file', file);

    return this.$http({
      url: `${this._AppConstants.api('v2')}/transfer/upload/custom-database`,
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
        'Content-Type': undefined,
      },
      data: fd,
    }).then(
      (res) => {
        const data = res.data;
        this.SweetAlert.success(
          'COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.SUCCESS.TITLE',
          'COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.SUCCESS.BODY',
        );
        return data;
      },
      (error) => {
        let errorType = 'UNKNOWN_ERROR';

        if (error.data && error.data.message) {
          if (error.data.message.indexOf('File format not valid') > -1) {
            errorType = 'INVALID_FILE';
          } else if (error.data.message.indexOf('Required') > -1) {
            errorType = 'MISSING_PARAMETERS';
          }
        } else {
          errorType = 'SERVER_ERROR';
        }

        this.SweetAlert.error(
          `COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.ERROR.${errorType}.TITLE`,
          `COMPONENTS.POLIS_INBOX.CUSTOM_BASES.UPLOAD.MESSAGES.ERROR.${errorType}.BODY`,
        );
      },
    );
  }

  fetchExtractionsQueue() {
    this.state.documentExtraction.isBusy = true;
    this.state.documentExtraction.hasError = false;

    return this.$http({
      url: `${this._AppConstants.api('v2')}/transfer/download/document`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then(
      (res) => {
        this.state.documentExtraction.isBusy = false;
        return (this.data.documentExtraction = res.data);
      },
      (err) => {
        this.state.documentExtraction.isBusy = false;
        this.state.documentExtraction.hasError = true;
        return false;
      },
    );
  }

  fetchExtraction(id, fileName = 'extraction', fileType) {
    const FILETYPES = {
      csv: 'text/plain;charset=utf-8',
      xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      zip: 'application/zip',
    };

    if (Object.keys(FILETYPES).includes(fileType)) {
      return this.$http({
        url: `${this._AppConstants.api('v2')}/transfer/download/document/${id}`,
        method: 'GET',
        headers: {
          Authorization: 'Bearer ' + this._JWT.get(),
        },
        responseType: 'arraybuffer',
      }).then((res) => {
        const fileData = new Blob([res.data], {
          type: FILETYPES[fileType],
        });
        this._downloadFile()(fileData, fileName, fileType);
      });
    } else {
      this.$log.error(
        'Invalid parameter:',
        `FileType "${fileType}" not defined`,
      );
    }
  }

  _downloadFile() {
    const a = document.createElement('a');
    document.body.appendChild(a);
    a.style = 'display: none';
    return function(fileData, fileName, fileType) {
      const url = window.URL.createObjectURL(fileData);
      a.href = url;
      a.download = `${fileName}.${fileType}`;
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    };
  }
}
