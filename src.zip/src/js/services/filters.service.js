export default class Filters {
  constructor(
    $filter,
    $log,
    $rootScope,
    FILTERS,
    $translate,
    $injector,
    Cards,
    Tab,
    AudienceTypes,
    MOSAIC,
    MOSAIC_PJ,
    $state,
    FilterService,
  ) {
    'ngInject';

    this.$filter = $filter;
    this.$log = $log;
    this.$rootScope = $rootScope;
    this.FILTERS = FILTERS;
    this.$translate = $translate;
    this.$injector = $injector;
    this.Cards = Cards;
    this.Tab = Tab;
    this.AudienceTypes = AudienceTypes;
    this.MOSAIC = MOSAIC;
    this.MOSAIC_PJ = MOSAIC_PJ;
    this.$state = $state;
    this.FilterService = FilterService;

    this.$onInit();
  }

  $onInit() {
    this.custom = {};

    // filters defaults
    this.filters = {
      radius: 495, //FIXME
    };
    this.dateRange = {
      start: new Date(2017, 11, 1), // Minimum date
      end: new Date(2018, 0, 31), // Current date
    };

    this.onChangeCallback = {};

    this.$rootScope.filtersHasChangeState = false;

    this.AudienceTypes.available.forEach((audience) => {
      this[audience] = {
        filters: {},
      };
    });
  }

  getMosaicFilter(type) {
    const filter = {};

    if (type == 'companies') {
      // Mosaic defaults
      for (const key in this.MOSAIC_PJ) {
        filter[key] = true;
      }
    } else {
      // Mosaic defaults
      for (const key in this.MOSAIC) {
        filter[key] = true;
      }
    }

    return filter;
  }

  getCreditRiskFilter(type) {
    let filter = {};

    if (type === 'companies') {
      // Companies credit Risk defaults
      filter = {
        a: true,
        b: true,
        c: true,
        d: true,
        e: true,
        f: true,
        g: true,
        h: true,
        unknown: true,
      };
    } else {
      // Resident credit Risk defaults
      filter = {
        very_low: true,
        low: true,
        medium: true,
        high: true,
        very_high: true,
      };
    }

    return filter;
  }

  _getAdditionalFilters() {
    const additionalFilter = {};
    Object.keys(this.FilterService.availableGroups)
      .filter((groupId) => this.groupNotBelongsSerasa(groupId))
      .forEach((group) => {
        const model = this.FilterService.availableGroups[group].dimensions[
          this.AudienceTypes.applied
        ];

        if (model) {
          Object.keys(model).forEach((dimension) => {
            additionalFilter[model[dimension].name] = Object.assign(
              {},
              model[dimension],
            );

            ['name', 'values', 'config'].forEach((key) => {
              delete additionalFilter[model[dimension].name][key];
            });

            Object.keys(model[dimension].values).forEach((value) => {
              additionalFilter[model[dimension].name][value] =
                model[dimension].values[value];
            });
          });
        }
      });

    return additionalFilter;
  }

  groupNotBelongsSerasa(groupId) {
    return (
      this.FilterService.availableGroups[groupId].name.indexOf('serasa') === -1
    );
  }

  getFilters(removeRadius, exclude = true) {
    const formatedFilters = [];
    const additionalFilter = this._getAdditionalFilters();
    const serasaFilters = this[this.AudienceTypes.applied].filters;

    // Merge current selection with global filters
    const mergedFilters = {
      ...serasaFilters,
      ...additionalFilter,
      ...this.filters,
      ...this.custom,
    };

    if (this.$state.current.name == 'app.data-view' || removeRadius) {
      delete mergedFilters.radius;
    }

    Object.keys(mergedFilters).forEach((key) => {
      if (key !== 'start' && key !== 'end' && 'unknownInfo') {
        const formatedFilter = this._formatFilter(
          key,
          mergedFilters[key],
          exclude,
        );
        if (formatedFilter) {
          formatedFilters.push(formatedFilter);
        }
      } else if (mergedFilters[key]) {
        formatedFilters[key] = mergedFilters[key];
      }
    });

    return formatedFilters;
  }

  isFiltersValid() {
    return (
      (this._isValid(this.filters.mosaic) &&
        this._isValid(this.residents.filters.social_class)) ||
      (this.Tab.isVisitors() &&
        this.filters.unknownInfo &&
        this._isDateRangeValid(this.dateRange))
    );
  }

  _isValid(value) {
    for (const key in value) {
      if (value[key]) {
        return true;
      }
    }
    return false;
  }

  _isDateRangeValid(dateRange) {
    // hours * minutes * seconds * miliseconds
    const day = 24 * 60 * 60 * 1000;
    const timeDiference = dateRange.end - dateRange.start;
    if (timeDiference / day < 63) {
      return true;
    }

    return false;
  }

  getFiltersAsString() {
    const filters = this.getValidFilters();
    let stringFilters = '';

    for (const key in filters) {
      let CONST;
      let title;

      if (this.FILTERS[key]) {
        CONST = this.$injector.has(this.FILTERS[key].const)
          ? this.$injector.get(this.FILTERS[key].const)
          : {};
        title = this.FILTERS[key].label
          ? this.FILTERS[key].label + '.TITLE'
          : key;
      } else {
        CONST = {};
        title = key;
      }

      stringFilters += this.$translate.instant(title) + ': ';
      if (filters[key]) {
        if (filters[key] instanceof Array) {
          stringFilters += filters[key]
            .map((filterKey) => {
              if (
                this.FILTERS[key] &&
                this.FILTERS[key].label &&
                CONST[filterKey]
              ) {
                return this.$translate.instant(
                  this.FILTERS[key].label + '.VALUES.' + CONST[filterKey],
                );
              }

              return filterKey;
            })
            .join(', ');
        } else {
          stringFilters += filters[key];
        }
      }
      stringFilters += '\n';
    }

    return stringFilters;
  }

  getValidFilters() {
    const validFilters = {};

    for (const key in this.filters) {
      if (
        this.filters[key] instanceof Array ||
        typeof this.filters[key] === 'string' ||
        typeof this.filters[key] === 'number'
      ) {
        validFilters[key] = this.filters[key];
      } else if (this.filters[key] instanceof Object) {
        validFilters[key] = [];
        Object.keys(this.filters[key]).forEach((filterKey) => {
          if (this.filters[key][filterKey]) {
            validFilters[key].push(filterKey);
          }
        });
      }
    }
    return validFilters;
  }

  getParams() {
    const params = {
      filters: this.getFilters(),
    };

    if (this.AudienceTypes.applied === 'visitors') {
      params.start = this.$filter('date')(this.dateRange.start, 'yyyy-MM-dd');
      params.end = this.$filter('date')(this.dateRange.end, 'yyyy-MM-dd');
    }

    return params;
  }

  change(filterWatch) {
    // flag that indicates the filters were changed
    // this._$rootScope.filtersHasChangeState = !this._$rootScope.filtersHasChangeState;

    if (!filterWatch) {
      this.$rootScope.primary = !this.$rootScope.primary;
      this.$rootScope.compare = !this.$rootScope.compare;
    } else {
      this.$rootScope[filterWatch] = !this.$rootScope[filterWatch];
    }

    // Deregister Existent Watchers
    if (this.AudienceTypes.applied != this.AudienceTypes.previous) {
      this.deregisterWatchers();
    }
  }

  deregisterWatchers() {
    while (this.Cards.watcherInstances.length) {
      this.Cards.watcherInstances.pop()(); // Tetinha function
    }
  }

  onChange(callback = {}) {
    this.onChangeCallback = callback;
  }

  _formatFilter(name, values, exclude) {
    const truthy = [];
    const falsey = [];

    if (!values) {
      return;
    }

    if (typeof values === 'number') {
      return {
        name,
        values: [values.toString()],
      };
    }

    if (typeof values === 'string') {
      return {
        name,
        values: [values == 'true'],
      };
    }

    if (Array.isArray(values) && name === 'cnae') {
      const cnaeValues = [];
      values.map((value) => {
        cnaeValues.push(value.cnae);
      });

      return {
        name,
        values: cnaeValues,
      };
    }

    if (values.length && typeof values[0] === 'number') {
      return {
        name,
        values:
          name === 'duration'
            ? values.map((value) => (value * 60).toString())
            : values,
      };
    }

    if (values.length && typeof values[0] === 'string') {
      return {
        name,
        values,
      };
    }

    for (const key in values) {
      if (this.AudienceTypes.applied === 'visitors') {
        if (values[key]) {
          if (
            name == 'mosaic' ||
            name == 'credit_risk' ||
            name == 'social_class'
          ) {
            truthy.push(key.toUpperCase());
          } else {
            truthy.push(key);
          }
        } else {
          if (
            name == 'mosaic' ||
            name == 'credit_risk' ||
            name == 'social_class'
          ) {
            falsey.push(key.toUpperCase());
          } else {
            falsey.push(key);
          }
        }
      } else {
        if (values[key]) {
          truthy.push(key);
        } else {
          falsey.push(key);
        }
      }
    }

    if (exclude) {
      // if all selected or any selected do not return the object
      if (!truthy.length || !falsey.length) {
        if (
          !this.filters.unknownInfo &&
          (name === 'mosaic' || name === 'social_class')
        ) {
          return {
            name: name + '_exclude',
            values: ['unknown'],
          };
        }

        return;
      }

      if (truthy.length > falsey.length) {

        return {
          name: name + '_exclude',
          values: falsey,
        };
      }
    }

    return {
      name,
      values: truthy,
    };
  }
}
