export default class ExportService {
  constructor(
    $http,
    $log,
    $q,
    $state,
    $translate,
    AppConstants,
    AudienceTypes,
    Bases,
    Filters,
    JWT,
    Layers,
    Markers,
    ParamSerializer,
    Tab,
  ) {
    'ngInject';

    // init private variables
    this.$log = $log;
    this._$http = $http;
    this._AppConstants = AppConstants;
    this._Markers = Markers;
    this._Filters = Filters;
    this._JWT = JWT;
    this._$translate = $translate;
    this._$q = $q;
    this._Tab = Tab;
    this._$state = $state;
    this._Layers = Layers;
    this._ParamSerializer = ParamSerializer;
    this._AudienceTypes = AudienceTypes;
    this._Bases = Bases;

    // init public variables
    this.group = '';
    this.count = 0;
    this.personGroup = [];
    this.fields = [];
    this.radius = '';
  }

  getExport(type = 'csv', primary = 'serasa', secondary) {
    let mime = '';

    if (type == 'csv') {
      mime = 'text/plain;charset=utf-8';
    } else if (type == 'xlsx') {
      mime =
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    } else {
      return;
      this.$log.error('Invalid file type');
    }

    let url = !secondary
      ? `/database/${
          primary === 'serasa' ? 'serasa/report' : 'customer/report/' + primary
        }`
      : `/database/comparison/report/${primary}/${secondary}`;

    let params = this._Bases.getParams(primary, secondary);

    if (secondary) {
      this.$log.warn(
        'TODO',
        'API for export and front-end should be the same.',
      );
      params.cards.push('state_city');
    }

    return this._$http({
      url: `${this._AppConstants.api('v2')}${url}/${type}`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
      responseType: 'arraybuffer',
      params: params,
      paramSerializer: this._ParamSerializer.base64,
    }).then((res) => {
      const data = new Blob([res.data], {
        type: mime,
      });
      this.downloadFile()(data, `export.${type}`);
    });
  }

  downloadFile() {
    const a = document.createElement('a');
    document.body.appendChild(a);
    a.style = 'display: none';
    return function(blob, fileName) {
      const url = window.URL.createObjectURL(blob);
      a.href = url;
      a.download = fileName;
      a.click();
      window.URL.revokeObjectURL(url);
    };
  }

  getComparison(type) {
    this.getExport(type, this._Bases.applied[0].id, this._Bases.applied[1].id);
  }
}
