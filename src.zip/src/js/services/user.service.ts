import { LOGOUT_USER } from '../app.actions';
import { Account, UserInfo, AccountConfig } from '../core/models';
import { StateService } from '@uirouter/core';
import BasesService from './bases.service';
import Filters from './filters.service';
import JWT from './jwt.service';
import LayersService from './layers.service';
import ModalService from './modal.service';
import PanelStateService from './panel-state.service';
import { SweetAlertService } from './sweet-alert.service';

export class UserService {
  private current = null;
  public info = {} as UserInfo;

  constructor(
    private $http: ng.IHttpService,
    private $log: ng.ILogService,
    private $q: ng.IQService,
    private $rootScope: ng.IRootScopeService,
    private $state: StateService,
    private $translate: ng.translate.ITranslateService,
    private AppConstants,
    private AudienceTypes,
    private Bases: BasesService,
    private Filters: Filters,
    private JWT: JWT,
    private Layers: LayersService,
    private Markers,
    private Modal: ModalService,
    private PanelStateService: PanelStateService,
    private SweetAlert: SweetAlertService,
  ) {
    'ngInject';
  }

  attemptAuth(type: string, credentials) {
    const route = type === 'login' ? '/users/accounts/login/' : '';

    const httpOptions = {
      url: this.AppConstants.api('v2') + route,
      method: 'POST',
      data: {
        username: credentials.email,
        password: credentials.password,
        context: 'account',
      },
    };

    return this.$http(httpOptions)
      .then((response) => response.data)
      .then((account: Account) => {
        this.JWT.save(account.token);
        this.current = account;

        this.getUserData();

        return account;
      });
  }

  preRegister(payload) {
    return this.$http({
      url: this.AppConstants.api() + '/account/register',
      method: 'POST',
      data: payload,
    });
  }

  smsCode(payload) {
    return this.$http({
      url: this.AppConstants.api() + '/account/activate',
      method: 'PUT',
      data: payload,
    }).then((res) => {
      return res;
    });
  }

  forgot(payload) {
    return this.$http({
      url: this.AppConstants.api('v2') + '/users/accounts/recovery',
      method: 'POST',
      data: payload,
    }).then((res) => {
      return res;
    });
  }

  logout() {
    const httpOptions = {
      url: this.AppConstants.api() + '/logout/',
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    };

    this.$http(httpOptions);

    this.$rootScope.$broadcast(LOGOUT_USER);

    this.cleanEnv();
  }

  cleanEnv() {
    this.current = null;
    this.info = {} as UserInfo;
    this.JWT.destroy();

    this.Markers.reset();

    this.PanelStateService.setOpenState(false);

    this.Layers.reset();

    this.Bases.reset();

    this.$state.go('app.login');
  }

  verifyAuth() {
    const deferred = this.$q.defer();

    // Check for JWT token first
    if (!this.JWT.get()) {
      deferred.resolve(false);
      return deferred.promise;
    }

    // refresh user's info
    this.getUserData();

    // If there's a JWT & user is already set
    if (this.current) {
      deferred.resolve(true);

      // If current user isn't set, get it from the server.
      // If server doesn't 401, set current user & resolve promise.
    } else {
      this.$http({
        url: this.AppConstants.api('v2') + '/users/accounts/verify',
        method: 'GET',
        headers: {
          Authorization: 'Bearer ' + this.JWT.get(),
        },
      }).then(
        () => {
          this.current = {
            value: 'ok',
          };
          deferred.resolve(true);
        },

        // If an error happens, that means the user's token was invalid.
        () => {
          this.JWT.destroy();
          deferred.resolve(false);
        },

        // Reject automatically handled by auth interceptor
        // Will boot them to homepage
      );
    }

    return deferred.promise;
  }

  ensureAuthIs(shouldEnsure) {
    const deferred = this.$q.defer();

    this.verifyAuth().then((authIsValid) => {
      if (authIsValid !== shouldEnsure) {
        this.$state.go(!shouldEnsure ? 'app.map-view' : 'app.login');
        deferred.resolve(false);
      } else {
        deferred.resolve(true);
      }
    });

    return deferred.promise;
  }

  changePassword(oldPass, newPass) {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/users/accounts/password`,
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + this.JWT.get(),
      },
      data: {
        currentPassword: oldPass,
        password: newPass,
      },
    }).then(
      () => {
        this.SweetAlert.success('COMPONENTS.PASSWORD_MODAL.MESSAGES.SUCCESS');
        this.Modal.setCurrentModal(null);
        $('#modalPasswordChange').modal('hide');
      },
      (err) => {
        if (
          err.status == 405 &&
          err.data &&
          err.data.message &&
          err.data.message == 'LIMIT_EXCEEDED'
        ) {
          this.SweetAlert.error(
            'COMPONENTS.PASSWORD_MODAL.MESSAGES.LIMIT_EXCEEDED',
          );
        } else if (
          err.status == 405 &&
          err.data &&
          err.data.message &&
          err.data.message == 'PASSWORD_REUSED'
        ) {
          this.SweetAlert.error(
            'COMPONENTS.PASSWORD_MODAL.MESSAGES.PASSWORD_REUSED.TITLE',
            'COMPONENTS.PASSWORD_MODAL.MESSAGES.PASSWORD_REUSED.BODY',
          );
        } else {
          this.SweetAlert.error('COMPONENTS.PASSWORD_MODAL.MESSAGES.ERROR');
        }
        this.Modal.setCurrentModal(null);
        $('#modalPasswordChange').modal('hide');
      },
    );
  }

  getUserData() {
    const httpOptions = {
      url: `${this.AppConstants.api('v2')}/users/accounts/my/`,
      method: 'GET',
      headers: {
        Authorization: `Bearer ${this.JWT.get()}`,
      },
    };

    return this.$http(httpOptions)
      .then((response) => response.data)
      .then(
        (userInfo: UserInfo) => {
          // this validation considers that if radius is !undefined then it constains min and max values
          if (
            userInfo.user &&
            userInfo.user.config &&
            userInfo.user.config.radius
          ) {
            this.Filters.filters.radius =
              (userInfo.user.config.radius.max -
                userInfo.user.config.radius.min) /
                2 || 500;
          }

          const visitorsIndex = this.AudienceTypes.available.indexOf(
            'visitors',
          );
          if (
            !userInfo.account.config.visitorsEnabled &&
            visitorsIndex !== -1
          ) {
            this.AudienceTypes.available.splice(visitorsIndex, 1);
          }

          const daysForUpdate = userInfo.user.daysForUpdate;

          if (daysForUpdate > 0 && daysForUpdate <= 10) {
            const msg1 = this.$translate.instant(
              'AUTH.LOGIN.MESSAGES.RENEW_PASSWORD_1',
            );
            const msg2 = this.$translate.instant(
              'AUTH.LOGIN.MESSAGES.RENEW_PASSWORD_2',
            );
            this.SweetAlert.error(msg1 + ' ' + daysForUpdate + ' ' + msg2);
          } else if (daysForUpdate < 0) {
            this.Modal.setCurrentModal('modalPasswordChange');
            const timerToCloseModal = setInterval(() => {
              if (document.getElementById('modalPasswordChange')) {
                this.Modal.setCurrentModal('modalPasswordChange');
                $('#modalPasswordChange').modal('show');
                clearInterval(timerToCloseModal);
              }
            }, 1000);
          }

          this.info = userInfo;
          this.Layers.accountName = this.info.account.name;
        },
        (err) => {
          this.$log.error('UserService Error', err);
          this.info = {} as UserInfo;
        },
      );
  }
  getConfig(): AccountConfig {
    return this.info?.account?.config || {} as AccountConfig;
  }

  getCustomVars() {
    return this.getConfig()?.customVars || {};
  }

  changeConfig(user: { info: UserInfo }) {
    const httpOptions = {
      url: `${this.AppConstants.api()}/account/my/`,
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.JWT.get()}`,
      },
      data: {
        user: user.info.user,
      },
    };

    return this.$http(httpOptions).then(
      () => {
        this.SweetAlert.success(
          'COMPONENTS.USER_SETTINGS_MODAL.MESSAGES.SUCCESS',
        );
      },
      () => {
        this.SweetAlert.error('COMPONENTS.USER_SETTINGS_MODAL.MESSAGES.ERROR');
      },
    );
  }
}
