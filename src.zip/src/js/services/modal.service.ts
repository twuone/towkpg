export default class ModalService {
  details = {};
  polygon = {};
  currentModal = undefined;

  setDetails(details) {
    this.details = details;
  }

  setPolygon(polygon) {
    this.polygon = polygon;
  }

  setCurrentModal(modalID: string) {
    this.currentModal = modalID;
  }

  closeAll(reset: boolean) {
    $('.modal').modal('hide');
    if (reset) {
      this.setCurrentModal(undefined);
    }
  }
}
