export class AudienceTypesService {
  public cards: AudienceType = 'residents';
  public selected: AudienceType = 'residents';
  public applied: AudienceType = 'residents';
  public previous: AudienceType = 'residents';
  public available: AudienceType[] = ['residents', 'companies', 'visitors'];
}

export type AudienceType = 'residents' | 'companies' | 'visitors';
