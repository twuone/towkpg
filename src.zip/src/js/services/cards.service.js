import {
  RESET_NOT_PANEL_COMPLETELY,
  SHOW_COMPARISON_PANEL,
} from '../app.actions';

export default class CardsService {
  constructor(
    $http,
    $rootScope,
    $log,
    $state,
    $translate,
    AppConstants,
    AudienceTypes,
    DimensionService,
    JWT,
    Markers,
    ParamSerializer,
    Tab,
  ) {
    'ngInject';

    this.$translate = $translate;
    this.$log = $log;

    this.guid = null;
    this.params = {};

    this.$http = $http;
    this.$rootScope = $rootScope;
    this.AppConstants = AppConstants;
    this.JWT = JWT;
    this.ParamSerializer = ParamSerializer;
    this.Tab = Tab;
    this.AudienceTypes = AudienceTypes;

    this.watcherInstances = [];
    this.layerMode = false;
    this.customLayerTheme = false;
    this.baseId = null;
    this.baseIdCompare = null;
    this.dataCardComparison = {};
    this.lockCalculation = false;
    this.cardItemsLength = null;
    this.showComparison = false;

    this.Markers = Markers;
    this.$state = $state;

    this.counters = [];
    this.abortCalculation = false;
    this.available = {};
    this.totalLayer = 0;
    this.cardsSelected = [];

    this.$rootScope.$on(RESET_NOT_PANEL_COMPLETELY, () =>
      this.resetNotPanelCompletely(),
    );

    this.dimensionsFromServer = null;
    this.serasaCards = null;
    this.cardHash = null;

    this.DimensionService = DimensionService;
  }

  getCards(type) {
    return this.$http({
      url: `assets/mocks/${type}-cards.json`,
      method: 'GET',
      headers: {
        Authorization: `Bearer ${this.JWT.get()}`,
      },
      params: this.params,
      paramSerializer: this.ParamSerializer.base64,
    }).then(
      (res) => res.data,
      (reason) => {
        return {
          error: reason.status,
        };
      },
    );
  }

  /**
   * Obtém a lista de filtros do servidor
   * @param {string} dimensionId
   */
  getCardsNew(dimensionId) {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/dimensions/groups?full=true`,
      method: 'GET',
      headers: {
        Authorization: `Bearer ${this.JWT.get()}`,
      },
      params: this.params,
      paramSerializer: this.ParamSerializer.base64,
    }).then((response) => response.data).then(
      (dimensionsFromServer) => {
        const filters = Object.values(dimensionsFromServer)
          .filter((dimensionGroup) => dimensionGroup.dimensions[dimensionId])
          .reduce((filters, dimensionGroup) =>
            filters.concat(dimensionGroup.dimensions[dimensionId]), []);

        return filters;
      },
      (reason) => ({
        error: reason.status,
      }),
    );
  }

  checkExclusionLimit() {
    const customBase = this.baseIdCompare == 'serasa' ? 'primary' : 'compare';
    if (!this.dataCardComparison[customBase]) {
      return false;
    }
  }

  getCardDetails(
    uri,
    type,
    params,
    marker,
    entity = 'data',
    filters,
    location,
    filterWatch,
    constName = '',
  ) {
    let url;
    let baseContext =
      filterWatch === 'primary' ? this.baseId : this.baseIdCompare;
    if (filterWatch != 'primary' && !this.baseIdCompare) {
      baseContext = this.baseId;
    }

    const inclination = uri
      .replace('/', '')
      .replace('inclination/', '')
      .replace(/-/g, '_');

    if (!this.layerMode) {
      if (uri.includes('//')) {
        url = uri;
      } else {
        if (baseContext && baseContext != 'serasa') {
          url = `${this.AppConstants.api('v2')}/data/${baseContext}/${
            marker.guid
          }/${type}/${inclination}`;
        } else {
          // Standard Base
          url = `${this.AppConstants.api(
            entity === 'device' ? 'v1' : 'v2',
          )}/${entity}/${marker.guid}/${type}${uri}`;
        }
      }
    } else {
      if (uri.includes('//')) {
        url = uri;
      } else {
        if (baseContext && baseContext != 'serasa') {
          // Custom Bases
          if (this.customLayerTheme) {
            url = `${this.AppConstants.api(
              'v2',
            )}/database/customer/report/${baseContext}`;
          } else {
            url = `${this.AppConstants.api(
              'v2',
            )}/database/ibge/report/${baseContext}`;
          }
        } else {
          // Standard Base
          url = `${this.AppConstants.api('v2')}/database/ibge/report`;
        }
      }
      if (this.customLayerTheme) {
        url = url.replace('/ibge/', '/serasa/');
      }
      params = {
        filters,
        cards: [inclination],
        category: type,
        location,
      };
    }

    let httpOptions = {};

    if (this.customLayerTheme && this.layerMode) {
      httpOptions = {
        url,
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.JWT.get()}`,
          'Content-Type': 'text/plain',
        },
        data: btoa(JSON.stringify(params)),
      };
    } else {
      const mapViewRequestParams = {
        params: this.ParamSerializer.base64(params, true),
      };

      if (constName != null) {
        mapViewRequestParams.constName = constName;
      }

      httpOptions = {
        url,
        method: 'GET',
        headers: {
          Authorization: `Bearer ${this.JWT.get()}`,
        },
        params: mapViewRequestParams,
      };
    }

    return this.$http(httpOptions)
      .then((response) => response.data)
      .then(
        (res) => {
          if (!this.dataCardComparison[filterWatch]) {
            this.dataCardComparison[filterWatch] = {};
          }
          let data = undefined;
          if (!this.layerMode) {
            this.dataCardComparison[filterWatch][inclination] = Object.assign(
              {},
              res,
            );
            data = this.getPercentage(res);
          } else {
            this.dataCardComparison[filterWatch][inclination] = Object.assign(
              {},
              res.cards[inclination],
            );
            data = this.getPercentage(
              res.cards[inclination.replace('residents', 'residents_quantity')],
            ); /* FIX ME : looks like gambi.. */
            if (params.cards[0] === 'count') {
              data = {
                value: res.counters.audience,
              };
            } else {
              data = this.getPercentage(res.cards[params.cards[0]]);
            }
          }
          return data;
        },
        (reason) => {
          const data = {
            error: reason.status,
          };
          return data;
        },
      );
  }

  _getJoinSegments(cardKey) {
    if (
      this.dataCardComparison.primary[cardKey] &&
      this.dataCardComparison.compare[cardKey]
    ) {
      if (
        Object.keys(this.dataCardComparison.primary[cardKey]).length >=
        Object.keys(this.dataCardComparison.compare[cardKey]).length
      ) {
        return this.dataCardComparison.primary[cardKey];
      } else {
        return this.dataCardComparison.compare[cardKey];
      }
    } else {
      if (!this.dataCardComparison.primary[cardKey]) {
        return this.dataCardComparison.compare[cardKey];
      } else {
        return this.dataCardComparison.primary[cardKey];
      }
    }
  }

  _getMajorSegmentsLength(cardKey) {
    if (
      this.dataCardComparison.primary[cardKey] &&
      this.dataCardComparison.compare[cardKey]
    ) {
      if (
        Object.keys(this.dataCardComparison.primary[cardKey]).length >=
        Object.keys(this.dataCardComparison.compare[cardKey]).length
      ) {
        return 'primary';
      } else {
        return 'compare';
      }
    } else {
      if (!this.dataCardComparison.primary[cardKey]) {
        return 'compare';
      } else {
        return 'primary';
      }
    }
  }

  compareForNotColumn() {
    this.totalLayer = 0;
    try {
      if (
        this.dataCardComparison.primary &&
        this.dataCardComparison.primary['state_city']
      ) {
        this.dataCardComparison.primary['state_city'] = this.dataCardComparison[
          'primary'
        ]['state_city'].graph;
      }
      if (
        this.dataCardComparison.compare &&
        this.dataCardComparison.compare['state_city']
      ) {
        this.dataCardComparison.compare['state_city'] = this.dataCardComparison[
          'compare'
        ]['state_city'].graph;
      }

      this.counters = [];
      this.lockCalculation = true;

      const joinCards = Object.assign(
        {},
        this.dataCardComparison['primary'],
        this.dataCardComparison['compare'],
      );
      const cardItemsLength = Object.keys(joinCards).length;
      const comparison = {};

      // Each Card...
      const cardKeys = Object.keys(joinCards);

      for (let cId = 0; cId < cardKeys.length; cId++) {
        if (this.abortCalculation) {
          return false;
        }

        if (!comparison[cardKeys[cId]]) {
          comparison[cardKeys[cId]] = [];
        }

        // Each Data Segment...
        const segments = Object.keys(this._getJoinSegments(cardKeys[cId]));
        const majorContext = this._getMajorSegmentsLength(cardKeys[cId]);
        const minorContext = majorContext == 'primary' ? 'compare' : 'primary';

        for (let sId = 0; sId < segments.length; sId++) {
          const segment = segments[sId];
          let temp = null;
          let p_value = undefined;
          let c_value = undefined;

          temp = Object.assign(
            {},
            this.dataCardComparison[majorContext][cardKeys[cId]][segment],
          );

          p_value = temp
            ? this.getComparisonValue(
                'primary',
                cardKeys[cId],
                temp['label'],
                segments,
              )
            : 0;
          c_value = temp
            ? this.getComparisonValue(
                'compare',
                cardKeys[cId],
                temp['label'],
                segments,
              )
            : 0;

          if (Object.keys(this.customFields).includes(cardKeys[cId])) {
            comparison[cardKeys[cId]] = [];
          } else if (
            !this.dataCardComparison['primary'][cardKeys[cId]] ||
            !this.dataCardComparison['compare'][cardKeys[cId]] ||
            (!Object.keys(this.dataCardComparison.primary[cardKeys[cId]])
              .length ||
              !Object.keys(this.dataCardComparison['compare'][cardKeys[cId]])
                .length) ||
            temp == null
          ) {
            /* -------------------------------
            Proplematic Data Possibilities */
            // One Card is missing of the pair... just assume what we have
            if (temp != null) {
              comparison[cardKeys[cId]].push(temp);
            } else {
              // Everything is null from both sides... there is nothing to do
              comparison[cardKeys[cId]] = [];
            }
          } else {
            /* Subtract. . . . . . . . . . . . . . . . . .
            - - - - - - - - - - - - - - - - - - - - - - -*/

            let parityExists = false;

            for (
              let zxc = 0;
              zxc <
              Object.keys(this.dataCardComparison[minorContext][cardKeys[cId]])
                .length;
              zxc++
            ) {
              if (
                this.dataCardComparison[minorContext][cardKeys[cId]][zxc] &&
                this.dataCardComparison[minorContext][cardKeys[cId]][zxc]
                  .label == temp['label']
              ) {
                parityExists = true;
              }
            }

            if (parityExists) {
              let attempts = 0;
              const syncSubtraction = setInterval(() => {
                if (p_value != undefined && c_value != undefined) {
                  try {
                    if (p_value == c_value) {
                      temp.value = 0;
                    } else {
                      temp.value = Math.abs(p_value - c_value);
                      if (cardKeys[cId] == cardKeys[0]) {
                        this.totalLayer += temp.value;
                      }
                    }
                    comparison[cardKeys[cId]][segment] = temp;
                    clearInterval(syncSubtraction);
                  } catch (error) {}
                } else {
                  p_value = this.getComparisonValue(
                    'primary',
                    cardKeys[cId],
                    temp['label'],
                    segments,
                  );
                  c_value = this.getComparisonValue(
                    'compare',
                    cardKeys[cId],
                    temp['label'],
                    segments,
                  );
                }
                attempts++;
                if (attempts > 10) {
                  p_value = 0;
                  c_value = 0;
                  clearInterval(syncSubtraction);
                }
              }, 500);
            } else {
              p_value = p_value == undefined ? 0 : p_value;
              c_value = c_value == undefined ? 0 : c_value;

              comparison[cardKeys[cId]][segment] = {
                value: Math.abs(p_value - c_value),
                percentage: 0,
                label: temp.label,
              };
            }
          }
        }

        let total = 0;
        for (let seg = 0; seg < segments.length; seg++) {
          let totalAttempts = 0;
          const syncTotal = setInterval(() => {
            if (comparison[cardKeys[cId]].length) {
              try {
                total += comparison[cardKeys[cId]][seg].value;
                clearInterval(syncTotal);
              } catch (error) {}
            }
            totalAttempts++;
            if (totalAttempts > 10) {
              clearInterval(syncTotal);
            }
          }, 500);
        }

        for (let seg = 0; seg < segments.length; seg++) {
          let percAttempts = 0;
          const syncPerc = setInterval(() => {
            if (comparison[cardKeys[cId]].length == segments.length) {
              try {
                comparison[cardKeys[cId]][seg].percentage =
                  (comparison[cardKeys[cId]][seg]['value'] / total) * 100;
                clearInterval(syncPerc);
              } catch (error) {}
            }
            percAttempts++;
            if (percAttempts > 10) {
              clearInterval(syncPerc);
            }
          }, 500);
        }
      }

      comparison.count = {};

      comparison.count.value = Math.abs(
        this.dataCardComparison.primary['count'].value -
          this.dataCardComparison['compare']['count']['value'],
      );

      this.dataCardComparison.not_column_cards = comparison;
      const c_keys = Object.keys(this.dataCardComparison.not_column_cards);

      // =========================================
      // bypass different structure for layer mode
      if (isNaN(comparison.count.value)) {
        comparison.count.value = this.totalLayer;
        if (comparison.count.value == 0) {
          let attempts_sync2 = 0;
          const sync2 = setInterval(() => {
            if (comparison.count.value == 0 && this.totalLayer == 0) {
              const dataContext =
                Object.keys(this.dataCardComparison.primary[cardKeys[0]])
                  .length > 0
                  ? 'primary'
                  : 'compare';
              const contextKeys = Object.keys(
                this.dataCardComparison[dataContext][cardKeys[0]],
              );
              let ctxTotal = 0;
              for (let idc = 0; idc < contextKeys.length; idc++) {
                ctxTotal += this.dataCardComparison[dataContext][cardKeys[0]][
                  contextKeys[idc]
                ].value;
              }
              comparison.count.value = Math.ceil(ctxTotal / contextKeys.length);
            } else {
              clearInterval(sync2);
            }
            attempts_sync2++;
            if (attempts_sync2 > 10) {
              clearInterval(sync2);
            }
          }, 500);
        }
      }

      let counter = 0;
      Object.keys(this.dataCardComparison.not_column_cards).forEach(
        (key) => counter++,
      );
      const sync = setInterval(() => {
        if (counter >= this.cardItemsLength) {
          this.lockCalculation = false;
          clearInterval(sync);
          this.showComparison = true;
          this.$rootScope.$broadcast(SHOW_COMPARISON_PANEL);
          this.$rootScope.$apply();
        }
      }, 500);
    } catch (calc_error) {
      this.$log.error('CALCULATION ERROR', calc_error);
      this.lockCalculation = false;
      this.abortCalculation = true;
    }
  }

  rebuildCardSelection() {
    this.cardsSelected = [];
    this.temp_cards = [];
    this.DimensionService.availableGroups.forEach((element) => {
      if (element.dimensions[this.AudienceTypes.selected]) {
        this.temp_cards = this.temp_cards.concat(
          element.dimensions[this.AudienceTypes.selected],
        );
      }
    });

    for (let i = 0; i < this.temp_cards.length; i++) {
      if (this.temp_cards[i]) {
        this.cardsSelected.push({
          id: this.temp_cards[i].id,
          check: true,
          constName: this.temp_cards[i].config.constName,
          name: this.$translate.instant(
            'CARDS.' + this.temp_cards[i].config.constName + '.TITLE',
          ),
        });
      }
    }
  }

  isCardSelected(constName) {
    for (let i = 0; i < this.cardsSelected.length; i++) {
      if (constName == this.cardsSelected[i].constName) {
        return this.cardsSelected[i].check;
      }
    }
    return true;
  }

  getComparisonValue(col, card, label, segments) {
    try {
      if (
        !segments ||
        !this.dataCardComparison[col] ||
        !this.dataCardComparison[col][card]
      ) {
        return undefined;
      }
      let value = 0;
      for (let i = 0; i < segments.length; i++) {
        if (
          this.dataCardComparison[col][card] &&
          this.dataCardComparison[col][card][segments[i]].label == label
        ) {
          value = this.dataCardComparison[col][card][segments[i]].value;
          break;
        }
      }
      return value;
    } catch (error) {
      return undefined;
    }
  }

  getComparedValue(card, label) {
    const segments = Object.keys(
      this.dataCardComparison['not_column_cards'][card],
    );
    for (let i = 0; i < segments.length; i++) {
      if (this.dataCardComparison.not_column_cards[card][i].label == label) {
        return this.dataCardComparison.not_column_cards[card][i].value;
      }
    }
    return 'No Data Available';
  }

  resetNotPanelCompletely() {
    $('.panel-cards .panel-content').off('scroll');
    if (this.dataCardComparison.primary) {
      delete this.dataCardComparison['primary'];
    }
    if (this.dataCardComparison.compare) {
      delete this.dataCardComparison['compare'];
    }
    if (this.dataCardComparison.not_column_cards) {
      delete this.dataCardComparison['not_column_cards'];
    }

    this.showComparison = false;

    setTimeout(() => {
      this.abortCalculation = false;
    }, 500);
  }

  setGuid(guid) {
    this.guid = guid;
  }

  setParams(params) {
    this.params = params;
  }

  getPercentage(data) {
    if (data instanceof Array) {
      const total = data.reduce((prev, cur) => {
        return prev + cur.value;
      }, 0);

      const newData = data.map((d) => {
        d.percentage = (d.value / total) * 100;
        return d;
      });

      return newData;
    }
    return data;
  }
}
