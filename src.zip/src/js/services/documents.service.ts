import CardsService from './cards.service';
import FiltersService from './filters.service';
import JWT from './jwt.service';
import LayersService from './layers.service';
import { ExtractionField } from '../core/models';
import { StateService } from '@uirouter/core';
import { SweetAlertService } from './sweet-alert.service';
import { AudienceType } from './audience-types.service';
import { UserService } from './user.service';

export default class DocumentsService {
  public userCount: number;
  public baseId: string;
  public count = 0;
  public fields = [] as ExtractionField[];
  public userMosaicRule: boolean;  

  private group = '';
  private personGroup = [];
  private radius = '';
  private multi;
  private tags;
  private fmtFilters;
  private blockSubmit: boolean;
  private exclusion_database_id: string;
  private selectedFields: string[];

  constructor(
    private $http: ng.IHttpService,
    private $q: ng.IQService,
    private $state: StateService,
    private AppConstants,
    private Cards: CardsService,
    private CUSTOM_DOCUMENTS,
    private Filters: FiltersService,
    private JWT: JWT,
    private Layers: LayersService,
    private Markers,
    private SweetAlert: SweetAlertService,
    private Tab,
    private User: UserService,
  ) {
    'ngInject';
  }

  setOptions(
    options: DocumentsServiceOptions,
    exclude: boolean,
  ) {
    this.multi = options.multi;
    this.group = options.group;
    this.count = options.count || 0;
    this.tags = options.tags;
    this.fmtFilters = options.fmtFilters;
    this.fields = options.fields;
    this.blockSubmit = false;

    if (exclude) {
      this.exclusion_database_id = this.baseId;
      this.baseId = 'serasa';
    }

    this.selectFields();
  }

  selectFields() {
    this.blockSubmit = true;
    this.userMosaicRule = this.User.info.account.config.customVars?.cs_mosaic_pj;
    this.selectedFields = this.fields
      .filter((field) => (field.name === 'mosaic' && !this.userMosaicRule && !this.Tab.isResidents())? null : field.checked)
      .reduce((selectedFields, field) => {
        this.blockSubmit = false;

        selectedFields.push(field.name);

        return selectedFields;
      }, []);
  }

  /**
   * Chamada para a extração de base
   * @param {*} group
   */
  async submitRequest(group: AudienceType) {

    const data = {
      fields: this.selectedFields,
    } as {
      fields: string[];
      audience: {
        filters: string[];
        count: number;
        database_id?: string;
        exclusion_database_id?: string;
        location?: any;
        limit: number;
      };
    };
    const params = this.Filters.getParams();

    data.audience = {
      filters: params.filters,
      count: this.count,
      limit: this.userCount,
    };

    if (this.baseId) {
      data.audience.database_id = this.baseId;
    }

    if (this.exclusion_database_id) {
      data.audience.exclusion_database_id = this.exclusion_database_id;
      delete this.exclusion_database_id;
    }

    let target = null;
    if (this.$state.current.name == 'app.data-view') {
      target = `region/${this.baseId}`;
      data.audience.location = this.Layers.selection;
      data.audience.location['entity-origin'] = 'CORREIOS';
    } else {
      if (this.Cards.layerMode) {
        target = `region/${this.baseId}`;
        data.audience.location = this.Layers.selection;
        data.audience.location['entity-origin'] = 'IBGE';
      } else {
        target = this.Markers.primary.guid;
      }
    }

   const userConfirmed = await this.SweetAlert.confirmation('COMPONENTS.REQUEST_DOCUMENTS_MODAL.CONFIRMATION.TEXT');
    if (userConfirmed?.value === true) {
      return this.$http({
        url: `${this.AppConstants.api()}/data/request/${target}/${group}/documents-enhancement`,
        method: 'POST',
        headers: {
          Authorization: 'Bearer ' + this.JWT.get(),
        },
        data,
      }).then(
        () => {
          this.SweetAlert.success(
            'COMPONENTS.REQUEST_DOCUMENTS_MODAL.MESSAGES.SUCCESS',
          );
          $('#requestDocumentsModal').modal('hide');
        },
        () => {
          this.SweetAlert.error(
            'COMPONENTS.REQUEST_DOCUMENTS_MODAL.MESSAGES.ERROR',
          );
        },
      );
    } else {
      return Promise.reject('Usuário cancelou a solicitação');
    }
  }
}

export interface DocumentsServiceOptions {
  multi?: any;
  group?: any;
  tags?: any[];
  count?: number;
  fmtFilters?: any;
  fields: ExtractionField[];
}
