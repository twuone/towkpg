export default class SnapshotService {
  constructor(
    $http,
    $log,
    AppConstants,
    JWT,
    ParamSerializer,
    Filters,
    Cards,
    AudienceTypes,
    $rootScope,

    // ,
    // AudienceTypes, $rootScope, $translate, $state, Markers, Cards, SweetAlert, Tab
  ) {
    'ngInject';

    this._AppConstants = AppConstants;
    this.$log = $log;
    this._JWT = JWT;
    this._$http = $http;
    this._ParamSerializer = ParamSerializer;
    this._Filters = Filters;
    this._AudienceTypes = AudienceTypes;
    this.Cards = Cards;
    this.$rootScope = $rootScope;

    // this._$translate = $translate;
    this.dimensionsHashMap = {};
    this.available = [];
    this.dimensionUrl = `${this._AppConstants.api('v2')}/dimensions/snapshots`;
    this.snapshotByAudiences = {};
  }

  applyFilters() {
    let filters = null;
    this.available.forEach((element) => {
      if (element.name == this._AudienceTypes.selected) {
        filters = element.filters;
        this._AudienceTypes.applied = this._AudienceTypes.selected;
      }
    });

    if (filters) {
      /* Cards Selected
      ----------------- */
      const selectedDimensions = this.Cards.cardsSelected;
      for (let s = 0; s < selectedDimensions.length; s++) {
        for (let i = 0; i < filters.length; i++) {
          if (selectedDimensions[s].id == filters[i].dimensionId) {
            this.Cards.cardsSelected[s].check = true;
            break;
          }
          this.Cards.cardsSelected[s].check = false;
        }
      }
    } else {
      return false;
    }
    return true;
  }

  fetch() {
    return this._$http({
      url: this.dimensionUrl,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then(
      (res) => {
        this.available = res.data;
        this.available.forEach((element) => {
          this.snapshotByAudiences[element.name] = element.id;
        });

        this.createCardHash();
      },
      (err) => {
        // if (this.options && this.options[key]) {
        //   this.options[key] = [];
        // }
      },
    );
  }

  createCardHash() {
    const sync = setInterval(() => {
      if (Object.keys(this.Cards.available).length > 2) {
        clearInterval(sync);
        const audienceKeys = Object.keys(this.Cards.available);
        for (let i = 0; i < audienceKeys.length; i++) {
          for (
            let j = 0;
            j < Object.keys(this.Cards.available[audienceKeys[i]]).length;
            j++
          ) {
            this.dimensionsHashMap[
              this.Cards.available[audienceKeys[i]][j].id
            ] = this.Cards.available[audienceKeys[i]][j].name;
          }
        }
      }
    }, 500);
  }

  save(dimensions) {
    /*
    Process Filters Activated -------------------------- */
    this._AudienceTypes.applied = this._AudienceTypes.selected;
    const filters = this._Filters.getFilters(true, false);

    const filtersStructure = {};
    for (let i = 0; i < filters.length; i++) {
      filtersStructure[filters[i].name] = filters[i].values;
    }

    const selectedDimensions = [];

    for (let i = 0; i < dimensions.length; i++) {
      if (dimensions[i].check) {
        let f_name = dimensions[i].constName.toLowerCase();
        f_name = f_name.replace('cnae_group', 'cnae');
        f_name = f_name.replace('mosaic_pj', 'mosaic');

        const filterVal = filtersStructure[f_name] || [];

        selectedDimensions.push({
          dimensionId: dimensions[i].id,
          values: filterVal,
        });
      }
    }

    let method = 'POST';
    const data = {
      name: this._AudienceTypes.selected,
      filters: selectedDimensions,
    };
    let url = this.dimensionUrl;
    if (
      Object.keys(this.snapshotByAudiences).includes(
        this._AudienceTypes.selected,
      )
    ) {
      method = 'PUT';
      url += '/' + this.snapshotByAudiences[this._AudienceTypes.selected];
    }
    return this._$http({
      url,
      method,
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
      data,
    }).then(
      (res) => {
        this.fetch();
      },
      (err) => {
        this.$log.error(err);
      },
    );
  }
}
