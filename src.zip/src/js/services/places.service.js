import { IMPORT_MARKERS_FINISHED } from '../app.actions';

export default class Places {
  constructor($http, AppConstants, JWT, Markers, SweetAlert, $rootScope) {
    'ngInject';

    this._$http = $http;
    this._AppConstants = AppConstants;
    this._JWT = JWT;
    this._Markers = Markers;
    this._AutoComplete = null;
    this.SweetAlert = SweetAlert;
    this.$rootScope = $rootScope;
    this.places = [];
    this.availableTags = [];

    this.queue = {
      empty: true,
    };
  }

  getPlaces() {
    return this._$http({
      url: `${this._AppConstants.api()}/marker`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then((res) => {
      this.places = res.data;
      this.availableTags = this.getTagsFromPlaces();
      return this.places;
    });
  }

  getTagsFromPlaces() {
    const tags = new Set();

    this.places.forEach((place) => {
      if (place.tags) {
        place.tags.forEach((tag) => {
          tags.add(tag);
        });
      }
    });

    return [...tags];
  }

  autoComplete(input) {
    if (this._AutoComplete === null) {
      this._AutoComplete = new google.maps.places.AutocompleteService();
    }
    return new Promise((resolve, reject) => {
      this._AutoComplete.getQueryPredictions(
        { input },
        (predictions, status) => {
          if (status != google.maps.places.PlacesServiceStatus.OK) {
            reject(status);
          } else {
            resolve(predictions);
          }
        },
      );
    });
  }

  getDetails(placeId) {
    const service = new google.maps.places.PlacesService(
      document
        .getElementsByTagName('html')[0]
        .appendChild(document.createElement('div')),
    );

    return new Promise((resolve, reject) => {
      service.getDetails({ placeId }, (place, status) => {
        if (status != google.maps.places.PlacesServiceStatus.OK) {
          reject(status);
        } else {
          const formatedPlace = {
            desc: place.formatted_address,
            points: [
              {
                latitude: place.geometry.location.lat(),
                longitude: place.geometry.location.lng(),
              },
            ],
            type: place.types[0],
            viewport: place.geometry.viewport,
          };
          resolve(formatedPlace);
        }
      });
    });
  }

  send(markers) {
    return this._$http({
      url: `${this._AppConstants.api()}/marker/add`,
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
      data: {
        markers,
      },
    });
  }

  sendMarkerEdit(marker) {
    return this._$http({
      url: `${this._AppConstants.api()}/marker/${marker.id}`,
      method: 'PUT',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
      data: marker,
    });
  }

  sendBatchingPlaces(file) {
    return this._$http({
      url: `${this._AppConstants.api()}/marker/validate`,
      method: 'POST',
      headers: {
        'Content-Type': 'text/csv',
        Authorization: 'Bearer ' + this._JWT.get(),
      },
      data: file,
    });
  }

  getCurrentLocation() {
    return new Promise((resolve, reject) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            resolve(position.coords);
          },
          () => {
            // default são paulo
            resolve({
              latitude: -23.5505199,
              longitude: -46.63330940000003,
            });
          },
        );
      } else {
        reject("Browser doesn't support Geolocation");
      }
    });
  }

  /**
   * Returns a list with all upload queue data
   * @return {Promise} [description]
   */
  getExecutionQueue() {
    return this._$http({
      url: `${this._AppConstants.api('v2')}/marker/execution`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then((res) => {
      if (res.data.length) {
        this.queue.list = res.data;
        this.queue.empty = false;
      } else {
        this.queue.empty = true;
      }
      return this.queue;
    });
  }

  /**
   * Send a file to be processed by the queue
   * @param  {Blob} file A CSV file
   * @return {Promise}
   */
  uploadToQueue(file) {
    return this._$http({
      url: `${this._AppConstants.api('v2')}/marker/upload`,
      method: 'POST',
      headers: {
        'Content-Type': 'text/csv',
        Authorization: 'Bearer ' + this._JWT.get(),
        'File-Name': file.name,
      },
      data: file,
    }).then((res) => {
      this.SweetAlert.success(
        'COMPONENTS.PLACES_MODAL.MESSAGES.FILE_SENT.TITLE',
        'COMPONENTS.PLACES_MODAL.MESSAGES.FILE_SENT.MESSAGE',
      );
      this.getExecutionQueue();
    });
  }

  /**
   * Get the result of a job and parses it
   * @param  {Integer} uploadId
   * @return {Promise}
   */
  getJobResult(uploadId) {
    return this._$http({
      url: `${this._AppConstants.api('v2')}/marker/${uploadId}`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then((res) => {
      this.queue.selection = {
        markers: {
          valid: [],
          invalid: [],
        },
      };

      res.data['validated-markers'].forEach((marker) => {
        if (marker.status === 'ok') {
          this.queue.selection.markers.valid.push(marker);
        } else {
          this.queue.selection.markers.invalid.push(marker);
        }
      });
    });
  }

  importQueueSelection() {
    this.send(this.queue.selection.markers.valid).then(() => {
      this.getPlaces().then((data) => {
        this.places = data;
        this.SweetAlert.success(
          'COMPONENTS.PLACES_MODAL.MESSAGES.POINTS_ADDED.TITLE',
          'COMPONENTS.PLACES_MODAL.MESSAGES.POINTS_ADDED.MESSAGE',
        );
        this.$rootScope.$broadcast(IMPORT_MARKERS_FINISHED);
      });
    });
  }
}
