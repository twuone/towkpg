import { FilterTypes } from '../shared/models/filter-types.enum';

function isDimensionTypeAffinity(dimension) {
  return dimension?.config?.filterType === FilterTypes.Affinity;
}

export default class FilterService {
  constructor(DimensionService, AudienceTypes) {
    'ngInject';

    this.DimensionService = DimensionService;
    this.AudienceTypes = AudienceTypes;
  }

  setup() {
    this.availableGroups = {};
    this.DimensionService.availableGroups.forEach((group) => {
      this.setupDimensionGroup(group);
    });
  }

  getAffinities() {
    return Object.values({...this.availableGroups})
      .map((dimensionGroup) => dimensionGroup.dimensions)
      .reduce((dimensions, audience) =>
        dimensions.concat(Object.values(audience)), [])
      .reduce((affinities, affinitiesObject) =>
        affinities.concat(Object.values(affinitiesObject)), [])
      .filter((dimension) => isDimensionTypeAffinity(dimension));
  }

  setupDimensionGroup(group) {
    this.availableGroups[group.id] = angular.copy(group);
    const dimensionIdsFields = ['dimensionIds', 'id'];
    dimensionIdsFields.forEach((idField) => {
      this.removeIdField(idField, group);
    });

    Object.keys(this.availableGroups[group.id].dimensions).forEach(
      (audience) => {
        this.setupDimension(group, audience);
      },
    );
  }

  setupDimension(group, audience) {
    const dimensionsObj = {};

    this.availableGroups[group.id].dimensions[audience].forEach((dimension) => {
      dimensionsObj[dimension.id] = {
        name: dimension.name,
        config: dimension.config,
        values: {},
      };
      dimension.values.forEach((value) => {
        dimensionsObj[dimension.id].values[value] = true;
      });
    });

    this.availableGroups[group.id].dimensions[audience] = dimensionsObj;
  }

  removeIdField(idField, group) {
    delete this.availableGroups[group.id][idField];
  }

  getModel(groupName, dimensionName) {
    if (this.DimensionService.availableGroups) {
      const audience = this.AudienceTypes.selected;

      const group = this.DimensionService.availableGroups.filter((g) =>
        g.name.includes(groupName),
      )[0];

      const dimension = group.dimensions[audience].filter(
        (d) => d.name === dimensionName,
      )[0];
      const model = this.availableGroups[group.id].dimensions[audience][
        dimension.id
      ];

      return model;
    } else {
      return null;
    }
  }
}
