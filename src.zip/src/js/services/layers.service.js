import {
  CHANGE_CUSTOM_LAYER_SELECTION,
  CHANGE_LAYER_MODE,
  CLEAN_MAP_DATA,
  FINISH_MAP_LOADING,
  LOAD_LAYER_SELECTION,
  RELEASE_MAP,
  REMOVE_MAP_EVENTS_OF_THEMES,
  RESET_NOT_PANEL_COMPLETELY,
  SELECT_BY_LAYER,
  SELECT_BY_SUBLAYER,
  STYLIZE_MAP,
} from '../app.actions';

export default class LayersService {
  constructor(
    $http,
    $log,
    $rootScope,
    $state,
    $translate,
    AppConstants,
    AudienceTypes,
    Cards,
    Filters,
    JWT,
    Markers,
    ParamSerializer,
    SweetAlert,
    Tab,
  ) {
    'ngInject';

    this.$log = $log;
    this.$http = $http;
    this.$rootScope = $rootScope;
    this.$state = $state;
    this.$translate = $translate;
    this.AppConstants = AppConstants;
    this.AudienceTypes = AudienceTypes;
    this.Cards = Cards;
    this.Filters = Filters;
    this.JWT = JWT;
    this.Markers = Markers;
    this.ParamSerializer = ParamSerializer;
    this.SweetAlert = SweetAlert;
    this.Tab = Tab;

    this.accountName = '';

    /* ===========
			Layers
		=========== */
    this.activated = false;
    this.IsMapClear = true;

    // IBGE //
    this.cityProps = null;
    this.limitSlugLen = 3;
    this.currentLayer = null;
    this.noNeighborhood = false;
    this.currentSubLayer = null;
    this.loadingCep5SectorData = false;
    this.dataCep5Sector = [];
    this.lastSelectedType = 'country';
    this.lastSelectedValue = 'Brasil';
    this.selection = {
      country: 'br',
    };
    this.selectFields = ['country', 'state', 'city', 'neighborhood'];
    this.zoomLevelLayer = {
      country: 3,
      state: 5,
      city: 5,
      neighborhood: 12,
    };
    this.enabledSubLayers = {
      bairros: false,
      ceps5: false,
      censitarias: false,
    };

    // Themes //
    this.customThemesLayer = false;
    this.currentCustomLayer = null;
    this.allThemes = [
      {
        fileName: 'IBGE',
        shapeFileId: null,
        source: 'Serasa',
      },
    ];

    // Init public variables
    this.available = [
      {
        id: 'serasa',
        name: 'Serasa Experian',
      },
    ];

    this.queue = {
      empty: true,
    };

    this.slug = {
      fragments: {},
      get() {
        return `/${this.fragments.join()}/`;
      },
      clear() {
        return (this.fragments = []);
      },
    };

    //COMBAK This should really be inside the component, not the service.
    this.multiField = {
      validate: () => {
        const length = this.multiField.value.length;
        if (length == 5 && !isNaN(this.multiField.value)) {
          this.multiField.type = 'cep5';

          // } else if(length == 8 && !isNaN(this.multiField.value)) {
          // 	this.multiField.type = "cep8";
        } else if (length == 15 && !isNaN(this.multiField.value)) {
          this.multiField.type = 'sector_code';
        } else {
          this.multiField.type = 'invalid';
          this.multiField.reset();
        }

        if (this.multiField.type) {
          this.multiField.set();
        }
      },
      set: () => {
        if (this.multiField.type == 'cep5' || this.multiField.type == 'cep8') {
          this.selection.cep = this.multiField.value;
          delete this.selection.sector_code;
        } else if (this.multiField.type == 'sector_code') {
          this.selection.sector_code = this.multiField.value;
          delete this.selection.cep;
        }
      },
      reset: (hard) => {
        if (!this.multiField.value || hard) {
          this.multiField.value = ''; // This looks reduntant, but it is not
          delete this.multiField.type;
        }
        delete this.selection.cep;
        delete this.selection.sector_code;
      },
    };

    let attempts = 0;
    this.clock = setInterval(() => {
      attempts++;
      if (!this.queue.empty) {
        clearInterval(this.clock);
        this.getSerasaAndUserThemes();
      } else if (attempts == 10) {
        clearInterval(this.timerToMapLayerReload);
      }
    }, 250);
  }

  isValid() {
    if (this.activated) {
      if (this.multiField.value != '') {
        return this.multiField.type != 'invalid';
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  resetIbgeCombos() {
    this.noNeighborhood = false;
    this.clearSubLayers();
    this.currentSubLayer = null;
    this.clearSelection();
    this.currentLayer = null;
    this.resetEnvironment();
  }

  resetEnvironment() {
    this.cityProps = null;
    this.limitSlugLen = 3;
    this.currentLayer = null;
    this.noNeighborhood = false;
    this.currentSubLayer = null;
    this.customThemesLayer = false;
    this.loadingCep5SectorData = false;
    this.dataCep5Sector = [];
    this.lastSelectedType = 'country';
    this.lastSelectedValue = 'Brasil';
    this.selection = {
      country: 'br',
    };
    this.selectFields = ['country', 'state', 'city', 'neighborhood'];
    this.zoomLevelLayer = {
      country: 3,
      state: 5,
      city: 5,
      neighborhood: 10,
    };
    this.enabledSubLayers = {
      bairros: false,
      ceps5: false,
      censitarias: false,
    };
  }

  reset() {
    this.activated = false;
    this.geojson = null;
    this.clearSubLayers();
    this.currentSubLayer = null;
    this.clearSelection();
    this.currentLayer = null;
    this.slug.clear();
    this.resetEnvironment();
  }

  changeMode() {
    this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
    if (this.AudienceTypes.applied == 'visitors') {
      this.AudienceTypes.cards = 'residents';
      this.AudienceTypes.previous = 'residents';
      this.AudienceTypes.applied = 'residents';
      this.Tab.cards = 'residents';
    }

    this.$rootScope.$broadcast(CHANGE_LAYER_MODE, {});
    if (!this.activated) {
      this.reset();
      if (this.Markers.primary.guid == 'layer') {
        this.Markers.reset();
      }
    } else {
      this.currentCustomLayer = this.allThemes[0];
    }
  }

  reloadNextFields(index, reloading_sublayer = false) {
    // Reset state for clean navigation ==================================
    // -------------------------------------------------------------------
    this.multiField.reset(true);
    if ((index == 1 || index == 2) && !reloading_sublayer) {
      this.clearSubLayers();
    }

    // Reset next until last
    Object.keys(this.selectFields).forEach((key, keyIndex) => {
      if (keyIndex + 1 > index) {
        delete this.selection[this.selectFields[keyIndex + 1]];
      }
    });
    if (this.selection.cep) {
      delete this.selection.cep;
    }
    if (this.selection.sector_code) {
      delete this.selection.sector_code;
    }
    if (this.selection.ibge_query) {
      delete this.selection.ibge_query;
    }

    // END ---------------------------------------------------------------

    // loading a sub-layer?
    this.currentLayer = this.selectFields.neighborhood
      ? 'neighborhood'
      : this.selectFields[index + 1];

    // Get Next (If not last)
    if (index + 1 < this.selectFields.length) {
      // Get data for nex Level
      this.get(this.currentLayer).then(() => this.multiField.reset(true));
    } else {
      if (this.$state.current.name != 'app.data-view') {
        this.findSubLayerInGeoJson('NAME');
      }
    }

    this.lastSelectedValue = this.selection[this.selectFields[index]];
    this.lastSelectedType = this.selectFields[index];
  }

  findSubLayerInGeoJson(label) {
    let foundElement = false;
    let element = null;
    for (let i = 0; i < this.geojson.features.length; i++) {
      const val =
        label == 'NAME'
          ? this.geojson.features[i].properties.metadata[label].toLowerCase()
          : this.geojson.features[i].properties.metadata[label];
      if (this.selection.neighborhood == val) {
        element = {
          feature: this.geojson.features[i],
        };
        foundElement = true;
        break;
      }
    }
    if (foundElement) {
      this.$rootScope.$broadcast(SELECT_BY_SUBLAYER, element);
    }
  }

  findLayerInGeoJson() {
    let labelValue = null;
    let labelType = null;
    if (this.selection.city) {
      labelValue = 'MUNICIPIO';
      labelType = 'city';
    } else if (this.selection.state) {
      labelValue = 'UF';
      labelType = 'state';
    }
    if (labelValue && labelType) {
      this.$rootScope.$broadcast(SELECT_BY_LAYER, {
        name: this.selection[labelType],
        type: labelValue,
      });
    }
  }

  textFieldSelection() {
    if (this.multiField.value) {
      this.findCep5OrSector(this.multiField.value);
    } else {
      if (this.selection.neighborhood) {
        this.findSubLayerInGeoJson('NAME');
      } else {
        this.$rootScope.$broadcast(LOAD_LAYER_SELECTION, {});
      }
    }
  }

  findCep5OrSector(value) {
    /* SP, Capital => test me: 355030885000006 */
    this.searchingCepCode = true;
    this.multiField.validate();
    if (this.multiField.type != 'invalid') {
      const label = value.length == 5 ? 'CEP5' : 'COD_SETOR';
      if (
        Object.values(this.dataCep5Sector)
          .map((el) => el.label)
          .indexOf(value) != -1
      ) {
        if (this.selection.neighborhood) {
          delete this.selection.neighborhood;
        }
        this.Cards.layerMode = true;
        this.Markers.primary.guid = 'layer';
        this.Markers.primary.title = value;
        this.Markers.primary.desc = this.$translate.instant(
          `COMPONENTS.MAP.LAYERS.TYPES.${label.toUpperCase()}`,
        );

        // this._Filters.change('primary');
      } else {
        this.SweetAlert.info(
          this.$translate.instant(
            'COMPONENTS.MAP.LAYERS.MESSAGES.NOT_FOUND_TITLE',
          ),
          this.$translate.instant('COMPONENTS.MAP.LAYERS.MESSAGES.NOT_FOUND') +
            ' ' +
            value,
          false,
        );
      }
    }

    this.searchingCepCode = false;
  }

  extractInfoFromLayer(obj) {
    let layerTitle = '';
    let layerType = '';

    if (obj.MUNICIPIO) {
      layerTitle = obj.MUNICIPIO.toLowerCase();
      layerType = 'city';
    } else if (obj.UF) {
      layerTitle = obj.UF.toLowerCase();
      layerType = 'state';
    } else if (obj.NAME) {
      // ---- Sub Layers Logic ----------------
      layerType = 'neighborhood';
      layerTitle = obj.NAME.toLowerCase();
    } else if (obj.CEP5) {
      layerType = 'CEP5';
      layerTitle = obj.CEP5;
    } else if (obj.COD_SETOR) {
      layerType = 'COD_SETOR';
      layerTitle = obj.COD_SETOR;
    }
    return {
      layerType,
      layerTitle,
    };
  }

  selectSubLayerOption(option) {
    this.currentSubLayer = option;
    this.reloadNextFields(2, true);
  }

  clearSelection() {
    Object.keys(this.selectFields).forEach((key, keyIndex) => {
      delete this.selection[this.selectFields[keyIndex + 1]];
    });

    if (this.$state.current.name == 'app.map-view') {
      if (this.activated) {
        this.get();
        this.$rootScope.$broadcast(FINISH_MAP_LOADING, {});
      }
    }
  }

  clearSubLayers() {
    this.currentSubLayer = null;
    Object.keys(this.enabledSubLayers).forEach((key_type, keyIndex) => {
      this.enabledSubLayers[key_type] = false;
    });
    this.multiField.reset(true);
  }

  getSlug(remove_attr) {
    let slug = '';

    if (remove_attr) {
      if (this.selection.hasOwnProperty(remove_attr)) {
        delete this.selection[remove_attr];
      }
    }

    let sl = 0;
    Object.keys(this.selection).forEach((key) => {
      if (this.selection[key] != true && this.selection[key] != false) {
        if (sl < this.limitSlugLen) {
          slug = `${slug}/${this.selection[key].replace(/ /g, '-')}`.replace(
            '\n',
            '',
          );
        }
      }
      sl++;
    });
    return slug;
  }

  getUrl() {
    if (this.$state.current.name == 'app.map-view') {
      return `${this.AppConstants.api(null, '/')}assets/layers/ibge`;
    } else if (this.$state.current.name == 'app.data-view') {
      return '/assets/layers';
    }
  }

  noNeighborhoodReset() {
    this.clearSubLayers();
    this.enabledSubLayers.bairros = false;
    this.selection.neighborhood = null;
    this.options.neighborhood = null;
    this.noNeighborhood = true;
    this.status = 'finished';
    this.currentSubLayer = 'generic';
  }

  loadCepAndSector() {
    this.loadingCep5SectorData = true;
    this.dataCep5Sector = [];
    if (this.cityProps[this.selection.city].hasCep) {
      this.getOnlyIndex(null, null, {
        type: 'ceps5',
      }).then(
        (res) => {
          this.dataCep5Sector = res.data;
        },
        (err) => {
          this.$log.error(err);
        },
      );
    }

    if (this.cityProps[this.selection.city].hasSector) {
      this.getOnlyIndex(null, null, {
        type: 'censitarias',
      })
        .then(
          (res) => {
            this.dataCep5Sector = this.dataCep5Sector.concat(res.data);
          },
          (err) => {
            this.$log.error(err);
          },
        )
        .finally(() => {
          this.loadingCep5SectorData = false;
        });
    }
  }

  get(key, slug, subLayer) {
    let url = null;
    if (subLayer && !slug) {
      url = `${this.getUrl()}${this.getSlug('ibge_query')}/${
        subLayer.type
      }/index.json`;
    } else {
      url = `${this.getUrl()}${this.getSlug()}/index.json`;
    }

    return this.$http({
      url,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    }).then(
      (res) => {
        if (!this.options) {
          this.options = {};
        }

        // Determine City Props
        if (this.selection.state && !this.selection.city) {
          this.cityProps = {};
          for (let i = 0; i < res.data.length; i++) {
            const item = res.data[i];
            this.cityProps[item.value] = {
              hasNeighborhood: item.temBairro,
              hasCep: item.temCep5,
              hasSector: item.temCensitaria,
            };
          }
        }

        //
        if (
          this.selection.city &&
          !this.selection.neighborhood &&
          !this.currentSubLayer
        ) {
          if (this.cityProps[this.selection.city].hasNeighborhood) {
            this.currentSubLayer = 'bairros';
            this.noNeighborhood = false;
          } else {
            this.noNeighborhoodReset();
            subLayer = false;
          }
          this.loadCepAndSector();
        }

        let layerLoad = true;

        // load subLayer or abort
        if (this.selection.city) {
          if (
            this.cityProps[this.selection.city].hasNeighborhood &&
            !subLayer
          ) {
            this.get(key, slug, {
              type: 'bairros',
            });
            layerLoad = false;
          }
        }

        this.options[key] = res.data;
        if (this.$state.current.name == 'app.map-view' && layerLoad) {
          this.status = 'busy';
          this.geojson = false;
          if (subLayer) {
            this.getMap(subLayer);
          } else {
            this.getMap();
          }
        }
      },
      (err) => {
        if (this.options && this.options[key]) {
          this.options[key] = [];
        }
      },
    );
  }

  /**
   * Returns a list with all upload queue data
   * @return {Promise} [description]
   */
  getSerasaAndUserThemes() {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/layers/private/theme/serasa`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    })
      .then(
        (res) => {
          this.allThemes = [
            {
              fileName: 'IBGE',
              shapeFileId: null,
              source: 'Serasa',
            },
          ];
          for (let i = 0; i < res.data.length; i++) {
            this.allThemes.push({
              fileName: res.data[i].fileName.replace('.zip', ''),
              requestDate: res.data[i].requestDate,
              shapeFileId: res.data[i].shapeFileId,
              source: 'Serasa',
            });
          }
        },
        (err) => {
          this.$log.error(err);
        },
      )
      .finally(() => {
        this.$http({
          url: `${this.AppConstants.api('v2')}/layers/private/theme`,
          method: 'GET',
          headers: {
            Authorization: 'Bearer ' + this.JWT.get(),
          },
        }).then(
          (res_2) => {
            for (let j = 0; j < res_2.data.length; j++) {
              this.allThemes.push({
                fileName: res_2.data[j].fileName.replace('.zip', ''),
                requestDate: res_2.data[j].requestDate,
                shapeFileId: res_2.data[j].shapeFileId,
                source: this.accountName,
              });
            }
          },
          (err_2) => {
            this.$log.error(err_2);
          },
        );
      });
  }

  getExecutionQueue() {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/layers/private/shapefile`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    }).then((res) => {
      if (res.data.length) {
        this.queue.list = res.data;
        this.queue.empty = false;
      } else {
        this.queue.empty = true;
      }
    });
  }

  /**
   * Send a file to be processed by the queue
   * @param  {Blob} file A ZIP file
   * @return {Promise}
   */
  uploadToQueue(file) {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/layers/private/shapefile`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/zip',
        Authorization: 'Bearer ' + this.JWT.get(),
        'File-Name': file.name,
      },
      data: file,
    }).then((res) => {
      this.SweetAlert.success(
        'COMPONENTS.LAYER_MANAGER_MODAL.MESSAGES.FILE_SENT.TITLE',
        'COMPONENTS.LAYER_MANAGER_MODAL.MESSAGES.FILE_SENT.MESSAGE',
      );
      this.getExecutionQueue();
      this.getSerasaAndUserThemes();
    });
  }

  /**
   * Get the result of a job and parses it
   * @param  {Integer} uploadId
   * @return {Promise}
   */
  getJobResult(uploadId) {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/layers/private/theme/${uploadId}`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    }).then((res) => {
      this.queue.selection = {
        markers: {
          valid: [],
          invalid: [],
        },
      };
      res.data['validated-markers'].forEach((marker) => {
        if (marker.status === 'ok') {
          this.queue.selection.markers.valid.push(marker);
        } else {
          this.queue.selection.markers.invalid.push(marker);
        }
      });
    });
  }

  deleteQueueItem(itemId) {
    return this.$http({
      url: `${this.AppConstants.api('v2')}/layers/private/theme/${itemId}`,
      method: 'DELETE',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    }).then((res) => {
      this.SweetAlert.success(
        'COMPONENTS.LAYER_MANAGER_MODAL.MESSAGES.FILE_REMOVED',
      );
      this.getExecutionQueue();
      this.getSerasaAndUserThemes();
    });
  }

  getOnlyIndex(key, slug, subLayer) {
    return this.$http({
      url: `${this.getUrl()}${this.getSlug('ibge_query')}/${
        subLayer.type
      }/index.json`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    });
  }

  resetCompareCard() {
    this.Markers.compare.guid = null;
    this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
  }

  loadCustomLayer() {
    this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
    this.$rootScope.$broadcast(CHANGE_CUSTOM_LAYER_SELECTION);

    this.Markers.compare.guid = null;
    if (!this.currentCustomLayer.shapeFileId) {
      if (
        this.lastSelectedType == 'country' &&
        this.lastSelectedValue == 'Brasil'
      ) {
        return;
      }
      if (this.selection.coordinates) {
        delete this.selection.coordinates;
      }
      this.$rootScope.$broadcast(REMOVE_MAP_EVENTS_OF_THEMES, {});
      this.customThemesLayer = false;
      this.Cards.customLayerTheme = false;
      this.resetIbgeCombos();
      return;
    }

    this.customThemesLayer = true;
    this.Cards.customLayerTheme = true;
    this.status = 'busy';
    this.geojson = false;

    this.lastSelectedValue = this.currentCustomLayer.fileName;
    this.lastSelectedType = this.currentCustomLayer.source;

    let themeUrl = `${this.AppConstants.api('v2')}/layers/private/theme/${
      this.currentCustomLayer.shapeFileId
    }`;

    if (this.currentCustomLayer.source == 'Serasa') {
      themeUrl = `${this.AppConstants.api('v2')}/layers/private/theme/serasa/${
        this.currentCustomLayer.shapeFileId
      }`;
    }

    return this.$http({
      url: themeUrl,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    }).then(
      (res) => {
        this.$rootScope.$broadcast(STYLIZE_MAP, false);
        this.geojson = res.data;
      },
      (err) => {
        this.status = 'finished';
        this.$rootScope.$broadcast(RELEASE_MAP);
      },
    );
  }

  getMap(subLayer, standAloneCity) {
    let url = `${this.AppConstants.api(
      null,
      '/',
    )}assets/layers/ibge${this.getSlug()}/map.geojson`;
    if (subLayer) {
      url = `${this.AppConstants.api(
        null,
        '/',
      )}assets/layers/ibge${this.getSlug()}/${subLayer.type}/map.geojson`;
    }
    if (standAloneCity) {
      url = url.replace('bairros/', '');
    }
    return this.$http({
      url,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
    }).then(
      (res) => {
        this.$rootScope.$broadcast(CLEAN_MAP_DATA, {});
        const clock = setInterval(() => {
          if (this.IsMapClear) {
            clearInterval(clock);
            this.geojson = res.data;
            this.$rootScope.$broadcast(FINISH_MAP_LOADING, {});
          }
        }, 250);
      },
      (err) => {
        this.status = 'finished';
        this.$rootScope.$broadcast(RELEASE_MAP);
      },
    );
  }
}
