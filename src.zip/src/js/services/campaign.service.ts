import { Base } from '../core/models';
import FiltersService from './filters.service';
import JWT from './jwt.service';
import { StateService } from '@uirouter/core';
import LayersService from './layers.service';
import CardsService from './cards.service';
import { SweetAlertService } from './sweet-alert.service';

export default class CampaignService {
  base = {} as Base;
  group = '';
  count = 0;
  personGroup = [];
  layerSource = false;
  multi: boolean;
  tags;
  fmtFilters;
  blockSubmit: boolean;
  userCount: number;
  exclusion_database_id: string;

  constructor(
    private $http: ng.IHttpService,
    private AppConstants,
    private Markers,
    private Filters: FiltersService,
    private JWT: JWT,
    private $translate: ng.translate.ITranslateService,
    private $q: ng.IQService,
    private $state: StateService,
    private Layers: LayersService,
    private Cards: CardsService,
    private SweetAlert: SweetAlertService,
  ) {
    'ngInject';
  }

  setSelectedBase(base: Base) {
    this.base = { ...base };
  }

  setOptions(options: CampaignServiceOptions, exclude = false) {
    this.multi = options.multi;
    this.group = options.group;
    this.count = options.count || 0;
    this.tags = options.tags;
    this.fmtFilters = options.fmtFilters;
    this.blockSubmit = false;
    this.userCount = this.count;
    if (exclude) {
      this.exclusion_database_id = this.base.id;
      this.base.id = 'serasa';
    }
  }

  getTagValues(tags: { text: string }[]) {
    return tags.map((tag) => tag.text);
  }

   clearBases() {
     this.base = null;
   }

  sendFacebook(formFields) {
    let data = {} as SendFacebookPayload;
    let params = this.Filters.getParams();

    data.audience = {
      filters: params.filters,
      count: this.count,
      limit: this.userCount,
    };

    if (this.base.id) data.audience.database_id = this.base.id;
    if (this.base.name) data.audience.database_name = this.base.name;

    if (this.exclusion_database_id) {
      data.audience.exclusion_database_id = this.exclusion_database_id;
      delete this.exclusion_database_id;
    }

    let target = null;
    let region = 'region/serasa';
    if (this.$state.current.name == 'app.data-view') {
      target = region;
      data.audience.location = this.Layers.selection;
      data.audience.location['entity-origin'] = 'CORREIOS';
    } else {
      if (this.Cards.layerMode) {
        target = region;
        data.audience.location = this.Layers.selection;
        data.audience.location['entity-origin'] = 'IBGE';
      } else {
        target = this.Markers.primary.guid;
      }
    }

    if (this.$state.current.name == 'app.data-view') {
      data.audience.location = this.Layers.selection;
    }

    data.campaignInformation = {
      accountEmails: this.getTagValues(formFields.emails),
      accountIds: formFields.ids,
      name: formFields.name,
    };

    return this.$http({
      url: `${this.AppConstants.api()}/data/request/${target}/residents/campaign/facebook`,
      method: 'POST',
      headers: {
        Authorization: 'Bearer ' + this.JWT.get(),
      },
      data,
    }).then(
      (res) => {
        this.SweetAlert.success(
          'COMPONENTS.CAMPAIGN_SIMPLE_MODAL.MESSAGES.SUCCESS.TITLE',
        );
      },
      (err) => {
        this.SweetAlert.error(
          'COMPONENTS.CAMPAIGN_SIMPLE_MODAL.MESSAGES.ERROR',
        );
      },
    );
  }
}

interface SendFacebookPayload {
  audience: {
    count: number,
    database_id?: string,
    database_name?: string,
    exclusion_database_id: string,
    filters: string[],
    limit: number,
    location: {
      'entity-origin'?: string,
      country: string
    }
  };
  campaignInformation: {
    accountEmails: string[],
    accountIds: string,
    name: string,
  };
}

interface CampaignServiceOptions {
  count: number;
  fmtFilters?;
  group?: string;
  fields?;
  multi?;
  tags?: string[];
}
