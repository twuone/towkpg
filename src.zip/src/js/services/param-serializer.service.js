export default class ParamSerializer {
  base64(str, isCustomParam = false) {
    // Unicode Compatible - https://goo.gl/nUcUXv
    // first we use encodeURIComponent to get percent-encoded UTF-8,
    // then we convert the percent encodings into raw bytes which
    // can be fed into btoa.
    const pattern = /%([0-9A-F]{2})/g;

    const result = btoa(
      encodeURIComponent(JSON.stringify(str)).replace(pattern, (_, p1) =>
        String.fromCharCode(`0x${p1}`),
      ),
    );

    if (isCustomParam) {
      return `${result}`;
    }

    return `params=${result}`;
  }
}
