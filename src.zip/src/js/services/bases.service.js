export default class BasesService {
  constructor(
    $http,
    $log,
    $rootScope,
    $state,
    $translate,
    AppConstants,
    AudienceTypes,
    Cards,
    Filters,
    JWT,
    Layers,
    Markers,
    ParamSerializer,
    SweetAlert,
    Tab,
  ) {
    'ngInject';

    this.$log = $log;
    this._AppConstants = AppConstants;
    this._JWT = JWT;
    this._$http = $http;
    this._ParamSerializer = ParamSerializer;
    this._Filters = Filters;
    this._AudienceTypes = AudienceTypes;
    this._Layers = Layers;
    this._Tab = Tab;
    this._Markers = Markers;
    this._$translate = $translate;
    this._$state = $state;
    this.SweetAlert = SweetAlert;
    this._$rootScope = $rootScope;
    this._Cards = Cards;
    this.tempBasesNames = null;
    this.countersHub = [];
    this.queue = {};
    this.data_view = {
      masterReport: null,
      slaveReport: null,
    };

    // Init public variables
    this.available = [
      {
        id: 'serasa',
        name: 'Serasa Experian',
      },
    ];

    this.selection = [
      {
        column: 'primary',
        id: 'serasa',
        name: 'Serasa Experian',
      },
      {
        column: 'secondary',
        id: null,
        name: null,
      },
    ];
  }

  reset() {
    this.available = [
      {
        id: 'serasa',
        name: 'Serasa Experian',
      },
    ];

    this.selection = [
      {
        column: 'primary',
        id: 'serasa',
        name: 'Serasa Experian',
      },
      {
        column: 'secondary',
        id: null,
        name: null,
      },
    ];
    this.resetCustomFields();
    this.tempBasesNames = [];
  }

  get() {
    return this._$http({
      url: `${this._AppConstants.api('v2')}/database/customer-database`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
    }).then((res) => {
      this.available = [
        {
          id: 'serasa',
          name: 'Serasa Experian',
        },
      ];
      this.available = this.available.concat(res.data);
      this.tempBasesNames = this.available.map((i) => i.name);
      return this.available;
    });
  }

  isBusy() {
    this.status = 'idle';
    Object.keys(this.queue).forEach((key) => {
      if (this.queue[key] == 'loading') {
        this.status = 'busy';
      }
    });
  }

  getReport(id = 'serasa', column) {
    // COMBAK: This custom queue manager may be replaced with angular's $q
    // If not, it should at least have it's funcionality more encapsulated
    // Maybe a queue.register(baseId)

    const queueID = btoa(`${id}:${Date.now()}`);
    this.queue[queueID] = 'loading';
    this.isBusy();

    const basesParams = this.getParams(id);

    const requestParams = {
      masterType: this.selection[0].id == 'serasa' ? 'SERASA' : 'CUSTOMER',
      slaveType: this.selection[1].id == 'serasa' ? 'SERASA' : 'CUSTOMER',
      masterReportId:
        this.selection[0].id == 'serasa' ? null : this.selection[0].id,
      slaveReportId:
        this.selection[1].id === null
          ? null
          : this.selection[1].id == 'serasa'
          ? null
          : this.selection[1].id,
      params: this._ParamSerializer.base64(basesParams, true),
    };

    for (let k = 0; k < requestParams.length; k++) {
      if (!requestParams[k]) {
        delete requestParams[k];
      }
    }

    return this._$http({
      url: `${this._AppConstants.api('v2')}/database/full-report`,
      method: 'GET',
      headers: {
        Authorization: 'Bearer ' + this._JWT.get(),
      },
      params: requestParams,
    }).then(
      (res) => {
        res.data = this._TEMP_FORMAT_RESPONSE_DATA(res.data);

        this._Cards.dataCardComparison.primary = Object.assign(
          {},
          res.data.masterReport.cards,
        );
        this._Cards.dataCardComparison.primary.count = {
          value: res.data.masterReport.counters.audience,
        };

        if (res.data.slaveReport) {
          this._Cards.dataCardComparison.compare = Object.assign(
            {},
            res.data.slaveReport.cards,
          );
          this._Cards.dataCardComparison.compare.count = {
            value: res.data.slaveReport.counters.audience,
          };
        }

        delete this.queue[queueID];
        this.isBusy();

        Object.keys(res.data)
          .filter((reportKey) => res.data[reportKey])
          .forEach((reportKey) => {
            Object.keys(res.data[reportKey].cards).forEach((cardName) => {
              if (
                res.data[reportKey].cards[cardName].graph &&
                res.data[reportKey].cards[cardName].table
              ) {
                res.data[reportKey].cards[cardName].graph = this._getPercentage(
                  res.data[reportKey].cards[cardName].graph,
                );
              } else {
                res.data[reportKey].cards[cardName] = this._getPercentage(
                  res.data[reportKey].cards[cardName],
                );
              }
            });
          });
        this.data_view = res.data;
        return res.data;
      },
      (reason) => {
        this.$log.error('ERROR', reason);
        delete this.queue[queueID];
        this.isBusy();

        this.SweetAlert.error(
          'FILTERS.BASE_SELECTOR.MESSAGES.SERVER_ERROR.TITLE',
          'FILTERS.BASE_SELECTOR.MESSAGES.SERVER_ERROR.MESSAGE',
        );

        const data = {
          error: reason.status,
        };
        return data;
      },
    );
  }

  _TEMP_FORMAT_RESPONSE_DATA(responseData) {
    this.$log.warn('TODO:', 'This response should be formated on the back-end');
    Object.keys(responseData).forEach((reportKey) => {
      if (responseData[reportKey]) {
        // Temporary removing city object, but in the future (?) must be city instead state_city
        if (responseData[reportKey].cards.city) {
          delete responseData[reportKey].cards.city;
        }
        ['state_city'].forEach((cardName) => {
          const card = responseData[reportKey].cards[cardName];
          if (card.length) {
            const cardData = card[0].data;
            responseData[reportKey].cards[cardName] = cardData;
          }
        });
      }
    });
    return responseData;
  }

  _getPercentage(data) {
    if (data instanceof Array) {
      const total = data.reduce((prev, cur) => {
        return prev + cur.value;
      }, 0);

      const newData = data.map((d) => {
        d.percentage = (d.value / total) * 100;
        return d;
      });

      return newData;
    }
    return data;
  }

  getAvailableSegments() {
    this.availableSegments = new Set();

    this.applied.forEach((base) => {
      if (base.data && !base.data.error) {
        const segments = Object.keys(base.data.cards);
        segments.forEach((segment) => this.availableSegments.add(segment));
      }
    });

    this.availableSegments = Array.from(this.availableSegments);
    return this.availableSegments;
  }

  resetCustomFields() {
    delete this.customFields;
    this._Filters.custom = {};
  }

  consolidateCustomFields() {
    this.selection.forEach((selection, index) => {
      if (index === 0) {
        this.customFields = {};
      }

      if (
        selection.id &&
        selection.id !== 'serasa' &&
        selection.fields.length
      ) {
        selection.fields.forEach((field) => {
          if (!this.customFields[field.fieldName]) {
            this.customFields[field.fieldName] = new Set();
          }

          field.fieldOptions.forEach((opt) => {
            this.customFields[field.fieldName].add(opt.option);
          });
        });
      }

      this._Cards.customFields = this.customFields;
    });

    Object.keys(this.customFields)
      .sort()
      .forEach((key) => {
        // Sorting this Object's keys for angular's ngRepeat
        const hold = this.customFields[key];
        delete this.customFields[key];
        this.customFields[key] = hold;

        this.customFields[key] = Array.from(this.customFields[key]).sort();
      });

    if (
      Object.keys(this.customFields).length === 0 &&
      this.customFields.constructor === Object
    ) {
      delete this.customFields;
    }
  }

  getAvailableValues() {
    //FIXME: https://jsperf.com/for-vs-foreach/37
    // Loop through the applied bases
    this.applied.forEach((base, index, array) => {
      // Reset the dictionary on first iteration
      if (index === 0) {
        this.values = {};
        this.table = {};
      }

      // Check if is selected
      if (base.id && base.data) {
        // Loop through cards
        Object.keys(base.data.cards).forEach((segment) => {
          if (!this.values[segment] || !this.table[segment]) {
            this.values[segment] = new Set();
            this.table[segment] = {};
          }

          if (
            !base.data.cards[segment].graph &&
            !base.data.cards[segment].table
          ) {
            // Loop through values

            base.data.cards[segment].forEach((value) => {
              this.values[segment].add(value.label);
              if (!this.table[segment][base.id]) {
                this.table[segment][base.id] = {};
              }
              this.table[segment][base.id][value.label] = value.value;
            });
          } else if (segment === 'state_city') {
            base.data.cards[segment].table.forEach((value) => {
              if (this.values[segment].size <= 49) {
                this.values[segment].add(value.label);
              }

              if (!this.table[segment][base.id]) {
                this.table[segment][base.id] = {};
              }
              this.table[segment][base.id][value.label] = value.value;

              this.messageFor50Items =
                this.values[segment].size >= 50 ? true : false;
            });
          }
        });
      }
    });

    Object.keys(this.values).forEach((key) => {
      let array = Array.from(this.values[key]);

      if (key !== 'state_city') {
        array = array.sort();
      }

      this.values[key] = array;
    });

    this._Cards.available[this._AudienceTypes.applied].forEach((element) => {
      this.values[element.name] = element.values;
    });
  }

  clearAvailableSegments() {
    this.availableSegments = [];
  }

  getCards(baseId) {
    const cards = [];

    if (!baseId) {
      return cards;
    }

    this._Cards.available[this._AudienceTypes.selected].forEach((element) => {
      cards.push(element.name);
    });

    if (this._AudienceTypes.applied == 'residents') {
      cards.push('city');
      cards.push('state_city|count');
      cards.push('id_household|count');
    } else {
      cards.push('city');
      cards.push('state_city|count');
    }

    // Add custom fields
    if (baseId !== 'serasa') {
      const selectedBase = this.applied.filter((obj) => {
        return obj.id == baseId;
      })[0];

      selectedBase.fields.forEach((key) => {
        cards.push(key.fieldName);
      });
    }
    return cards;
  }

  getParams(primaryId, secondaryId) {
    const filters = this._Filters.getFilters();
    let cards = [];

    if (secondaryId) {
      cards = [
        ...new Set([
          ...this.getCards(primaryId),
          ...this.getCards(secondaryId),
        ]),
      ];
    } else {
      cards = this.getCards(primaryId);
    }

    return {
      filters,
      cards,
      category: this._AudienceTypes.applied,
      location: this._Layers.selection,
    };
  }

  select(id, base = 'primary') {
    if (id) {
      this.selectedBases[base] = id;
    } else {
      this.$log.warn(
        "Base ID can't be null. Use clearSelection() to reset it instead.",
      );
    }
  }

  clearSelection() {
    this.selection.forEach((item, index) => {
      if (this.applied) {
        this.applied[index].id = null;
        this.applied[index].name = null;
      }
      if (item.column == 'primary') {
        item.id = 'serasa';
        item.name = 'Serasa Experian';
      } else {
        item.id = null;
        item.name = null;
      }
    });
    this._Cards.baseId = this.selection[0].id;
    this._Cards.baseIdCompare = this.selection[1].id;
  }

  applySelection() {
    this.applied = angular.copy(this.selection); // We use copy to take advantage of the digestCycle check
    this._AudienceTypes.previous = this._AudienceTypes.applied;
    this._AudienceTypes.applied = this._Tab.cards;
    this.consolidateCustomFields();

    //COMBAK: This shoudn't be here
    if (this._Filters.isFiltersValid()) {
      this._Filters.change();
    } else {
      // some filter is invalid
      this.$log.warn('Invalid Filters!');
    }
  }

  isComparisonReady() {
    // Check if one of bases is Serasa...
    if (
      this.selection[1].id &&
      (this.selection[0].id == 'serasa' || this.selection[1].id == 'serasa') &&
      !(this.selection[0].id == 'serasa' && this.selection[1].id == 'serasa')
    ) {
      // Check if there is sufficient Data
      if (
        !this._Cards.dataCardComparison.primary ||
        !this._Cards.dataCardComparison.compare ||
        this._Cards.lockCalculation
      ) {
        return false;
      }

      let p_len = 0;
      let c_len = 0;

      Object.keys(this._Cards.dataCardComparison.primary).forEach((el) => {
        if (el.substring(0, 7) != 'custom_') {
          p_len++;
        }
      });

      Object.keys(this._Cards.dataCardComparison.compare).forEach((el) => {
        if (el.substring(0, 7) != 'custom_') {
          c_len++;
        }
      });

      if (
        this._Cards.dataCardComparison.primary &&
        this._Cards.dataCardComparison.compare &&
        p_len == c_len
      ) {
        return true;
      }
    }
    return false;
  }
}
