export default class PanelStateService {
  constructor() {
    this.menuFilters = {
      isOpen: false
    }
  }

  setOpenState(state) {
    this.menuFilters.isOpen = state
  }
}

