import { module } from 'angular';

import BasesService from './bases.service';
import CampaignService from './campaign.service';
import CardsService from './cards.service';
import DimensionService from './dimension.service';
import DocumentsService from './documents.service';
import ExportService from './export.service';
import FilterService from './filter.service';
import Filters from './filters.service';
import HeatMap from './heatmap.service';
import JwtService from './jwt.service';
import LayersService from './layers.service';
import ModalService from './modal.service';
import PanelStateService from './panel-state.service';
import ParamSerializer from './param-serializer.service';
import PlacesService from './places.service';
import InboxService from './polis-inbox.service';
import SnapshotService from './snapshot.service';
import { UserService } from './user.service';
import ExtractionService from './extraction.service';
import { AudienceTypesService } from './audience-types.service';
import { SweetAlertService } from './sweet-alert.service';


// Create the module where our functionality can attach to
export const ServicesModule = module('app.services', [])
  .service('AudienceTypes', AudienceTypesService)
  .service('Bases', BasesService)
  .service('Campaign', CampaignService)
  .service('Cards', CardsService)
  .service('DimensionService', DimensionService)
  .service('Documents', DocumentsService)
  .service('ExtractionService', ExtractionService)
  .service('Export', ExportService)
  .service('Filters', Filters)
  .service('FilterService', FilterService)
  .service('HeatMap', HeatMap)
  .service('InboxService', InboxService)
  .service('JWT', JwtService)
  .service('Layers', LayersService)
  .service('Modal', ModalService)
  .service('PanelStateService', PanelStateService)
  .service('ParamSerializer', ParamSerializer)
  .service('Places', PlacesService)    
  .service('SnapshotService', SnapshotService)
  .service('SweetAlert', SweetAlertService)
  .service('User', UserService).name;
  
