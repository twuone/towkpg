export default class PlacesFilter {
	constructor(Filters, $translate, PLACES_INFO) {
		'ngInject';

		// init private variables
		this._Filters = Filters;
		this._$translate = $translate;
		this._PlacesInfo = PLACES_INFO;

		// init public variables
		this.selectedPlaces = [];
		this.placesMap = {};

		this.orderedPlaces = Object.keys(this._PlacesInfo).sort((a,b) => {
			return (this._PlacesInfo[a] > this._PlacesInfo[b] ? 1 : (this._PlacesInfo[a] < this._PlacesInfo[b] ? -1 : 0));
		});
		
		this.orderedPlaces.forEach((place) => {
			this.placesMap[place] = false;
		});
	}

}
