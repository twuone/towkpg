import { isDefined } from 'angular';
import REQUEST_DOCUMENTS from '../constants/request-documents.constant';
import CUSTOM_DOCUMENTS from '../constants/custom-documents.constant';

export default class ExtractionService {
  constructor() {
    'ngInject';

    this.REQUEST_DOCUMENTS = REQUEST_DOCUMENTS;
    this.CUSTOM_DOCUMENTS = CUSTOM_DOCUMENTS;
  }

  get DefaultVariablesForExtraction() {
    return this.REQUEST_DOCUMENTS;
  }

  get CustomVariablesForExtraction() {
    return this.CUSTOM_DOCUMENTS;
  }

  getDefaultVariablesForExtractionByAudience(audience) {
    return this.DefaultVariablesForExtraction[audience];
  }

  getCustomVariablesForExtractionByAudience(audience) {
    return this.CustomVariablesForExtraction[audience];
  }

  getVariablesForExtractionByUserAndAudience(userConfig, audience) {
    const defaultVariables = this.getDefaultVariablesForExtractionByAudience(
      audience,
    );
    const customVariables = this.getEnabledCustomDocumentsForExtraction(
      userConfig,
      audience,
    );

    return [...defaultVariables, ...customVariables];
  }

  getEnabledCustomDocumentsForExtraction(userConfig, audience) {
    return this.getCustomVariablesForExtractionByAudience(audience).filter(
      (customVariableForExtraction) =>
        isDefined(userConfig.customVars) &&
        Object.entries(userConfig.customVars)
          .map(([customVarName, customVarValue]) => {
            return {
              name: customVarName,
              value: customVarValue,
            };
          })
          .some((customVar) =>
            this.isCustomVariableEnabled(
              customVar.name,
              customVariableForExtraction,
              customVar.value,
            ),
          ),
    );
  }

  isCustomVariableEnabled(
    customVarName,
    customVariableForExtraction,
    customVarValue,
  ) {
    return (
      this.isCustomVarNameEqualToVariableForExtractionFlag(
        customVarName,
        customVariableForExtraction,
      ) && customVarValue === true
    );
  }

  isCustomVarNameEqualToVariableForExtractionFlag(
    customVarName,
    customVariableForExtraction,
  ) {
    return customVarName === customVariableForExtraction.flag;
  }
}
