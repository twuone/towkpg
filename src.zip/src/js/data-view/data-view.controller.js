import { RESET_NOT_PANEL_COMPLETELY } from '../app.actions';
import { loadAffinities } from '../actions/affinities';

class DataViewController {
  constructor(
    $ngRedux,
    AppConstants,
    Bases,
    Layers,
    User,
    $rootScope,
    Cards,
    SnapshotService,
    AudienceTypes,
    DimensionService,
    FilterService,
  ) {
    'ngInject';

    this.appName = AppConstants.appName;
    this.Bases = Bases;
    this.Layers = Layers;
    this.Cards = Cards;
    this.user = User;
    this.Bases.clearSelection();
    this.Layers.reset();
    this.$rootScope = $rootScope;
    this.$ngRedux = $ngRedux;
    this.AudienceTypes = AudienceTypes;
    this.$rootScope.$broadcast(RESET_NOT_PANEL_COMPLETELY);
    this.SnapshotService = SnapshotService;
    this.DimensionService = DimensionService;
    this.FilterService = FilterService;

    this.$onInit();
  }

  fetchDimensions() {
    return this.DimensionService.fetch().then((dimensions) => {
      this.DimensionService.setAvailableGroups(dimensions, this.user.getConfig());
      this.FilterService.setup();

      const affinities = this.FilterService.getAffinities();

      this.$ngRedux.dispatch(loadAffinities(affinities));
    });
  }

  $onInit() {
    this.fetchDimensions();
    this.getCards();
    this.fetchSnapshot();
  }

  fetchSnapshot() {
    return this.SnapshotService.fetch();
  }

  getCards() {
    this.AudienceTypes.available.forEach((type) => {
      this.Cards.getCardsNew(type).then((response) => {
        this.onGetCardsSuccess(response, type);
      });
    });
  }

  onGetCardsSuccess(response, cardType) {
    const allowedCards = this.DimensionService.filterAvailable(
      response,
      this.user.getConfig(),
    );

    this.Cards.available[cardType] = allowedCards;
  }
}

export default DataViewController;
