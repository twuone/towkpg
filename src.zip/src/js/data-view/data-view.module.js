import angular from 'angular';
import HomeConfig from './data-view.config';
import DataViewController from './data-view.controller';

export const DataViewModule = angular
  .module('app.dataView', [])
  .controller('DataViewController', DataViewController)
  .config(HomeConfig).name;
