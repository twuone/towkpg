import template from './data-view.html';

function DataViewConfig($stateProvider) {
  'ngInject';

  const dataViewState = {
    name: 'app.data-view',
    url: '/data-view',
    controller: 'DataViewController',
    controllerAs: '$ctrl',
    template,
    data: {
      title: 'Data View',
    },
    resolve: {
      auth: /* @ngInject */ (User) => User.ensureAuthIs(true),
      onEnter(AudienceTypes, Tab, Cards) {
        'ngInject';

        if (AudienceTypes.applied === 'visitors') {
          AudienceTypes.applied = 'residents';
        }

        if (Tab.isVisitors()) {
          Tab.cards = 'residents';
        }

        Cards.dataCardComparison = {};
      },
    },
  };

  $stateProvider.state(dataViewState);
}

export default DataViewConfig;
