import template from './footer.html';

export const AppFooterComponent = {
  template,
  controller: class AppFooterComponent {
    constructor(AppConstants) {
      'ngInject';
      this.appName = AppConstants.appName;

      // Get today's date to generate the year
      this.date = new Date();
    }
  },
};
