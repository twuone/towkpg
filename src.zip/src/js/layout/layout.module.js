import angular from 'angular';

import { AppHeaderComponent } from './header.component';
import { AppFooterComponent } from './footer.component';

// Create the module where our functionality can attach to
export const LayoutModule = angular
  .module('app.layout', [])
  .component('appHeader', AppHeaderComponent)
  .component('appFooter', AppFooterComponent).name;
