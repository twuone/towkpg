import { CHANGE_LAYER_MODE } from '../app.actions';
import template from './header.html';

export const AppHeaderComponent = {
  template,
  controller: class AppHeaderComponent {
    constructor(
      AppConstants,
      User,
      Places,
      PanelStateService,
      $scope,
      $translate,
      Modal,
      $state,
      Bases,
      Export,
      Layers,
      $rootScope,
      Campaign
    ) {
      'ngInject';

      // init private variables
      this._User = User;
      this._$scope = $scope;
      this._$translate = $translate;
      this._PanelStateService = PanelStateService;
      this._Modal = Modal;
      this.$state = $state;
      this._Bases = Bases;
      this._Export = Export;
      this._Layers = Layers;
      this._$rootScope = $rootScope;
      this._Campaign = Campaign;

      // init public variables
      this.appName = AppConstants.appName;
      this.places = Places;
      this.isHeatmapEnabled = false;
      this.isHeatMapLoading = false;
      this.isBicycleMapEnabled = false;
      this.isTrafficMapEnabled = false;
    }

    openModal(modalID) {
      $('#' + modalID).modal('show');
      this._Modal.setCurrentModal(modalID);
    }

    logout() {
      this._User.logout();
    }

    toggleFilterMenu() {
      this._PanelStateService.menuFilters.isOpen = !this._PanelStateService
        .menuFilters.isOpen;
    }

    changeLanguage(key) {
      this._$translate.use(key);
    }

    resetByViewChange() {
      this._Bases.clearSelection();
      this._Bases.resetCustomFields();
      this._$rootScope.$broadcast(CHANGE_LAYER_MODE, {});
      this._Layers.reset();
      this._Campaign.clearBases();
    }

    toogleSelectDimensions() {
      $('#selectDimensionModal').modal('show');
    }
  },
};
