export function createObjectKeys(myArray) {
  var dt = {};
  myArray.forEach((val) => {
        dt[val] = true;
  });
  return dt;
}

export function createObjectKeysSame(myArray) {
  var dt = {};
  myArray.forEach((val) => {
        dt[val] = val;
  });
  return dt;
}

export function sortByName(a, b) {
  return sortByProperty('name')(a, b);
}

export function flatMap(old, next) {
  return old.concat(...Object.values(next));
}

export function sortByProperty(propertyName) {
  return function sort(prev, actual) {
    if (prev[propertyName] < actual[propertyName]) {
      return -1;
    }

    if (prev[propertyName] > actual[propertyName]) {
      return 1;
    }

    return 0;
  };
}
