import * as angular from 'angular';
import { GoogleTagManagerMiddleware } from './services/gtm-middleware.service';

export const CoreModule = angular
  .module('app.core', [])
  .factory('gtmMiddleware', GoogleTagManagerMiddleware).name;
