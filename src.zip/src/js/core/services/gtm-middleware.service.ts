import GoogleTagManager from '@redux-beacon/google-tag-manager';

import { createMiddleware, EventsMapper, EventsMap } from 'redux-beacon';

const STATE_CHANGE_SUCCESS = '@@reduxUiRouter/onSuccess';

export function GoogleTagManagerMiddleware(
  $translate: ng.translate.ITranslateService,
) {
  'ngInject';

  const gtm = GoogleTagManager();
  const trackPageView = (action) => ({
    page: {
      path: action.payload.toState.url,  
      title: $translate.instant(action.payload.toState.data.title),
    },
    event: 'pageview',
  });

  const eventsMap: EventsMap | EventsMapper = {
    ['@@reduxUiRouter/onSuccess']: trackPageView,
  };

  return createMiddleware(eventsMap, gtm);
}
