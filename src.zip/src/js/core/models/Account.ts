import { AccountConfig } from "./AccountConfig";

export interface Account {
  name: string;
  token: string;
  value?: string;
  config: AccountConfig;
}
