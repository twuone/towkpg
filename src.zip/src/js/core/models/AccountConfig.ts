import { CustomVars } from "./CustomVars";

export interface AccountConfig {
  visitorsEnabled?: boolean;
  /**
   * Informa se a geração de audiência no facebook está habilitada
   * para esse usuário
   */
  facebookEnabled?: boolean;
  customVars?: CustomVars;
}
