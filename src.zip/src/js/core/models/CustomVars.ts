export interface CustomVars {
  /**
   * Usuário pode extrair a variável CSBA_BV?
   */
  extract_cs_csba_bv: boolean;

}
