import { User } from "./User";
import { Account } from "./Account";

export interface UserInfo {
  user: User;
  account: Account;
}
