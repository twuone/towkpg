export interface ExtractionField {
  name: string;
  checked: boolean;
  isCustom: boolean;
}
