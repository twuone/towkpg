import { UserConfig } from "./UserConfig";

export interface User {
  config: UserConfig;
}
