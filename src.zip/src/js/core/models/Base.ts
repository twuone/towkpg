export interface Base {
  id: string,
  name: string,
}
