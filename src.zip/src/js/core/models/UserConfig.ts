export interface UserConfig {
  radius?: {
    min: number;
    max: number;
  };
}
