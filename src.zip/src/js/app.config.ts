import { UNAUTHORIZED, FORBIDDEN } from 'http-status';
import rootReducer, { initialState } from './reducers';
import thunkMiddleware from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';
import { applyMiddleware } from 'redux';
import { StateProvider, UrlService } from '@uirouter/angularjs';
import { UserService } from './services/user.service';
import ngRedux from 'ng-redux';

/* @ngInject */
function AppConfig(
  $httpProvider: ng.IHttpProvider,
  $stateProvider: StateProvider,
  $ngReduxProvider: ngRedux.INgReduxProvider,
  $translateProvider: ng.translate.ITranslateProvider,
  $urlServiceProvider: UrlService,
  ivhTreeviewOptionsProvider,
) {
  setupRedux();
  setupRouting($stateProvider, $urlServiceProvider);
  setupI18n($translateProvider);
  setupTreeView(ivhTreeviewOptionsProvider);
  setupInterceptors($httpProvider);

  function setupRedux() {
    const middlewares = [thunkMiddleware];
    const middlewareEnhancer = applyMiddleware(...middlewares);
    const enhancers = [middlewareEnhancer];
    const composedEnhancers = composeWithDevTools(...enhancers);

    $ngReduxProvider.createStoreWith(
      rootReducer,
      ['gtmMiddleware'],
      [composedEnhancers],
      initialState,
    );
  }
}

function setupTreeView(ivhTreeviewOptionsProvider) {
  ivhTreeviewOptionsProvider.set({
    defaultSelectedState: false,
    validate: true,
    twistieCollapsedTpl: '<span class="mdi mdi-chevron-right"></span>',
    twistieExpandedTpl: '<span class="mdi mdi-chevron-down"></span>',
    twistieLeafTpl: '&#9679;',
  });
}

function setupRouting($stateProvider: StateProvider, $urlServiceProvider: UrlService) {
  const appState = {
    name: 'app',
    abstract: true,
    component: 'app',
    resolve: {
      auth: /* @ngInject */ (User: UserService) => User.verifyAuth(),
    },
  };

  $stateProvider.state(appState);
  $urlServiceProvider.rules.otherwise('/');
}

function setupI18n($translateProvider: ng.translate.ITranslateProvider) {
  $translateProvider.preferredLanguage('pt');
  $translateProvider.fallbackLanguage('pt'); // TODO: Change to en
  $translateProvider.useSanitizeValueStrategy('escape');
  $translateProvider.useLocalStorage();
  $translateProvider.registerAvailableLanguageKeys(['pt'], {
    'pt-*': 'pt',
  });
  $translateProvider.useStaticFilesLoader({
    prefix: 'assets/languages/',
    suffix: '.json',
  });
}

function setupInterceptors($httpProvider: ng.IHttpProvider) {
  // Intercept all requests and log out in case of 401 (Unauthorized)
  $httpProvider.interceptors.push(
    /* @ngInject */ ($injector, $q: ng.IQService) => ({
      responseError(rejection) {
        const User: UserService = $injector.get('User');
        if (
          [UNAUTHORIZED, FORBIDDEN].includes(rejection.status) &&
          rejection.data.message !== 'PASSWORD_REUSED'
        ) {
          User.cleanEnv();
        }
        return $q.reject(rejection);
      },
    }),
  );
}

export default AppConfig;
