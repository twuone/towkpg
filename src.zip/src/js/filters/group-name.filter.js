function GroupNameFilter() {

	return (groupName='') => {
        return groupName.replace(/(--.+)/,'');
    };
}

export default GroupNameFilter;
