export function IsAdditionalDimensioGroupFilter() {
  return (group) => (!group.name.includes('serasa') ? group : false);
}
