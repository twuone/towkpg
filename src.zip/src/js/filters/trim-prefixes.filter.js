function TrimPrefixesFilter() {
  return function(text = '') {
    const prefixes = ['custom_'];

    for (let i = 0; i < prefixes.length; i++) {
      const re = new RegExp(`^${prefixes[i]}`, 'gi');
      const filteredText = text.replace(re, '');
      if (text != filteredText) {
        return filteredText;
      }
    }
    return text;
  };
}

export default TrimPrefixesFilter;
