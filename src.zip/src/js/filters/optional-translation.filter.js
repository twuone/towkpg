function OptionalTranslationFilter() {
  return function(text = '') {
    if (text.substring(0, 6) === 'CARDS.') {
      const tokens = text.split('.');
      return tokens[tokens.length - 1];
    }
    return text;
  };
}

export default OptionalTranslationFilter;
