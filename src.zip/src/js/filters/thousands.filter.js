function ThousandsFilter($filter) {
  'ngInject';

  return function(number = '') {
    return $filter('number')(number).replace(/,/g, '.');
  };
}

export default ThousandsFilter;
