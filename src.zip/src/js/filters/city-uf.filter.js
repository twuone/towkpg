function CityUFFilter() {
	return function(text='') {
        if(text.toLowerCase()=='none_none') return "Desconhecido"
        if(text.toLowerCase()=='unknown_unknown') return "Desconhecido"
        
        if(text.indexOf("_")!=-1){
            let temp = text.split('_')[0]
            let frag = text.split('_')
            frag.splice(0,1)
            let stringConcat = ""
            for(let i=0; i<frag.length; i++){
                stringConcat += frag[i] + " "
            }
            text = temp.toUpperCase() + " - " + stringConcat;
        }
        return text
    };
}

export default CityUFFilter;
