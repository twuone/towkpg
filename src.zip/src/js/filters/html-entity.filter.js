function HTMLEntityFilter() {

	return (text='') => {
        text = text.replace(/(\&amp;)/g, '&');
        text = text.replace(/(\&(GT|gt);)/g, '>');
        text = text.replace(/(\&(LT|lt);)/g, '<');
        return text
    };
}

export default HTMLEntityFilter;
