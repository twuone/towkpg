import angular from 'angular';
import CityUFFilter from './city-uf.filter';
import CnpjFilter from './cnpj.filter';
import CustomHighlightFilter from './custom-highlight.filter';
import GroupNameFilter from './group-name.filter';
import HTMLEntityFilter from './html-entity.filter';
import OptionalTranslationTitleFilter from './optional-translation-title.filter';
import OptionalTranslationFilter from './optional-translation.filter';
import ThousandsFilter from './thousands.filter';
import TrimPrefixesFilter from './trim-prefixes.filter';
import { IsAdditionalDimensioGroupFilter } from './is-additional-dimension-group.filter';

export const FiltersModule = angular
  .module('app.filters', [])
  .filter('cnpj', CnpjFilter)
  .filter('customHighlight', CustomHighlightFilter)
  .filter('thousands', ThousandsFilter)
  .filter('trimPrefixes', TrimPrefixesFilter)
  .filter('optionalTranslation', OptionalTranslationFilter)
  .filter('optionalTranslationTitle', OptionalTranslationTitleFilter)
  .filter('cityUFFilter', CityUFFilter)
  .filter('groupName', GroupNameFilter)
  .filter('isAdditionalDimensionGroup', IsAdditionalDimensioGroupFilter)
  .filter('htmlEntity', HTMLEntityFilter).name;
