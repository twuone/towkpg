function OptionalTranslationTitleFilter() {
  return function(text = '') {
    if (
      text.substring(0, 6) === 'CARDS.' &&
      text.split('.')[text.split('.').length - 1] == 'TITLE'
    ) {
      const tokens = text.split('.');
      let name = '';
      for (let i = 0; tokens.length > i; i++) {
        if (!['CARDS', 'TITLE'].includes(tokens[i])) {
          while (tokens[i].indexOf('_') != -1) {
            tokens[i] = tokens[i].replace('_', ' ');
          }

          name += tokens[i] + ' ';
        }
      }
      return name;
    }
    return text;
  };
}

export default OptionalTranslationTitleFilter;
