/**
 * Lista de ações que são disparadas a nível de $rootScope para a aplicação
 * inteira
 */

export const CHANGE_PAGE_TITLE = 'pageTitleChange';

export const CHANGE_AUDIENCE_TYPE_SELECTION = 'audienceTypeSelectionChange';

export const CHANGE_BOUNDS = 'bounds_changed';

export const CHANGE_CUSTOM_LAYER_SELECTION = 'customLayerSelectionChange';

export const CHANGE_LAYER_MODE = 'layerModeChanged';

export const CLEAN_MAP_DATA = 'cleanMapData';

export const FINISH_MAP_LOADING = 'mapFinishedLoading';

export const IMPORT_MARKERS_FINISHED = 'markers.importFinished';

export const LOAD_LAYER_SELECTION = 'loadLayerSelection';

export const LOGOUT_USER = 'userLogout';

export const REFRESH_MARKER_CLUSTER = 'refreshMarkerCluster';

export const REFRESH_PLACES_LIST = 'refreshPlacesList';

export const NOT_COLUMN_IS_READY = 'notColumnIsReady';

export const SET_MENU_FILTER = 'setMenuFilter';

/**
 * Evento disparado toda vez que a lista de parâmetros para a extração é
 * modificada.
 */
export const REFRESH_USER_COUNT = 'refreshUserCount';

export const RELEASE_MAP = 'releaseMap';

export const REMOVE_ALL_PLACES_TYPES = 'removeAllPlacesTypes';

export const REMOVE_MAP_EVENTS_OF_THEMES = 'removeMapEventsOfThemes';

export const RESET_NOT_PANEL_COMPLETELY = 'resetNotPanelCompletely';

export const SELECT_BY_SUBLAYER = 'selectBySubLayer';

export const SELECT_BY_LAYER = 'selectDataByLayer';

export const SELECT_UI_TAG_MANAGER = 'UiSelectTagManager';

export const SET_ALL_PLACES_TYPES = 'setAllPlacesTypes';

export const SHOW_COMPARISON_PANEL = 'showingComparisonPanel';

export const STYLIZE_MAP = 'stylizeMap';
