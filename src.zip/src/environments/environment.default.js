/**
 * Polis Config Default Settings
 * @property {string} apiUrl Url da API do projeto
 * @property {string} googleApiKey Chave da API do Google Maps
 */
const environment = {
	appName: 'polis',
	jwtKey: 'jwtToken',
	apiUrl: 'https://next-polis-polis-stg.apps.appcanvas.net',
  googleApiKey: 'AIzaSyDOP_OtzBQRiIfcVpOkw36gh5DhEsnFQ-g',
  googleTagAPIKey: 'GTM-5TDQ43F',
};

export default environment;
