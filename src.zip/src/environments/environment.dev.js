import environmentDefault from './environment.default';

/**
 * Polis Config Dev
 */
const environment = Object.assign(environmentDefault, {});

export default environment;
