import environmentDefault from './environment.default';

/**
 * Polis Config QA Settings
 */
const environment = Object.assign(environmentDefault, {
	apiUrl: 'https://polis-next-polis-qa.f-internal.br.appcanvas.net',
});

export default environment;
