import environmentDefault from './environment.default';

/**
 * Polis Config Production Settings
 */
const environment = Object.assign(environmentDefault, {
  apiUrl: 'https://polis.f.apps.experian.com',
  googleTagAPIKey: 'GTM-KFNC89P',
});

export default environment;
